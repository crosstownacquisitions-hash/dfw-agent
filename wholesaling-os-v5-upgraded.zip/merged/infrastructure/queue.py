from __future__ import annotations
from app.settings import settings

def enqueue_task(task_name: str, payload: dict) -> None:
    backend = (settings.queue_backend or "celery").lower()
    if backend == "celery":
        from infrastructure.queue_celery import celery_app
        celery_app.send_task("infrastructure.worker.execute", kwargs={"task_name": task_name, **payload})
        return
    if backend == "rq":
        from infrastructure.queue_rq import get_queue
        from infrastructure.worker import rq_execute
        get_queue().enqueue(rq_execute, task_name=task_name, **payload)
        return
    raise ValueError(f"Unsupported QUEUE_BACKEND: {backend}")
