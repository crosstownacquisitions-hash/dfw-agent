from __future__ import annotations

"""Central registry for background tasks.

We keep task discovery explicit and stable. Tasks can still be executed via a
"module:function" import string, but registering them lets us validate inputs
and provide better error messages.
"""

from collections.abc import Callable
from typing import Any

TASKS: dict[str, Callable[..., Any]] = {}


def register_task(name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    def _decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        TASKS[name] = fn
        return fn

    return _decorator


def resolve_task(name: str) -> Callable[..., Any]:
    if name in TASKS:
        return TASKS[name]

    # Fallback: allow "pkg.module:function" strings.
    if ":" not in name:
        raise KeyError(f"Task not registered and not importable: {name}")
    mod, fn = name.split(":", 1)
    module = __import__(mod, fromlist=[fn])
    task_fn = getattr(module, fn)
    return task_fn
