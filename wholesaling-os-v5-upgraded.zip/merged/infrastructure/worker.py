from __future__ import annotations

import json
from typing import Any

from app.logger import get_logger
from infrastructure.task_registry import resolve_task
from infrastructure.queue_celery import celery_app

log = get_logger(__name__)


@celery_app.task(name="infrastructure.worker.execute")
def execute(task_name: str, **kwargs: Any) -> dict:
    """Execute a registered task.

    This is the single Celery entrypoint. We keep task invocation stable and
    transport-safe.
    """
    log.info("Executing task", extra={"task": task_name, **{k: str(v) for k, v in kwargs.items()}})
    fn = resolve_task(task_name)
    result = fn(**kwargs)
    # Ensure JSON serializable result
    try:
        json.dumps(result)
        return result if isinstance(result, dict) else {"result": result}
    except Exception:
        return {"result": str(result)}


def rq_execute(task_name: str, **kwargs: Any) -> dict:
    """RQ entrypoint (when QUEUE_BACKEND=rq)."""
    fn = resolve_task(task_name)
    result = fn(**kwargs)
    return result if isinstance(result, dict) else {"result": result}
