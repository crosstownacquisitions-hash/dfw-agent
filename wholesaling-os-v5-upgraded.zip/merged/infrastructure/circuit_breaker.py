from __future__ import annotations

"""Circuit breaker for external service calls.

States: CLOSED (normal) → OPEN (failing, reject calls) → HALF_OPEN (probe)

Usage
-----
notion_breaker = get_breaker("notion")

@notion_breaker.protect
def call_notion_api():
    ...

# Or as context manager:
with notion_breaker:
    client.update_page(...)
"""

import logging
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, TypeVar

log = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


class BreakerState(Enum):
    CLOSED = "closed"       # Normal — calls pass through
    OPEN = "open"           # Failing — calls rejected immediately
    HALF_OPEN = "half_open" # Recovery probe — one call allowed


class CircuitBreakerError(Exception):
    """Raised when circuit is OPEN and call is rejected."""
    def __init__(self, service: str):
        super().__init__(f"Circuit breaker OPEN for '{service}' — service unavailable")
        self.service = service


@dataclass
class BreakerStats:
    failures: int = 0
    successes: int = 0
    total_calls: int = 0
    last_failure_time: float = 0.0
    last_state_change: float = field(default_factory=time.time)


class CircuitBreaker:
    """Thread-safe circuit breaker (single-process)."""

    def __init__(
        self,
        service: str,
        failure_threshold: int = 5,
        success_threshold: int = 2,
        reset_timeout_s: float = 60.0,
    ):
        self.service = service
        self.failure_threshold = failure_threshold
        self.success_threshold = success_threshold
        self.reset_timeout_s = reset_timeout_s

        self._state = BreakerState.CLOSED
        self._stats = BreakerStats()
        self._half_open_successes = 0

    # ------------------------------------------------------------------
    # State machine
    # ------------------------------------------------------------------

    @property
    def state(self) -> BreakerState:
        if self._state == BreakerState.OPEN:
            if time.time() - self._stats.last_failure_time >= self.reset_timeout_s:
                self._transition(BreakerState.HALF_OPEN)
        return self._state

    def _transition(self, new_state: BreakerState) -> None:
        if new_state != self._state:
            log.warning(
                "CircuitBreaker '%s' %s → %s",
                self.service,
                self._state.value,
                new_state.value,
            )
            self._state = new_state
            self._stats.last_state_change = time.time()
            if new_state == BreakerState.CLOSED:
                self._stats.failures = 0
                self._half_open_successes = 0

    def _on_success(self) -> None:
        self._stats.successes += 1
        if self._state == BreakerState.HALF_OPEN:
            self._half_open_successes += 1
            if self._half_open_successes >= self.success_threshold:
                self._transition(BreakerState.CLOSED)
        elif self._state == BreakerState.CLOSED:
            self._stats.failures = max(0, self._stats.failures - 1)

    def _on_failure(self, exc: Exception) -> None:
        self._stats.failures += 1
        self._stats.last_failure_time = time.time()
        if self._state == BreakerState.HALF_OPEN:
            self._transition(BreakerState.OPEN)
        elif self._stats.failures >= self.failure_threshold:
            self._transition(BreakerState.OPEN)

    # ------------------------------------------------------------------
    # Usage patterns
    # ------------------------------------------------------------------

    @contextmanager
    def __call__(self):
        """Use as context manager: `with breaker(): ...`"""
        current = self.state
        self._stats.total_calls += 1

        if current == BreakerState.OPEN:
            raise CircuitBreakerError(self.service)

        try:
            yield
            self._on_success()
        except CircuitBreakerError:
            raise
        except Exception as exc:
            self._on_failure(exc)
            raise

    def protect(self, fn: F) -> F:
        """Decorator: @breaker.protect"""
        import functools

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with self():
                return fn(*args, **kwargs)

        return wrapper  # type: ignore

    def call(self, fn: Callable, *args: Any, default: Any = None, **kwargs: Any) -> Any:
        """Call fn through breaker; return default if circuit is OPEN."""
        try:
            with self():
                return fn(*args, **kwargs)
        except CircuitBreakerError:
            return default

    def status(self) -> dict[str, Any]:
        return {
            "service": self.service,
            "state": self.state.value,
            "failures": self._stats.failures,
            "total_calls": self._stats.total_calls,
            "last_failure_time": self._stats.last_failure_time,
            "reset_timeout_s": self.reset_timeout_s,
        }


# ---------------------------------------------------------------------------
# Global registry
# ---------------------------------------------------------------------------

_breakers: dict[str, CircuitBreaker] = {}


def get_breaker(
    service: str,
    failure_threshold: int = 5,
    success_threshold: int = 2,
    reset_timeout_s: float = 60.0,
) -> CircuitBreaker:
    if service not in _breakers:
        _breakers[service] = CircuitBreaker(
            service=service,
            failure_threshold=failure_threshold,
            success_threshold=success_threshold,
            reset_timeout_s=reset_timeout_s,
        )
    return _breakers[service]


def all_statuses() -> list[dict[str, Any]]:
    return [b.status() for b in _breakers.values()]
