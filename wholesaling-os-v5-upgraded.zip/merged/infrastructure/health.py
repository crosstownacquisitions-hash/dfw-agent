from __future__ import annotations

"""Health check system.

Each check returns a HealthResult. The /health/detail endpoint aggregates all.

Checks registered:
  - database      (SQLAlchemy ping)
  - redis         (PING command)
  - notion        (lightweight API check)
  - llm           (env key presence)
  - disk          (output dir writable)
  - circuit_breakers (state summary)
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any, Callable

log = logging.getLogger(__name__)


@dataclass
class HealthResult:
    name: str
    status: str         # "ok" | "degraded" | "down"
    latency_ms: float = 0.0
    message: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status,
            "latency_ms": round(self.latency_ms, 1),
            "message": self.message,
            **({"meta": self.meta} if self.meta else {}),
        }


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------

def check_database() -> HealthResult:
    t0 = time.time()
    try:
        from tools.data.storage import engine
        from sqlalchemy import text
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return HealthResult("database", "ok", latency_ms=(time.time() - t0) * 1000)
    except Exception as exc:
        return HealthResult("database", "down", latency_ms=(time.time() - t0) * 1000, message=str(exc)[:100])


def check_redis() -> HealthResult:
    t0 = time.time()
    try:
        import redis  # type: ignore
        url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        r = redis.from_url(url, socket_connect_timeout=2, socket_timeout=2)
        r.ping()
        return HealthResult("redis", "ok", latency_ms=(time.time() - t0) * 1000)
    except ImportError:
        return HealthResult("redis", "degraded", message="redis package not installed")
    except Exception as exc:
        return HealthResult("redis", "down", latency_ms=(time.time() - t0) * 1000, message=str(exc)[:100])


def check_notion() -> HealthResult:
    t0 = time.time()
    token = os.getenv("NOTION_TOKEN", "")
    if not token or token == "secret_xxx":
        return HealthResult("notion", "degraded", message="NOTION_TOKEN not configured")
    try:
        import requests
        r = requests.get(
            "https://api.notion.com/v1/users/me",
            headers={"Authorization": f"Bearer {token}", "Notion-Version": "2022-06-28"},
            timeout=5,
        )
        if r.status_code == 200:
            return HealthResult("notion", "ok", latency_ms=(time.time() - t0) * 1000)
        return HealthResult(
            "notion", "degraded",
            latency_ms=(time.time() - t0) * 1000,
            message=f"HTTP {r.status_code}",
        )
    except Exception as exc:
        return HealthResult("notion", "down", latency_ms=(time.time() - t0) * 1000, message=str(exc)[:100])


def check_llm() -> HealthResult:
    has_gemini = bool(os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"))
    has_openai = bool(os.getenv("OPENAI_API_KEY"))
    has_anthropic = bool(os.getenv("ANTHROPIC_API_KEY"))

    if has_gemini or has_openai or has_anthropic:
        providers = [p for p, ok in [("gemini", has_gemini), ("openai", has_openai), ("anthropic", has_anthropic)] if ok]
        return HealthResult("llm", "ok", meta={"providers": providers})
    return HealthResult("llm", "degraded", message="No LLM API keys configured — LLM features disabled")


def check_disk() -> HealthResult:
    t0 = time.time()
    try:
        os.makedirs("out", exist_ok=True)
        probe = os.path.join("out", ".health_probe")
        with open(probe, "w") as f:
            f.write("ok")
        os.remove(probe)

        # Check available space
        stat = os.statvfs("out") if hasattr(os, "statvfs") else None
        free_gb = (stat.f_bavail * stat.f_frsize / 1e9) if stat else None

        meta = {}
        if free_gb is not None:
            meta["free_gb"] = round(free_gb, 1)
            if free_gb < 1.0:
                return HealthResult("disk", "degraded", message=f"Low disk space: {free_gb:.1f}GB free", meta=meta)

        return HealthResult("disk", "ok", latency_ms=(time.time() - t0) * 1000, meta=meta)
    except Exception as exc:
        return HealthResult("disk", "down", latency_ms=(time.time() - t0) * 1000, message=str(exc)[:100])


def check_circuit_breakers() -> HealthResult:
    try:
        from infrastructure.circuit_breaker import all_statuses
        statuses = all_statuses()
        open_breakers = [s["service"] for s in statuses if s["state"] == "open"]
        if open_breakers:
            return HealthResult(
                "circuit_breakers",
                "degraded",
                message=f"Open breakers: {', '.join(open_breakers)}",
                meta={"breakers": statuses},
            )
        return HealthResult("circuit_breakers", "ok", meta={"breakers": statuses})
    except Exception as exc:
        return HealthResult("circuit_breakers", "ok", message="No breakers registered")


# ---------------------------------------------------------------------------
# Aggregator
# ---------------------------------------------------------------------------

_ALL_CHECKS: list[Callable[[], HealthResult]] = [
    check_database,
    check_redis,
    check_notion,
    check_llm,
    check_disk,
    check_circuit_breakers,
]


def run_all_checks() -> dict[str, Any]:
    results = []
    overall = "ok"

    for check_fn in _ALL_CHECKS:
        try:
            result = check_fn()
        except Exception as exc:
            result = HealthResult(check_fn.__name__, "down", message=str(exc)[:100])

        results.append(result.to_dict())

        if result.status == "down":
            overall = "down"
        elif result.status == "degraded" and overall != "down":
            overall = "degraded"

    return {
        "status": overall,
        "checks": results,
        "ts": time.time(),
    }


def liveness() -> dict[str, str]:
    """Minimal liveness probe — just confirms process is alive."""
    return {"status": "ok"}


def readiness() -> dict[str, Any]:
    """Readiness probe — confirms critical deps are up."""
    db = check_database()
    if db.status == "down":
        return {"status": "not_ready", "reason": "database down"}
    return {"status": "ready"}
