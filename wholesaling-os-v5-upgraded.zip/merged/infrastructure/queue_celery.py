from __future__ import annotations
from celery import Celery
from app.settings import settings

celery_app = Celery(
    "wholesaling_os_v4",
    broker=settings.redis_url,
    backend=settings.redis_url,
    include=["infrastructure.worker"],
)
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    enable_utc=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
)
