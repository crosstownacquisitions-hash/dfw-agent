from __future__ import annotations
import redis
from rq import Queue
from app.settings import settings

def get_queue() -> Queue:
    return Queue("default", connection=redis.from_url(settings.redis_url))
