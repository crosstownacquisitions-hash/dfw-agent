from __future__ import annotations

"""Top-level config constants for the Wholesaling OS pipeline.

Values here are the operational defaults. Override via environment variables
or the DB-backed ConfigRepo (config_kv table) for runtime tuning.
"""

import os

# ---------------------------------------------------------------------------
# Buy box — what kinds of deals we pursue
# ---------------------------------------------------------------------------

BUY_BOX = {
    "property_types":   ["SFH", "Duplex", "Triplex", "Quadplex"],
    "max_arv":          600_000,
    "min_arv":          60_000,
    "max_rehab_pct":    0.45,       # rehab / ARV — above this is too risky
    "min_discount_pct": 0.20,       # minimum asking discount vs ARV
    "states":           ["TX"],
    "counties":         [],         # empty = all counties in state
}

# ---------------------------------------------------------------------------
# MAO (Maximum Allowable Offer) config
# ---------------------------------------------------------------------------

MAO_CONFIG = {
    "wholesale_pct":    0.70,       # ARV * this - rehab - assignment_fee
    "assignment_fee":   15_000,
    "flip_sell_pct":    0.08,       # selling costs as % of ARV
    "flip_hold":        15_000,     # holding costs (6 months, rough estimate)
    "flip_profit":      30_000,     # minimum acceptable profit for flip
    "flip_max_pct_cap": 0.80,       # never offer above 80% ARV for flip
}

# ---------------------------------------------------------------------------
# Decision thresholds
# ---------------------------------------------------------------------------

THRESHOLDS = {
    "pursue_offer":          85,    # score >= this → PURSUE_OFFER
    "pursue_if_negotiable":  70,    # score >= this → PURSUE_IF_NEGOTIABLE
    "nurture":               50,    # score >= this → NURTURE
    # below 50 → DISCARD
}

# ---------------------------------------------------------------------------
# Offer strategy
# ---------------------------------------------------------------------------

OFFER_STRATEGY = {
    "lao_pct":          0.85,       # Last Acceptable Offer: MAO * this
    "anchor_pct":       0.75,       # Anchor Offer (open): MAO * this
    "walk_away_pct":    0.95,       # Walk-Away: MAO * this (best case)
    "rounding":         500,        # round offers to nearest $500
}

# ---------------------------------------------------------------------------
# LLM concurrency
# ---------------------------------------------------------------------------

LLM_CONCURRENT: int = int(os.getenv("LLM_CONCURRENT", "3"))
