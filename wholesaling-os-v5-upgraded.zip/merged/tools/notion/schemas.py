from __future__ import annotations

"""Default Notion schema mapping.

If you name properties differently in Notion, update these constants to match.
"""


LEADS = {
    "title": "Address",
    "lead_id": "Lead ID",
    "status": "Status",
    "source": "Source",
    "city": "City",
    "state": "State",
    "zip": "Zip",
    "county": "County",
    "type": "Type",
    "beds": "Beds",
    "baths": "Baths",
    "sqft": "Sqft",
    "year": "Year",
    "asking": "Asking Price",
    "last_touch": "Last Touch",
    "next_action": "Next Action Date",
}


UNDERWRITING = {
    "title": "Deal",
    "lead_relation": "Lead",
    "decision": "Decision",
    "arv": "ARV",
    "rehab": "Rehab",
    "mao_flip": "MAO Flip",
    "mao_wholesale": "MAO Wholesale",
    "score": "Deal Score",
    "notes": "Notes",
}


TASKS = {
    "title": "Task Name",
    "deal_relation": "Deal",
    "type": "Task Type",
    "owner": "Owner",
    "due": "Due Date",
    "status": "Status",
    "outcome": "Outcome",
    "priority": "Priority",
    "address": "Address",
    "best_phone": "Best Phone",
    "attempt": "Attempt #",
    "notes": "Notes",
    "created_by_zap": "Created By Zap",
    "created_time": "Created Time",
}


BUYERS = {
    "title": "Buyer Name",
    "phone": "Phone",
    "email": "Email",
    "cities": "Buy Box Cities",
    "zips": "Zip Focus",
    "strategy": "Strategy",
    "max_price": "Max Price",
    "types": "Asset Types",
    "activity": "Activity Score",
    "last_deal": "Last Deal",
}


DEALROOMS = {
    "title": "Address",
    "status": "Status",
    "tier": "Tier",
    "packet_status": "Packet Status",
    "deal_room_link": "Deal Room Link",
    "google_sheet_row_id": "Google Sheet Row ID",
    "arv": "ARV",
    "repairs": "Repairs",
    "mao": "MAO",
    "equity_pct": "Equity %",
    "close_probability": "Close Probability",
    "buyer_blast_sent": "Buyer Blast Sent",
    "seller_presentation_sent": "Seller Presentation Sent",
}
