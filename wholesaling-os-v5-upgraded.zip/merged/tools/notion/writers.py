from __future__ import annotations

from datetime import date, datetime
from typing import Any

from app.settings import settings
from tools.notion.client import NotionClient
from tools.notion.schemas import DEALROOMS, LEADS, TASKS, UNDERWRITING


def rt(text: str) -> dict:
    return {"rich_text": [{"text": {"content": str(text)}}]}


def title(text: str) -> dict:
    return {"title": [{"text": {"content": str(text)}}]}


def num(v: float | int | None) -> dict:
    return {"number": None if v is None else float(v)}


def sel(v: str | None) -> dict:
    return {"select": None if not v else {"name": str(v)}}


def msel(values: list[str] | None) -> dict:
    vals = values or []
    return {"multi_select": [{"name": str(v)} for v in vals if v]}


def dt(v: datetime | date | None) -> dict:
    if not v:
        return {"date": None}
    if isinstance(v, date) and not isinstance(v, datetime):
        return {"date": {"start": v.isoformat()}}
    return {"date": {"start": v.isoformat()}}


def rel(page_id: str | None) -> dict:
    return {"relation": [] if not page_id else [{"id": page_id}]}


class NotionWriters:
    def __init__(self, client: NotionClient | None = None) -> None:
        self.client = client or NotionClient()

    # --------- Generic helpers
    def _query_equals_rich_text(self, database_id: str, prop_name: str, value: str) -> list[dict]:
        q = {"filter": {"property": prop_name, "rich_text": {"equals": value}}}
        res = self.client.query_database(database_id, q)
        return res.get("results", [])

    def _query_equals_title(self, database_id: str, prop_name: str, value: str) -> list[dict]:
        q = {"filter": {"property": prop_name, "title": {"equals": value}}}
        res = self.client.query_database(database_id, q)
        return res.get("results", [])

    def upsert_by_rich_text(self, database_id: str, prop_name: str, unique_value: str, *, create: dict, update: dict) -> dict:
        rows = self._query_equals_rich_text(database_id, prop_name, unique_value)
        if not rows:
            return self.client.create_page(create)
        return self.client.update_page(rows[0]["id"], update)

    # --------- Leads
    def upsert_lead(self, *, lead_id: str, address: str, fields: dict[str, Any]) -> dict:
        props = {
            LEADS["title"]: title(address),
            LEADS["lead_id"]: rt(lead_id),
        }

        def maybe_set(key: str, notion_prop: str, fn):
            if key in fields and fields[key] is not None and fields[key] != "":
                props[notion_prop] = fn(fields[key])

        maybe_set("status", LEADS["status"], sel)
        maybe_set("source", LEADS["source"], sel)
        maybe_set("city", LEADS["city"], sel)
        maybe_set("state", LEADS["state"], sel)
        maybe_set("zip", LEADS["zip"], rt)
        maybe_set("county", LEADS["county"], sel)
        maybe_set("property_type", LEADS["type"], sel)
        maybe_set("beds", LEADS["beds"], num)
        maybe_set("baths", LEADS["baths"], num)
        maybe_set("sqft", LEADS["sqft"], num)
        maybe_set("year_built", LEADS["year"], num)
        maybe_set("asking_price", LEADS["asking"], num)
        maybe_set("last_touch", LEADS["last_touch"], dt)
        maybe_set("next_action", LEADS["next_action"], dt)

        create_payload = {"parent": {"database_id": settings.notion_db_leads}, "properties": props}
        update_payload = {"properties": props}

        return self.upsert_by_rich_text(
            settings.notion_db_leads,
            LEADS["lead_id"],
            lead_id,
            create=create_payload,
            update=update_payload,
        )

    def update_lead_page(self, page_id: str, properties: dict[str, Any]) -> dict:
        return self.client.update_page(page_id, {"properties": properties})

    # --------- Underwriting
    def create_underwrite(self, *, lead_page_id: str, uw: dict[str, Any]) -> dict:
        """Create an underwriting row linked to a Lead.

        Your Underwriting DB title property is expected to be UNDERWRITING["title"] (default: "Deal").
        We set it to uw["deal_key"] if present, otherwise fall back to the Lead page id.
        """
        deal_title = str(uw.get("deal_key") or uw.get("deal") or uw.get("address") or lead_page_id)
        props = {
            UNDERWRITING["title"]: title(deal_title),
            UNDERWRITING["lead_relation"]: rel(lead_page_id),
            UNDERWRITING["arv"]: num(uw.get("arv") if "arv" in uw else uw.get("arv_est")),
            UNDERWRITING["rehab"]: num(uw.get("rehab") if "rehab" in uw else uw.get("repairs_est")),
            UNDERWRITING["mao_wholesale"]: num(uw.get("mao_wholesale") if "mao_wholesale" in uw else uw.get("mao_wholesale")),
            UNDERWRITING["mao_flip"]: num(uw.get("mao_flip") if "mao_flip" in uw else uw.get("mao_flip")),
            UNDERWRITING["score"]: num(uw.get("score") if "score" in uw else uw.get("deal_score")),
            UNDERWRITING["decision"]: sel(uw.get("decision")),
        }
        if UNDERWRITING.get("notes") and uw.get("notes"):
            props[UNDERWRITING["notes"]] = rt(uw.get("notes"))

        payload = {"parent": {"database_id": settings.notion_db_underwriting}, "properties": props}
        return self.client.create_page(payload)

    # --------- Tasks
    def create_task(
        self,
        *,
        title_text: str,
        lead_page_id: str,
        task_type: str,
        due: datetime | None,
        status: str = "To Do",
        address: str = "",
    ) -> dict:
        """Create a task row linked to a Deal/Lead.

        Your Tasks DB uses property names in tools.notion.schemas.TASKS (e.g., title="Task Name", relation="Deal").
        We link TASKS["deal_relation"] to the passed lead_page_id (your 'Deal' relation).
        """
        props = {
            TASKS["title"]: title(title_text),
            TASKS["deal_relation"]: rel(lead_page_id),
            TASKS["type"]: sel(task_type),
            TASKS["due"]: dt(due),
            TASKS["status"]: sel(status),
        }
        if address and TASKS.get("address"):
            props[TASKS["address"]] = rt(address)

        payload = {"parent": {"database_id": settings.notion_db_tasks}, "properties": props}
        return self.client.create_page(payload)

    # --------- Deal Rooms
    def create_dealroom(
        self,
        *,
        title_text: str,
        lead_page_id: str | None = None,
        numbers_summary: str = "",
        access_info: str = "",
        packet_status: str = "Draft",
        tier: str = "",
        status: str = "",
        deal_room_link: str = "",
    ) -> dict:
        """Create a Deal Room row.

        Your Deal Rooms DB property names are in tools.notion.schemas.DEALROOMS.
        The title property is expected to be "Address".
        """
        props = {
            DEALROOMS["title"]: title(title_text),
        }
        # Optional fields if you use them
        if status and DEALROOMS.get("status"):
            props[DEALROOMS["status"]] = sel(status)
        if tier and DEALROOMS.get("tier"):
            props[DEALROOMS["tier"]] = sel(tier)
        if packet_status and DEALROOMS.get("packet_status"):
            props[DEALROOMS["packet_status"]] = sel(packet_status)
        if deal_room_link and DEALROOMS.get("deal_room_link"):
            props[DEALROOMS["deal_room_link"]] = rt(deal_room_link)

        payload = {"parent": {"database_id": settings.notion_db_dealrooms}, "properties": props}
        return self.client.create_page(payload)
