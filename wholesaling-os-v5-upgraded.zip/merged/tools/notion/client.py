from __future__ import annotations
import requests
from app.settings import settings

NOTION_VERSION = "2022-06-28"

class NotionClient:
    def __init__(self, token: str | None = None) -> None:
        self.token = token or settings.notion_token
        if not self.token:
            raise ValueError("NOTION_TOKEN missing")
        self.base = "https://api.notion.com/v1"

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.token}",
            "Notion-Version": NOTION_VERSION,
            "Content-Type": "application/json",
        }

    def query_database(self, database_id: str, payload: dict) -> dict:
        r = requests.post(f"{self.base}/databases/{database_id}/query", headers=self._headers(), json=payload, timeout=60)
        r.raise_for_status()
        return r.json()

    def create_page(self, payload: dict) -> dict:
        r = requests.post(f"{self.base}/pages", headers=self._headers(), json=payload, timeout=60)
        r.raise_for_status()
        return r.json()

    def update_page(self, page_id: str, payload: dict) -> dict:
        r = requests.patch(f"{self.base}/pages/{page_id}", headers=self._headers(), json=payload, timeout=60)
        r.raise_for_status()
        return r.json()
