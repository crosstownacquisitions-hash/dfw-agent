from __future__ import annotations

from typing import Any

from app.settings import settings
from tools.notion.client import NotionClient
from tools.notion.schemas import LEADS


def _get_plain_text(prop: dict) -> str | None:
    if not prop:
        return None
    t = prop.get("title") or prop.get("rich_text") or []
    if not t:
        return None
    return "".join([x.get("plain_text", "") for x in t]).strip() or None


def _get_select(prop: dict) -> str | None:
    s = (prop or {}).get("select")
    return s.get("name") if s else None


def _get_number(prop: dict) -> float | None:
    return (prop or {}).get("number")


def parse_lead_page(page: dict) -> dict[str, Any]:
    props = page.get("properties", {})
    return {
        "page_id": page.get("id"),
        "lead_id": _get_plain_text(props.get(LEADS["lead_id"])),
        "address": _get_plain_text(props.get(LEADS["title"])) or "",
        "status": _get_select(props.get(LEADS["status"])) or "New",
        "source": _get_select(props.get(LEADS["source"])) or "",
        "city": _get_select(props.get(LEADS["city"])) or "",
        "state": _get_select(props.get(LEADS["state"])) or "TX",
        "zip": _get_plain_text(props.get(LEADS["zip"])) or "",
        "county": _get_select(props.get(LEADS["county"])) or "",
        "property_type": _get_select(props.get(LEADS["type"])) or "SFH",
        "beds": _get_number(props.get(LEADS["beds"])),
        "baths": _get_number(props.get(LEADS["baths"])),
        "sqft": _get_number(props.get(LEADS["sqft"])),
        "year_built": _get_number(props.get(LEADS["year"])),
        "asking_price": _get_number(props.get(LEADS["asking"])),
    }


class NotionReaders:
    def __init__(self, client: NotionClient | None = None) -> None:
        self.client = client or NotionClient()

    def fetch_new_leads(self, limit: int = 100) -> list[dict[str, Any]]:
        # Status select equals "New" by default.
        q = {
            "page_size": min(limit, 100),
            "filter": {"property": LEADS["status"], "select": {"equals": "New"}},
        }
        res = self.client.query_database(settings.notion_db_leads, q)
        leads = [parse_lead_page(p) for p in res.get("results", [])]
        # If lead_id missing, we still process but generate internal ID.
        return leads[:limit]
