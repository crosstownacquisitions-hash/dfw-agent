from __future__ import annotations

"""Redis-backed function cache with in-process LRU fallback.

Usage
-----
from tools.cache.redis_cache import cached

@cached(ttl=86400, key_prefix="comps")
def get_comps(address: str, zip_code: str) -> list[dict]:
    ...

When Redis is unavailable the decorator falls back to a bounded in-process
dict so the service degrades gracefully (slower but functional).
"""

import functools
import hashlib
import json
import logging
import os
import time
from collections import OrderedDict
from typing import Any, Callable, TypeVar

log = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])

# ---------------------------------------------------------------------------
# In-process LRU fallback
# ---------------------------------------------------------------------------

class _LRUCache:
    def __init__(self, maxsize: int = 512):
        self._store: OrderedDict[str, tuple[Any, float]] = OrderedDict()
        self.maxsize = maxsize

    def get(self, key: str, ttl: int) -> tuple[bool, Any]:
        if key not in self._store:
            return False, None
        val, stored_at = self._store[key]
        if time.time() - stored_at > ttl:
            del self._store[key]
            return False, None
        self._store.move_to_end(key)
        return True, val

    def set(self, key: str, value: Any) -> None:
        self._store[key] = (value, time.time())
        self._store.move_to_end(key)
        if len(self._store) > self.maxsize:
            self._store.popitem(last=False)


_local_cache = _LRUCache(maxsize=1024)


# ---------------------------------------------------------------------------
# Redis client (lazy init)
# ---------------------------------------------------------------------------

_redis_client = None
_redis_unavailable = False


def _get_redis():
    global _redis_client, _redis_unavailable
    if _redis_unavailable:
        return None
    if _redis_client is not None:
        return _redis_client
    try:
        import redis  # type: ignore
        url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        _redis_client = redis.from_url(url, socket_connect_timeout=2, socket_timeout=2)
        _redis_client.ping()
        log.debug("Redis cache connected")
        return _redis_client
    except Exception as exc:
        log.warning("Redis unavailable (%s) — using in-process LRU cache", exc)
        _redis_unavailable = True
        return None


# ---------------------------------------------------------------------------
# Key construction
# ---------------------------------------------------------------------------

def _make_key(prefix: str, args: tuple, kwargs: dict) -> str:
    payload = json.dumps({"args": args, "kwargs": kwargs}, sort_keys=True, default=str)
    digest = hashlib.sha256(payload.encode()).hexdigest()[:20]
    return f"cache:{prefix}:{digest}"


# ---------------------------------------------------------------------------
# Decorator
# ---------------------------------------------------------------------------

def cached(ttl: int = 3600, key_prefix: str = "fn") -> Callable[[F], F]:
    """Cache return value in Redis (or local LRU fallback) for `ttl` seconds."""

    def decorator(fn: F) -> F:
        prefix = key_prefix or fn.__qualname__

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            key = _make_key(prefix, args, kwargs)
            r = _get_redis()

            # -- Try Redis --
            if r is not None:
                try:
                    raw = r.get(key)
                    if raw is not None:
                        return json.loads(raw)
                except Exception:
                    pass

            # -- Try local LRU --
            hit, val = _local_cache.get(key, ttl)
            if hit:
                return val

            # -- Miss: call function --
            result = fn(*args, **kwargs)

            # -- Store in Redis --
            if r is not None:
                try:
                    r.setex(key, ttl, json.dumps(result, default=str))
                except Exception:
                    pass

            # -- Store locally --
            _local_cache.set(key, result)
            return result

        wrapper.cache_clear = lambda: None  # noqa: E731 (stub for compatibility)
        return wrapper  # type: ignore

    return decorator


def invalidate(key_prefix: str, *args: Any, **kwargs: Any) -> None:
    """Explicitly invalidate a cache entry."""
    key = _make_key(key_prefix, args, kwargs)
    r = _get_redis()
    if r is not None:
        try:
            r.delete(key)
        except Exception:
            pass
    # Local cache — just let it expire
