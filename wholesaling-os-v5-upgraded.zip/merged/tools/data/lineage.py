from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any

from tools.data.repo import SessionLocal
from tools.data.models import Lineage


def _checksum(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def record_lineage(
    *,
    lead_id: str,
    run_id: str,
    entity: str,
    field: str,
    value: Any,
    sources: list[dict[str, Any]] | None,
    selected_by: str,
) -> None:
    now = datetime.now(timezone.utc)
    with SessionLocal() as s:
        s.add(
            Lineage(
                lead_id=lead_id,
                run_id=run_id,
                entity=entity,
                field=field,
                value=value,
                sources=sources,
                selected_by=selected_by,
                value_checksum=_checksum(value),
                created_at=now,
            )
        )
        s.commit()
