from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.settings import settings
from tools.data.storage import engine, SessionLocal
from tools.data.models import Base, ConfigKV, Lead, Outcome, Run, Underwrite


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def init_db() -> None:
    Base.metadata.create_all(bind=engine)


class RunsRepo:
    def create_run(self, run_id: str, goal: str, started_at: datetime) -> None:
        with SessionLocal() as s:
            s.merge(Run(run_id=run_id, goal=goal, started_at=started_at))
            s.commit()

    def finish_run(self, run_id: str, finished_at: datetime, summary: dict) -> None:
        with SessionLocal() as s:
            r = s.get(Run, run_id)
            if not r:
                r = Run(run_id=run_id, goal="", started_at=finished_at)
            r.finished_at = finished_at
            r.summary = summary
            s.merge(r)
            s.commit()


class LeadsRepo:
    def upsert(self, *, lead_id: str, **fields) -> Lead:
        with SessionLocal() as s:
            existing = s.get(Lead, lead_id)
            now = utcnow()
            if existing:
                for k, v in fields.items():
                    setattr(existing, k, v)
                existing.updated_at = now
                s.merge(existing)
                s.commit()
                s.refresh(existing)
                return existing

            lead = Lead(
                lead_id=lead_id,
                created_at=now,
                updated_at=now,
                **fields,
            )
            s.add(lead)
            s.commit()
            s.refresh(lead)
            return lead

    def set_status(self, lead_id: str, status: str) -> None:
        with SessionLocal() as s:
            lead = s.get(Lead, lead_id)
            if not lead:
                return
            lead.status = status
            lead.updated_at = utcnow()
            s.merge(lead)
            s.commit()


class UnderwriteRepo:
    def add(self, *, lead_id: str, run_id: str, **fields) -> Underwrite:
        with SessionLocal() as s:
            uw = Underwrite(lead_id=lead_id, run_id=run_id, created_at=utcnow(), **fields)
            s.add(uw)
            s.commit()
            s.refresh(uw)
            return uw


class OutcomeRepo:
    def add(self, *, lead_id: str, run_id: str, event: str, value: float | None = None, meta: dict | None = None) -> None:
        with SessionLocal() as s:
            s.add(Outcome(lead_id=lead_id, run_id=run_id, event=event, value=value, meta=meta, created_at=utcnow()))
            s.commit()


class ConfigRepo:
    def get(self, key: str, default: dict | None = None) -> dict:
        with SessionLocal() as s:
            row = s.get(ConfigKV, key)
            return row.value if row else (default or {})

    def set(self, key: str, value: dict) -> None:
        with SessionLocal() as s:
            s.merge(ConfigKV(key=key, value=value, updated_at=utcnow()))
            s.commit()
