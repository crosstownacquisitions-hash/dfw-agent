from __future__ import annotations

"""Minimal Notion API wrapper (stable, low-dependency).

This file intentionally does NOT depend on app.settings, Pydantic, or other internal layers.
It reads NOTION_TOKEN from the environment by default.

Endpoints used:
- GET /databases/{database_id}
- POST /databases/{database_id}/query
- POST /pages
- PATCH /pages/{page_id}
"""

import os
import requests
import time
from typing import Optional, Dict, Any

NOTION_VERSION = "2022-06-28"


class NotionClient:
    def __init__(self, token: Optional[str] = None):
        self.token = (token or os.getenv("NOTION_TOKEN", "")).strip()
        if not self.token:
            raise RuntimeError("Missing NOTION_TOKEN")

        self.base = "https://api.notion.com/v1"
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Notion-Version": NOTION_VERSION,
            "Content-Type": "application/json",
        }

    def _req(self, method: str, path: str, json: Optional[dict] = None, timeout: int = 30) -> dict:
        """HTTP request with basic 429 backoff + retry.

        Notion rate limits are common during backfills. We honor Retry-After when present.
        """
        url = f"{self.base}{path}"

        max_tries = 4
        backoff = 1.2

        for attempt in range(max_tries):
            r = requests.request(method, url, headers=self.headers, json=json, timeout=timeout)

            # Rate limited
            if r.status_code == 429:
                retry_after = r.headers.get("retry-after")
                sleep_s = float(retry_after) if retry_after else (backoff ** attempt)
                time.sleep(min(sleep_s, 20.0))
                continue

            if r.status_code >= 400:
                raise RuntimeError(f"Notion {r.status_code}: {r.text[:800]}")

            return r.json()

        raise RuntimeError("Notion 429: rate limited repeatedly; try again later.")

    def get_database(self, database_id: str) -> dict:
        return self._req("GET", f"/databases/{database_id}", json=None)

    def retrieve_database(self, database_id: str) -> dict:
        return self._req("GET", f"/databases/{database_id}", json=None)

    def query_database(self, database_id: str, payload: dict) -> dict:
        return self._req("POST", f"/databases/{database_id}/query", json=payload)

    def create_page(self, payload: dict) -> dict:
        return self._req("POST", "/pages", json=payload)

    def update_page(self, page_id: str, payload: dict) -> dict:
        return self._req("PATCH", f"/pages/{page_id}", json=payload)
