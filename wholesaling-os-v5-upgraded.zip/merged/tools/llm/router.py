from __future__ import annotations

import os
import time
from typing import Any

from litellm import completion

from app.settings import settings
from app.logger import get_logger

log = get_logger(__name__)


def _fallback_models(primary: str) -> list[str]:
    raw = os.getenv("LLM_FALLBACK_MODELS", "")
    models = [m.strip() for m in raw.split(",") if m.strip()]
    return [primary] + [m for m in models if m != primary]


def llm_complete(
    messages: list[dict],
    model: str | None = None,
    *,
    temperature: float = 0.2,
    max_tokens: int = 700,
    retries: int = 2,
    timeout_s: int = 60,
    **kwargs: Any,
) -> dict:
    """LiteLLM completion with ordered fallbacks + retry.

    Set provider keys in env (e.g., GEMINI_API_KEY, OPENAI_API_KEY, ANTHROPIC_API_KEY)
    per LiteLLM.
    """

    primary = model or settings.default_llm_model
    candidates = _fallback_models(primary)
    last_err: Exception | None = None

    for m in candidates:
        for attempt in range(retries + 1):
            try:
                t0 = time.time()
                resp = completion(
                    model=m,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    timeout=timeout_s,
                    **kwargs,
                )
                log.info(
                    "LLM ok",
                    extra={"model": m, "latency_ms": int((time.time() - t0) * 1000), "attempt": attempt},
                )
                return resp
            except Exception as e:
                last_err = e
                log.warning(
                    "LLM failed",
                    extra={"model": m, "attempt": attempt, "error": str(e)[:300]},
                )
                # brief backoff
                time.sleep(min(1.5 * (attempt + 1), 4.0))
                continue

    raise RuntimeError(f"All LLM models failed. Last error: {last_err}")
