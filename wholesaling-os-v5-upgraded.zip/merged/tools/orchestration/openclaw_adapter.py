from __future__ import annotations

"""Optional OpenClaw integration.

OpenClaw is not required to run this system today. The production-grade pattern
here is: deterministic workflows + background queue + tool adapters.

If you install OpenClaw later, this adapter is where you wire:
  - goal planning
  - agent selection
  - multi-step task graphs
"""

from app.logger import get_logger

log = get_logger(__name__)


def openclaw_available() -> bool:
    try:
        import openclaw  # type: ignore

        _ = openclaw
        return True
    except Exception:
        return False


def run_goal_with_openclaw(goal: str) -> dict:
    if not openclaw_available():
        raise RuntimeError("OpenClaw not installed. Add it to dependencies to use this adapter.")

    # TODO: implement: build OpenClaw agents + tools, then execute.
    log.info("OpenClaw adapter called", extra={"goal": goal})
    return {"status": "todo", "goal": goal}
