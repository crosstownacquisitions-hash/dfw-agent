from __future__ import annotations

"""Data lineage tracker.

Every computed field (ARV, rehab, MAO, score) records:
- Which sources contributed (comps_api, model_estimate, goliath, csv, etc.)
- How values were merged (blend, max_haircut, single_source, consensus)
- Per-source confidence
- Final selected value and method

This gives full auditability: "Where did that $187k ARV come from?"

Usage
-----
lineage = LineageGraph()
lineage.record("lead_abc", "arv", sources=[
    LineageSource("comps_api", 185000, confidence=0.85),
    LineageSource("model_estimate", 192000, confidence=0.55),
], selected_value=187200, method="weighted_consensus")

report = lineage.report("lead_abc")
"""

import hashlib
import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any

log = logging.getLogger(__name__)

_LINEAGE_DIR = os.path.join("out", "lineage")


@dataclass
class LineageSource:
    provider: str        # "comps_api" | "goliath" | "model_estimate" | "csv" | "llm"
    raw_value: Any
    confidence: float    # 0–1
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class LineageRecord:
    lead_id: str
    field_name: str
    sources: list[LineageSource]
    selected_value: Any
    method: str          # "weighted_consensus" | "single_source" | "blend" | "max_haircut" | "llm_only"
    checksum: str = ""
    ts: float = field(default_factory=time.time)

    def __post_init__(self):
        if not self.checksum:
            raw = f"{self.lead_id}:{self.field_name}:{self.selected_value}:{self.method}"
            self.checksum = hashlib.sha256(raw.encode()).hexdigest()[:16]

    def to_dict(self) -> dict[str, Any]:
        return {
            "lead_id": self.lead_id,
            "field": self.field_name,
            "selected_value": self.selected_value,
            "method": self.method,
            "checksum": self.checksum,
            "ts": self.ts,
            "sources": [
                {
                    "provider": s.provider,
                    "raw_value": s.raw_value,
                    "confidence": s.confidence,
                    "meta": s.meta,
                }
                for s in self.sources
            ],
        }


class LineageGraph:
    """In-memory lineage graph with disk persistence per lead."""

    def __init__(self):
        self._records: dict[str, list[LineageRecord]] = {}
        os.makedirs(_LINEAGE_DIR, exist_ok=True)

    def record(
        self,
        lead_id: str,
        field_name: str,
        sources: list[LineageSource],
        selected_value: Any,
        method: str,
    ) -> LineageRecord:
        rec = LineageRecord(
            lead_id=lead_id,
            field_name=field_name,
            sources=sources,
            selected_value=selected_value,
            method=method,
        )
        self._records.setdefault(lead_id, []).append(rec)
        self._persist(lead_id)
        return rec

    def report(self, lead_id: str) -> list[dict[str, Any]]:
        return [r.to_dict() for r in self._records.get(lead_id, [])]

    def verify_checksum(self, lead_id: str, field_name: str, value: Any, method: str) -> bool:
        """Verify a field's provenance checksum hasn't been tampered with."""
        raw = f"{lead_id}:{field_name}:{value}:{method}"
        expected = hashlib.sha256(raw.encode()).hexdigest()[:16]
        for rec in self._records.get(lead_id, []):
            if rec.field_name == field_name:
                return rec.checksum == expected
        return False

    def _persist(self, lead_id: str) -> None:
        path = os.path.join(_LINEAGE_DIR, f"{lead_id}.json")
        try:
            data = [r.to_dict() for r in self._records[lead_id]]
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception as exc:
            log.warning("Lineage persist failed for %s: %s", lead_id, exc)


# ---------------------------------------------------------------------------
# Weighted consensus ARV (replaces simple LLM estimate)
# ---------------------------------------------------------------------------

def consensus_arv(
    lead_id: str,
    lineage: LineageGraph,
    *,
    comps_arv: float | None = None,
    comps_confidence: float = 0.0,
    model_arv: float | None = None,
    model_confidence: float = 0.0,
    avm: float | None = None,
    avm_confidence: float = 0.6,
    blend_threshold_pct: float = 0.20,
    haircut: float = 0.05,
) -> tuple[float | None, float, str]:
    """Return (arv, confidence, method) using a priority-weighted consensus.

    Priority ladder:
      1. comps_api (highest — real sold data)
      2. AVM / market value
      3. model_estimate (LLM or heuristic)

    Blend if values within blend_threshold_pct; apply haircut if divergent.
    """
    sources: list[LineageSource] = []
    candidates: list[tuple[float, float]] = []  # (value, weight)

    if comps_arv and comps_arv > 0:
        sources.append(LineageSource("comps_api", comps_arv, comps_confidence))
        candidates.append((comps_arv, comps_confidence * 1.5))  # extra weight for real comps

    if avm and avm > 0:
        sources.append(LineageSource("avm", avm, avm_confidence))
        candidates.append((avm, avm_confidence))

    if model_arv and model_arv > 0:
        sources.append(LineageSource("model_estimate", model_arv, model_confidence))
        candidates.append((model_arv, model_confidence))

    if not candidates:
        return None, 0.0, "no_sources"

    if len(candidates) == 1:
        val, conf = candidates[0]
        lineage.record(lead_id, "arv", sources, val, "single_source")
        return val, conf, "single_source"

    values = [v for v, _ in candidates]
    max_v, min_v = max(values), min(values)

    if max_v <= 0:
        return None, 0.0, "no_sources"

    divergence = (max_v - min_v) / max_v

    if divergence <= blend_threshold_pct:
        # Blend with confidence weights
        total_w = sum(w for _, w in candidates)
        blended = sum(v * w for v, w in candidates) / total_w if total_w > 0 else max_v
        final_conf = min(sum(c for _, c in candidates) / len(candidates) + 0.10, 0.95)
        method = "weighted_blend"
        result = round(blended, -2)
    else:
        # Divergent — take the highest-confidence value with a safety haircut
        best = max(candidates, key=lambda x: x[1])
        result = round(best[0] * (1.0 - haircut), -2)
        final_conf = best[1] * 0.85  # penalize for divergence
        method = "max_confidence_haircut"

    lineage.record(lead_id, "arv", sources, result, method)
    return result, final_conf, method
