from __future__ import annotations

"""Goliath AVM provider — wired third-party valuation source.

Uses httpx with tenacity exponential-backoff retries and a lightweight
circuit breaker. Joins the ARV weighted_consensus() automatically when
GOLIATH_BASE_URL and GOLIATH_API_KEY are set in the environment.
Returns a no-op dict when unconfigured so callers need no conditional logic.
"""

from dataclasses import dataclass
from typing import Any

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from app.settings import settings
from tools.cache.redis_cache import cached
from tools.circuit_breaker import CircuitBreaker

_cb = CircuitBreaker(failure_threshold=4, reset_timeout_s=45)


@dataclass
class GoliathAVM:
    arv: float | None
    confidence: float | None
    meta: dict


@cached(ttl=86400, key_prefix="goliath_avm")
def get_avm(address: str, city: str = "", state: str = "TX", zip_code: str = "") -> dict:
    """Get an AVM valuation from Goliath (if configured).

    Returns a dict with keys: arv, confidence, meta.
    When Goliath is not configured or the circuit is open, arv is None.
    """
    if not settings.goliath_base_url:
        return {"arv": None, "confidence": None, "meta": {"provider": "none"}}
    if not _cb.allow():
        return {"arv": None, "confidence": None, "meta": {"error": "circuit_open"}}

    try:
        data = _call("/avm", {"address": address, "city": city, "state": state, "zip": zip_code})
        _cb.on_success()
        return {
            "arv": data.get("arv"),
            "confidence": data.get("confidence"),
            "meta": {
                "provider": "goliath",
                "raw": {k: v for k, v in data.items() if k not in {"arv", "confidence"}},
            },
        }
    except Exception as e:
        _cb.on_failure()
        return {"arv": None, "confidence": None, "meta": {"error": str(e)}}


@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=0.5, min=0.5, max=4))
def _call(path: str, payload: dict[str, Any]) -> dict:
    url = settings.goliath_base_url.rstrip("/") + path
    headers = {"Authorization": f"Bearer {settings.goliath_api_key}"} if settings.goliath_api_key else {}
    with httpx.Client(timeout=20) as client:
        r = client.post(url, json=payload, headers=headers)
        r.raise_for_status()
        return r.json()
