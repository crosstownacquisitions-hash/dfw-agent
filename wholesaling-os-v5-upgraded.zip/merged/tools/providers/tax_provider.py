# TODO: tax/owner provider adapter
