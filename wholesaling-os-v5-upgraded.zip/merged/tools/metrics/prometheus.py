from __future__ import annotations

"""Prometheus metrics for Wholesaling OS.

Business metrics
----------------
  leads_processed_total          counter
  leads_pursued_total            counter
  offers_generated_total         counter
  avg_deal_score                 gauge
  avg_assignment_spread_dollars  gauge

Technical metrics
-----------------
  pipeline_duration_seconds      histogram
  llm_call_duration_seconds      histogram
  llm_cache_hits_total           counter
  notion_api_errors_total        counter
  queue_depth                    gauge

SLA metrics
-----------
  lead_to_offer_seconds          histogram (time from ingest to first offer)
  run_success_rate               gauge

Exposes /metrics endpoint for Prometheus scraping.
"""

from __future__ import annotations

import logging
import os
import time
from contextlib import contextmanager

log = logging.getLogger(__name__)

_ENABLED = False
_metrics: dict = {}


def _init_metrics():
    global _ENABLED, _metrics
    try:
        from prometheus_client import Counter, Gauge, Histogram, CollectorRegistry

        reg = CollectorRegistry()

        _metrics = {
            # Business
            "leads_processed": Counter(
                "leads_processed_total",
                "Total leads processed",
                ["decision"],
                registry=reg,
            ),
            "offers_generated": Counter(
                "offers_generated_total",
                "Total offer strategies generated",
                registry=reg,
            ),
            "avg_deal_score": Gauge(
                "avg_deal_score",
                "Rolling average deal score (last run)",
                registry=reg,
            ),
            "avg_assignment_spread": Gauge(
                "avg_assignment_spread_dollars",
                "Average assignment fee spread in dollars (last run)",
                registry=reg,
            ),
            # Technical
            "pipeline_duration": Histogram(
                "pipeline_duration_seconds",
                "End-to-end pipeline duration",
                buckets=[30, 60, 120, 300, 600, 1200],
                registry=reg,
            ),
            "llm_call_duration": Histogram(
                "llm_call_duration_seconds",
                "LLM call latency",
                buckets=[0.5, 1, 2, 5, 10, 20, 30],
                registry=reg,
            ),
            "llm_cache_hits": Counter(
                "llm_cache_hits_total",
                "LLM prompt cache hits",
                registry=reg,
            ),
            "notion_errors": Counter(
                "notion_api_errors_total",
                "Notion API errors",
                ["operation"],
                registry=reg,
            ),
            "queue_depth": Gauge(
                "queue_depth",
                "Current task queue depth",
                ["queue_name"],
                registry=reg,
            ),
            # SLA
            "lead_to_offer": Histogram(
                "lead_to_offer_seconds",
                "Time from lead ingest to offer generation",
                buckets=[60, 120, 300, 600, 1800, 3600],
                registry=reg,
            ),
            "run_success_rate": Gauge(
                "run_success_rate",
                "Fraction of recent runs completing without high-severity flags",
                registry=reg,
            ),
        }
        _metrics["_registry"] = reg
        _ENABLED = True
        log.info("Prometheus metrics initialized")
    except ImportError:
        log.info("prometheus_client not installed — metrics disabled")
    except Exception as exc:
        log.warning("Metrics init failed: %s", exc)


_init_metrics()


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

def record_leads_processed(decision: str, count: int = 1) -> None:
    if not _ENABLED:
        return
    try:
        _metrics["leads_processed"].labels(decision=decision).inc(count)
    except Exception:
        pass


def record_offer_generated(count: int = 1) -> None:
    if not _ENABLED:
        return
    try:
        _metrics["offers_generated"].inc(count)
    except Exception:
        pass


def set_avg_deal_score(score: float) -> None:
    if not _ENABLED:
        return
    try:
        _metrics["avg_deal_score"].set(score)
    except Exception:
        pass


def set_avg_spread(spread: float) -> None:
    if not _ENABLED:
        return
    try:
        _metrics["avg_assignment_spread"].set(spread)
    except Exception:
        pass


def record_notion_error(operation: str) -> None:
    if not _ENABLED:
        return
    try:
        _metrics["notion_errors"].labels(operation=operation).inc()
    except Exception:
        pass


def set_queue_depth(queue_name: str, depth: int) -> None:
    if not _ENABLED:
        return
    try:
        _metrics["queue_depth"].labels(queue_name=queue_name).set(depth)
    except Exception:
        pass


def set_run_success_rate(rate: float) -> None:
    if not _ENABLED:
        return
    try:
        _metrics["run_success_rate"].set(rate)
    except Exception:
        pass


def record_llm_cache_hit() -> None:
    if not _ENABLED:
        return
    try:
        _metrics["llm_cache_hits"].inc()
    except Exception:
        pass


@contextmanager
def time_pipeline():
    """Context manager to time the full pipeline run."""
    t0 = time.time()
    try:
        yield
    finally:
        if _ENABLED:
            try:
                _metrics["pipeline_duration"].observe(time.time() - t0)
            except Exception:
                pass


@contextmanager
def time_llm_call():
    """Context manager to time an LLM call."""
    t0 = time.time()
    try:
        yield
    finally:
        if _ENABLED:
            try:
                _metrics["llm_call_duration"].observe(time.time() - t0)
            except Exception:
                pass


def record_lead_to_offer(seconds: float) -> None:
    if not _ENABLED:
        return
    try:
        _metrics["lead_to_offer"].observe(seconds)
    except Exception:
        pass


def get_registry():
    """Return the Prometheus CollectorRegistry for use in FastAPI /metrics endpoint."""
    return _metrics.get("_registry") if _ENABLED else None


def record_run_summary(summary: dict) -> None:
    """Convenience: record all business metrics from a pipeline summary dict."""
    for decision in ("PURSUE_OFFER", "PURSUE_IF_NEGOTIABLE", "NURTURE", "DISCARD", "NEEDS_REVIEW"):
        key_map = {
            "PURSUE_OFFER": "pursued",
            "PURSUE_IF_NEGOTIABLE": "pursued",
            "NURTURE": "nurtured",
            "DISCARD": "discarded",
            "NEEDS_REVIEW": "needs_review",
        }
        cnt = summary.get(key_map.get(decision, ""), 0)
        if cnt:
            record_leads_processed(decision, cnt)

    if "avg_score" in summary:
        set_avg_deal_score(summary["avg_score"])
    if "avg_spread" in summary:
        set_avg_spread(summary["avg_spread"])
