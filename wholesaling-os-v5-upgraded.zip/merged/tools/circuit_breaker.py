from __future__ import annotations

from dataclasses import dataclass
from time import monotonic


@dataclass
class CircuitBreaker:
    failure_threshold: int = 5
    reset_timeout_s: int = 60

    failures: int = 0
    opened_at: float | None = None

    def allow(self) -> bool:
        if self.opened_at is None:
            return True
        # half-open after timeout
        return (monotonic() - self.opened_at) > self.reset_timeout_s

    def on_success(self) -> None:
        self.failures = 0
        self.opened_at = None

    def on_failure(self) -> None:
        self.failures += 1
        if self.failures >= self.failure_threshold:
            self.opened_at = monotonic()
