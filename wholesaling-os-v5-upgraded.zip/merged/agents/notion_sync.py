from __future__ import annotations

import os
import logging
import re
from datetime import date, datetime
from typing import Any, Dict, Optional, Tuple, List

from tools.notion_client import NotionClient
from .hash_utils import row_hash

log = logging.getLogger(__name__)

NOTION_DB_LEADS = os.getenv("NOTION_DB_LEADS", "").strip()
NOTION_DB_UNDERWRITING = os.getenv("NOTION_DB_UNDERWRITING", "").strip()
NOTION_DB_TASKS = os.getenv("NOTION_DB_TASKS", "").strip()
NOTION_DB_DEALROOMS = os.getenv("NOTION_DB_DEALROOMS", "").strip()

_HASH_RE = re.compile(r"\[hash:([0-9a-f]{12,64})\]\s*$", re.IGNORECASE)


def _strip_hash_suffix(text: str) -> str:
    t = (text or "").rstrip()
    return _HASH_RE.sub("", t).rstrip()


def _extract_hash(text: str) -> str:
    t = (text or "").strip()
    m = _HASH_RE.search(t)
    return (m.group(1) or "").strip() if m else ""


def _append_hash(text: str, h: str) -> str:
    base = _strip_hash_suffix(text)
    if not base:
        return f"[hash:{h}]"
    return base + "\n\n" + f"[hash:{h}]"


def _safe_rich_text(page: dict, prop_name: str) -> str:
    p = (page.get("properties") or {}).get(prop_name) or {}
    arr = p.get("rich_text") or []
    if arr:
        return (arr[0].get("plain_text") or "").strip()
    return ""


def _safe_title(page: dict, prop_name: str) -> str:
    p = (page.get("properties") or {}).get(prop_name) or {}
    arr = p.get("title") or []
    if arr:
        return (arr[0].get("plain_text") or "").strip()
    return ""


class NotionSync:
    """Canonical -> Notion sync with idempotent upserts.

    Key design points:
    - We retrieve DB schemas once and serialize values based on Notion property types.
    - Leads idempotency: store hash in Leads -> 'Last Updated' (rich_text).
    - Underwriting idempotency: store hash suffix in Underwriting -> 'Notes' (rich_text).
    - Deal Rooms idempotency: compare existing properties to intended; skip if no deltas.
    - Tasks idempotency: store hash suffix in Tasks -> 'Notes' (rich_text).
    """

    def __init__(self):
        self.client = NotionClient()
        self._db_prop_types: Dict[str, Dict[str, str]] = {}

    # ─────────────────────────────────────────────────────────────
    # Schema helpers
    # ─────────────────────────────────────────────────────────────
    def _ensure_schema_cached(self, database_id: str) -> None:
        if not database_id:
            return
        if database_id in self._db_prop_types:
            return
        db = self.client.retrieve_database(database_id)
        props = db.get("properties") or {}
        self._db_prop_types[database_id] = {name: (v.get("type") or "") for name, v in props.items()}

    def _ptype(self, database_id: str, prop_name: str) -> str:
        self._ensure_schema_cached(database_id)
        return (self._db_prop_types.get(database_id, {}) or {}).get(prop_name, "")

    def _serialize(self, ptype: str, value: Any) -> Optional[dict]:
        # Skip empties by default (keeps existing values unless explicitly overwritten)
        if value is None:
            return None
        if isinstance(value, str) and value.strip() == "":
            return None

        if ptype == "title":
            return {"title": [{"type": "text", "text": {"content": str(value)}}]}
        if ptype == "rich_text":
            return {"rich_text": [{"type": "text", "text": {"content": str(value)}}]}
        if ptype == "number":
            try:
                return {"number": float(value)}
            except Exception:
                return {"number": None}
        if ptype == "select":
            return {"select": {"name": str(value)}}
        if ptype == "multi_select":
            vals = value if isinstance(value, list) else [str(value)]
            return {"multi_select": [{"name": str(v)} for v in vals if str(v).strip()]}
        if ptype == "checkbox":
            return {"checkbox": bool(value)}
        if ptype == "url":
            return {"url": str(value)}
        if ptype == "date":
            if isinstance(value, (datetime, date)):
                return {"date": {"start": value.isoformat()}}
            # assume ISO-like
            return {"date": {"start": str(value)}}
        if ptype == "relation":
            # value can be a page id str or list[str]
            if isinstance(value, list):
                ids = [str(v) for v in value if v]
            else:
                ids = [str(value)]
            return {"relation": [{"id": pid} for pid in ids if pid]}
        if ptype in {"created_time", "created_by", "last_edited_time", "last_edited_by"}:
            return None  # not writable
        if ptype == "people":
            # Notion requires user IDs; skip unless passed as list of ids
            if isinstance(value, list) and value and isinstance(value[0], dict):
                return {"people": value}
            return None
        # unknown: try as rich_text
        return {"rich_text": [{"type": "text", "text": {"content": str(value)}}]}

    def _page_prop_plain(self, page: dict, prop_name: str) -> Any:
        p = (page.get("properties") or {}).get(prop_name) or {}
        ptype = p.get("type") or ""
        if ptype == "title":
            arr = p.get("title") or []
            return (arr[0].get("plain_text") if arr else "") or ""
        if ptype == "rich_text":
            arr = p.get("rich_text") or []
            return (arr[0].get("plain_text") if arr else "") or ""
        if ptype == "number":
            return p.get("number")
        if ptype == "select":
            s = p.get("select") or {}
            return s.get("name") or ""
        if ptype == "multi_select":
            return [x.get("name") for x in (p.get("multi_select") or []) if x.get("name")]
        if ptype == "checkbox":
            return bool(p.get("checkbox"))
        if ptype == "url":
            return p.get("url") or ""
        if ptype == "date":
            d = p.get("date") or {}
            return d.get("start") or ""
        if ptype == "relation":
            return [x.get("id") for x in (p.get("relation") or []) if x.get("id")]
        return ""

    def _build_props(self, database_id: str, values: Dict[str, Any]) -> dict:
        props: Dict[str, Any] = {}
        for prop_name, value in values.items():
            ptype = self._ptype(database_id, prop_name)
            if not ptype:
                # property missing from DB; ignore rather than crash
                continue
            payload = self._serialize(ptype, value)
            if payload is not None:
                props[prop_name] = payload
        return props

    # ─────────────────────────────────────────────────────────────
    # Leads
    # ─────────────────────────────────────────────────────────────
    def preload_leads_index(self) -> dict:
        """Prefetch all Leads pages into local indexes.

        Returns:
          - by_lead_id: lead_id -> page_id
          - by_address: address -> page_id
          - hash_by_page: page_id -> last_updated_hash (stored in Leads.Last Updated rich_text)
        """
        if not NOTION_DB_LEADS:
            return {"by_lead_id": {}, "by_address": {}, "hash_by_page": {}}

        by_lead_id: Dict[str, str] = {}
        by_address: Dict[str, str] = {}
        hash_by_page: Dict[str, str] = {}

        start_cursor = None
        while True:
            payload: Dict[str, Any] = {"page_size": 100}
            if start_cursor:
                payload["start_cursor"] = start_cursor

            res = self.client.query_database(NOTION_DB_LEADS, payload)
            rows = res.get("results", []) or []

            for page in rows:
                pid = page.get("id")
                if not pid:
                    continue

                lead_id = _safe_rich_text(page, "Lead ID")
                if lead_id:
                    by_lead_id[lead_id.strip()] = pid

                addr = _safe_title(page, "Address")
                if addr:
                    by_address[addr.strip()] = pid

                h = _safe_rich_text(page, "Last Updated")
                if h:
                    hash_by_page[pid] = h.strip()

            if not res.get("has_more"):
                break
            start_cursor = res.get("next_cursor")

        return {"by_lead_id": by_lead_id, "by_address": by_address, "hash_by_page": hash_by_page}

    def find_lead(self, *, lead_id: str, address: str) -> Optional[dict]:
        if not NOTION_DB_LEADS:
            return None

        lead_id = (lead_id or "").strip()
        address = (address or "").strip()

        if lead_id:
            res = self.client.query_database(
                NOTION_DB_LEADS,
                {"page_size": 1, "filter": {"property": "Lead ID", "rich_text": {"equals": lead_id}}},
            )
            rows = res.get("results", [])
            if rows:
                return rows[0]

        res = self.client.query_database(
            NOTION_DB_LEADS,
            {"page_size": 1, "filter": {"property": "Address", "title": {"equals": address}}},
        )
        rows = res.get("results", [])
        return rows[0] if rows else None

    def upsert_lead(self, canonical: Dict[str, Any], idx: Optional[dict] = None) -> str:
        """Upsert into Leads DB idempotently using Leads -> 'Last Updated' as hash storage."""
        if not NOTION_DB_LEADS:
            raise RuntimeError("NOTION_DB_LEADS missing")

        # Enforce writable hash storage
        if self._ptype(NOTION_DB_LEADS, "Last Updated") != "rich_text":
            raise RuntimeError("Leads -> 'Last Updated' must be a text (rich_text) property so we can store the idempotency hash.")

        address = str(canonical.get("address") or "").strip()
        if not address:
            raise ValueError("canonical.address missing")

        lead_id = str(canonical.get("lead_id") or "").strip()
        idx = idx or {"by_lead_id": {}, "by_address": {}, "hash_by_page": {}}
        by_lead_id = idx.get("by_lead_id", {}) or {}
        by_address = idx.get("by_address", {}) or {}
        hash_by_page = idx.get("hash_by_page", {}) or {}

        lead_page_id: Optional[str] = None
        if lead_id and lead_id in by_lead_id:
            lead_page_id = by_lead_id[lead_id]
        elif address and address in by_address:
            lead_page_id = by_address[address]

        # If we found by index, we can skip find_lead() query entirely.
        if lead_page_id:
            lead_page = {
                "id": lead_page_id,
                "properties": {
                    "Last Updated": {
                        "rich_text": [{"plain_text": hash_by_page.get(lead_page_id, "")}]
                    }
                },
            }
        else:
            lead_page = self.find_lead(lead_id=lead_id, address=address)

        # hash based on computed + key identity fields
        h = row_hash(
            canonical,
            [
                "lead_id",
                "address",
                "zip",
                "arv_est",
                "repairs_est",
                "mao_flip",
                "mao_wholesale",
                "deal_score",
                "decision",
                "sweet_spot",
            ],
        )

        # Store hash in Leads -> Last Updated (your property name)
        # NOTE: If you accidentally made Last Updated a 'Last edited time' property, Notion won't allow writes.
        values = {
            "Address": address,
            "Lead ID": lead_id,
            "City": canonical.get("city"),
            "State": canonical.get("state"),
            "Zip": canonical.get("zip"),
            "Type": canonical.get("property_type"),
            "Decision": canonical.get("decision"),
            "ARV": canonical.get("arv_est"),
            "Rehab": canonical.get("repairs_est"),
            "MAO Flip": canonical.get("mao_flip"),
            "MAO Wholesale": canonical.get("mao_wholesale"),
            "Deal Score": canonical.get("deal_score"),
            "Wholesale Sweet Spot": canonical.get("sweet_spot"),
            "Last Updated": h,  # hash storage
        }

        props = self._build_props(NOTION_DB_LEADS, values)

        # title is required
        if "Address" not in props:
            # If Address property missing or wrong type, fail loudly
            raise RuntimeError("Leads DB missing title property named 'Address'.")

        if lead_page:
            # idempotency check
            old_hash = str(self._page_prop_plain(lead_page, "Last Updated") or "").strip()
            if old_hash == h:
                return lead_page["id"]

            try:
                self.client.update_page(lead_page["id"], {"properties": props})
            except Exception as e:
                msg = str(e)
                if "Last Updated" in msg and "last_edited_time" in msg:
                    raise RuntimeError(
                        "Leads -> 'Last Updated' appears to be a 'Last edited time' property. "
                        "Change it to a text property (rich text) so we can store the idempotency hash."
                    ) from e
                raise

            # Keep preloaded index warm (optional)
            if idx is not None:
                if lead_id:
                    by_lead_id[lead_id] = lead_page["id"]
                if address:
                    by_address[address] = lead_page["id"]
                hash_by_page[lead_page["id"]] = h

            return lead_page["id"]

        created = self.client.create_page({"parent": {"database_id": NOTION_DB_LEADS}, "properties": props})
        if idx is not None:
            pid = created["id"]
            if lead_id:
                by_lead_id[lead_id] = pid
            if address:
                by_address[address] = pid
            hash_by_page[pid] = h
        return created["id"]

    # ─────────────────────────────────────────────────────────────
    # Underwriting (idempotent via Notes suffix hash)
    # ─────────────────────────────────────────────────────────────
    def _find_underwriting(self, deal_key: str) -> Optional[dict]:
        if not NOTION_DB_UNDERWRITING:
            return None
        res = self.client.query_database(
            NOTION_DB_UNDERWRITING,
            {"page_size": 1, "filter": {"property": "Deal", "title": {"equals": deal_key}}},
        )
        rows = res.get("results", [])
        return rows[0] if rows else None

    def upsert_underwriting(self, canonical: Dict[str, Any], lead_page_id: str) -> str:
        """Upsert into Underwriting DB with Lead relation, idempotent using Notes hash suffix."""
        if not NOTION_DB_UNDERWRITING:
            return ""


        if self._ptype(NOTION_DB_UNDERWRITING, "Notes") != "rich_text":
            raise RuntimeError("Underwriting -> 'Notes' must be a text (rich_text) property so we can store the idempotency hash suffix.")

        deal_key = str(canonical.get("deal_key") or canonical.get("address") or "").strip() or str(lead_page_id)
        uw_page = self._find_underwriting(deal_key)

        # Compute underwriting hash
        h = row_hash(
            {**canonical, "lead_page_id": lead_page_id, "deal_key": deal_key},
            ["deal_key", "lead_page_id", "arv_est", "repairs_est", "mao_flip", "mao_wholesale", "deal_score", "decision"],
        )

        # Notes handling: preserve existing notes, but maintain / update hash suffix
        existing_notes = ""
        if uw_page:
            existing_notes = str(self._page_prop_plain(uw_page, "Notes") or "")

        base_notes = canonical.get("notes")
        if base_notes is None or (isinstance(base_notes, str) and base_notes.strip() == ""):
            base_notes = _strip_hash_suffix(existing_notes)

        notes_with_hash = _append_hash(str(base_notes or ""), h)

        values = {
            "Deal": deal_key,  # title
            "Lead": [lead_page_id],  # relation
            "Decision": canonical.get("decision"),
            "ARV": canonical.get("arv_est"),
            "Rehab": canonical.get("repairs_est"),
            "MAO Flip": canonical.get("mao_flip"),
            "MAO Wholesale": canonical.get("mao_wholesale"),
            "Deal Score": canonical.get("deal_score"),
            "Notes": notes_with_hash,
        }
        props = self._build_props(NOTION_DB_UNDERWRITING, values)
        if "Deal" not in props:
            raise RuntimeError("Underwriting DB missing title property named 'Deal'.")

        if "Lead" not in props:
            raise RuntimeError("Underwriting DB missing relation property named 'Lead' (should relate to Leads).")

        if uw_page:
            old_hash = _extract_hash(existing_notes)
            if old_hash == h:
                return uw_page["id"]
            self.client.update_page(uw_page["id"], {"properties": props})
            return uw_page["id"]

        created = self.client.create_page({"parent": {"database_id": NOTION_DB_UNDERWRITING}, "properties": props})
        return created["id"]

    # ─────────────────────────────────────────────────────────────
    # Tasks (idempotent via Notes suffix hash)
    # ─────────────────────────────────────────────────────────────
    def _find_task(self, task_name: str, address: str = "") -> Optional[dict]:
        if not NOTION_DB_TASKS:
            return None
        task_name = (task_name or "").strip()
        if not task_name:
            return None

        # Try AND filter if Address prop exists
        filt: dict
        if address:
            filt = {
                "and": [
                    {"property": "Task Name", "title": {"equals": task_name}},
                    {"property": "Address", "rich_text": {"equals": address}},
                ]
            }
        else:
            filt = {"property": "Task Name", "title": {"equals": task_name}}

        res = self.client.query_database(NOTION_DB_TASKS, {"page_size": 1, "filter": filt})
        rows = res.get("results", [])
        return rows[0] if rows else None

    def upsert_task(self, task: Dict[str, Any], *, relation_candidates: Optional[List[str]] = None) -> str:
        """Create/update Tasks row.

        - Idempotency: hash suffix stored in Tasks -> Notes.
        - Relation: we try each candidate page_id for Tasks -> Deal relation until one works.
        """
        if not NOTION_DB_TASKS:
            return ""

        if self._ptype(NOTION_DB_TASKS, "Notes") != "rich_text":
            raise RuntimeError(
                "Tasks -> 'Notes' must be a text (rich_text) property so we can store the idempotency hash suffix."
            )

        task_name = str(task.get("Task Name") or "").strip()
        if not task_name:
            return ""

        address = str(task.get("Address") or "").strip()
        page = self._find_task(task_name, address=address)

        candidates = [c for c in (relation_candidates or []) if c]
        # Hash all meaningful fields + first candidate id (stable ordering)
        h = row_hash(
            {**task, "deal_relation": candidates[0] if candidates else ""},
            [
                "Task Name",
                "Status",
                "Due Date",
                "Owner",
                "Task Type",
                "Outcome",
                "Priority",
                "Address",
                "Best Phone",
                "Attempt #",
                "deal_relation",
            ],
        )

        existing_notes = ""
        if page:
            existing_notes = str(self._page_prop_plain(page, "Notes") or "")

        base_notes = task.get("Notes")
        if base_notes is None or (isinstance(base_notes, str) and base_notes.strip() == ""):
            base_notes = _strip_hash_suffix(existing_notes)

        task["Notes"] = _append_hash(str(base_notes or ""), h)

        if page:
            old_hash = _extract_hash(existing_notes)
            if old_hash == h:
                return page["id"]

        # Try candidates for Deal relation
        last_err: Optional[Exception] = None
        tried_none = False

        for idx, rel_id in enumerate(candidates + [""]):
            t = dict(task)
            if rel_id:
                t["Deal"] = [rel_id]
            else:
                t.pop("Deal", None)
                tried_none = True

            props = self._build_props(NOTION_DB_TASKS, t)
            if "Task Name" not in props:
                raise RuntimeError("Tasks DB missing title property named 'Task Name'.")

            try:
                if page:
                    self.client.update_page(page["id"], {"properties": props})
                    return page["id"]
                created = self.client.create_page({"parent": {"database_id": NOTION_DB_TASKS}, "properties": props})
                return created["id"]
            except Exception as e:
                last_err = e
                # Common relation mismatch errors: try next candidate (or no relation)
                continue

        if last_err:
            raise last_err
        return ""


    # ─────────────────────────────────────────────────────────────
    # Deal Rooms (idempotent by diffing current values)
    # ─────────────────────────────────────────────────────────────
    def _find_dealroom(self, address: str) -> Optional[dict]:
        if not NOTION_DB_DEALROOMS:
            return None
        address = (address or "").strip()
        if not address:
            return None
        res = self.client.query_database(
            NOTION_DB_DEALROOMS,
            {"page_size": 1, "filter": {"property": "Address", "title": {"equals": address}}},
        )
        rows = res.get("results", [])
        return rows[0] if rows else None

    def upsert_dealroom(self, dealroom: Dict[str, Any]) -> str:
        if not NOTION_DB_DEALROOMS:
            return ""

        address = str(dealroom.get("Address") or "").strip()
        if not address:
            return ""

        page = self._find_dealroom(address)
        props = self._build_props(NOTION_DB_DEALROOMS, dealroom)
        if "Address" not in props:
            raise RuntimeError("Deal Rooms DB missing title property named 'Address'.")

        if page:
            # diff-based idempotency (avoid storing hash in your schema)
            changed = False
            for prop_name in dealroom.keys():
                # only compare props we can write
                if self._ptype(NOTION_DB_DEALROOMS, prop_name) in {"created_time", "created_by", "last_edited_time", "last_edited_by"}:
                    continue
                desired = dealroom.get(prop_name)
                if desired is None or (isinstance(desired, str) and desired.strip() == ""):
                    continue
                current = self._page_prop_plain(page, prop_name)
                # Normalize for comparison
                if isinstance(current, list):
                    desired_list = desired if isinstance(desired, list) else [desired]
                    if [str(x) for x in current] != [str(x) for x in desired_list]:
                        changed = True
                        break
                else:
                    if str(current) != str(desired):
                        changed = True
                        break

            if not changed:
                return page["id"]

            self.client.update_page(page["id"], {"properties": props})
            return page["id"]

        created = self.client.create_page({"parent": {"database_id": NOTION_DB_DEALROOMS}, "properties": props})
        return created["id"]
