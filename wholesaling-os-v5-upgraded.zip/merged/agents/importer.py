from __future__ import annotations

import csv
import logging
import os
from typing import Dict, List, Tuple

import pandas as pd

from .schema import REQUIRED_INPUT_FIELDS, OPTIONAL_INPUT_FIELDS
from .header_maps import DEALSAUCE_TO_CANONICAL

logger = logging.getLogger(__name__)


def _read_header(path: str) -> List[str]:
    with open(path, "r", encoding="utf-8", newline="") as f:
        r = csv.reader(f)
        return next(r, [])


def load_leads_canonical(leads_csv_path: str) -> Tuple[pd.DataFrame, dict]:
    """Load a DealSauce export CSV into canonical columns.

    Design goals:
    - Fast: read only mapped columns via usecols when possible
    - Stable: single rename map (source -> canonical) applied once
    - Loud: returns a coverage report; optionally raises if required columns are absent
    """
    if not os.path.exists(leads_csv_path):
        raise FileNotFoundError(leads_csv_path)

    header = _read_header(leads_csv_path)
    header_set = set(header)

    # Determine minimum cols to read
    usecols = [src for src in DEALSAUCE_TO_CANONICAL.keys() if src in header_set]
    if not usecols:
        logger.warning("No known mapped columns found. Reading full CSV (slow).")
        df = pd.read_csv(leads_csv_path, dtype=str, keep_default_na=False).fillna("")
    else:
        df = pd.read_csv(leads_csv_path, usecols=usecols, dtype=str, keep_default_na=False).fillna("")

    # Rename once into canonical
    rename_map: Dict[str, str] = {src: DEALSAUCE_TO_CANONICAL[src] for src in usecols if src in DEALSAUCE_TO_CANONICAL}
    if rename_map:
        df = df.rename(columns=rename_map)

    # Ensure required + optional canonical columns exist
    for col in REQUIRED_INPUT_FIELDS | OPTIONAL_INPUT_FIELDS:
        if col not in df.columns:
            df[col] = ""

    # Coverage report
    missing_required = [c for c in REQUIRED_INPUT_FIELDS if df[c].astype(str).str.strip().eq("").all()]
    report = {
        "used_source_cols": usecols,
        "missing_required_fields_all_blank": missing_required,
        "missing_optional_fields_absent": [c for c in OPTIONAL_INPUT_FIELDS if c not in df.columns],
        "row_count": int(len(df)),
    }

    # No silent breaks: optionally enforce strictness
    strict = os.getenv("IMPORT_STRICT_SCHEMA", "true").lower().strip() == "true"
    if strict and missing_required:
        raise ValueError(
            "Import failed: required canonical fields are present but entirely blank: "
            + ", ".join(missing_required)
        )

    return df, report
