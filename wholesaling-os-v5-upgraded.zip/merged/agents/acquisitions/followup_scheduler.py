from __future__ import annotations
"""Follow-up scheduler — creates time-sequenced follow-up tasks for pursued leads."""
import csv, os, logging
from datetime import datetime, timezone, timedelta
from infrastructure.task_registry import register_task

log = logging.getLogger(__name__)

FOLLOWUP_SEQUENCE = [
    (1,  "Call/SMS Day 1 — introduce offer"),
    (3,  "Follow-up Day 3 — confirm receipt"),
    (7,  "Follow-up Day 7 — check motivation"),
    (14, "Follow-up Day 14 — final outreach before nurture"),
]

@register_task("agents.acquisitions.followup_scheduler:schedule")
def schedule(run_id: str, pursued_leads: list | None = None) -> dict:
    if not pursued_leads:
        return {"run_id": run_id, "tasks_created": 0}
    rows, count = [], 0
    now = datetime.now(timezone.utc)
    for lead in pursued_leads:
        for days, label in FOLLOWUP_SEQUENCE:
            rows.append({
                "lead_id":  lead.get("lead_id",""),
                "address":  lead.get("address",""),
                "due_date": (now + timedelta(days=days)).isoformat(),
                "task":     label,
                "run_id":   run_id,
            })
            count += 1
    path = "out/call_text_queue.csv"
    os.makedirs("out", exist_ok=True)
    is_new = not os.path.exists(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["lead_id","address","due_date","task","run_id"])
        if is_new: w.writeheader()
        w.writerows(rows)
    log.info("Scheduled %d follow-up tasks", count)
    return {"run_id": run_id, "tasks_created": count}
