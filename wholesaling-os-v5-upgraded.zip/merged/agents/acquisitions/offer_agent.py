from __future__ import annotations

"""Offer agent — generates structured offer strategies for pursued deals.

Builds a 4-rung offer ladder (LAO → Anchor → Walk-Away) for each
PURSUE_OFFER / PURSUE_IF_NEGOTIABLE deal and writes call scripts + CSV.
"""

import csv
import logging
import os
from dataclasses import dataclass
from typing import Any

from agents.llm import call_llm
from infrastructure.task_registry import register_task

log = logging.getLogger(__name__)


@dataclass
class OfferLadder:
    lao: float
    anchor: float
    rungs: list[float]
    walk_away: float


def _round_k(v: float, k: float = 1000.0) -> float:
    return round(v / k) * k


def build_ladder(mao70: float, mao80: float | None = None) -> OfferLadder:
    lao        = _round_k(mao70 * 0.80)
    anchor     = _round_k(mao70 * 0.84)
    rungs      = [_round_k(mao70 * p) for p in [0.88, 0.92, 0.96, 1.00]]
    walk_away  = min(mao70, mao80 or mao70)
    return OfferLadder(lao=lao, anchor=anchor, rungs=rungs, walk_away=walk_away)


def _call_script(lead: dict) -> str:
    addr    = lead.get("address", "the property")
    anchor  = lead.get("_anchor", 0)
    max_off = lead.get("_walk_away", 0)
    ask_str = f"${lead['asking_price']:,.0f}" if lead.get("asking_price") else "your asking price"
    prompt  = (
        f"Write a concise 3-paragraph cash offer call script for {addr}. "
        f"Anchor offer: ${anchor:,.0f}. Walk-away: ${max_off:,.0f}. Seller asking {ask_str}. "
        "Para 1: rapport. Para 2: present offer. Para 3: handle price objection. Under 150 words."
    )
    return call_llm(prompt, feature="offer_script") or (
        f"Hi, calling about {addr}. I can offer ${anchor:,.0f} cash, as-is, 10-14 day close. "
        f"Flexible up to ${max_off:,.0f} if timeline works. Good time to talk?"
    )


def _sms(lead: dict) -> str:
    anchor = lead.get("_anchor", 0)
    return (
        f"Hi, cash offer ready for {lead.get('address','your property')}: "
        f"${anchor:,.0f} as-is, fast close. Good time to talk? Reply STOP to opt out."
    )


def _write_csv(rows: list[dict], path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    is_new = not os.path.exists(path)
    fields = ["lead_id", "address", "arv", "mao_wholesale", "lao", "anchor",
              "walk_away", "asking_price", "score", "sms_opener"]
    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        if is_new:
            w.writeheader()
        w.writerows(rows)


@register_task("agents.acquisitions.offer_agent:generate_offers")
def generate_offers(run_id: str, pursued_leads: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    if not pursued_leads:
        return {"run_id": run_id, "offers_generated": 0}

    rows, generated = [], 0
    for lead in pursued_leads:
        mao_w = lead.get("mao_wholesale") or 0.0
        if not mao_w:
            continue
        ladder = build_ladder(mao_w, lead.get("mao_flip"))
        lead["_anchor"]     = ladder.anchor
        lead["_walk_away"]  = ladder.walk_away
        rows.append({
            "lead_id":      lead.get("lead_id", ""),
            "address":      lead.get("address", ""),
            "arv":          lead.get("arv", ""),
            "mao_wholesale": mao_w,
            "lao":          ladder.lao,
            "anchor":       ladder.anchor,
            "walk_away":    ladder.walk_away,
            "asking_price": lead.get("asking_price", ""),
            "score":        lead.get("deal_score", ""),
            "sms_opener":   _sms(lead),
        })
        generated += 1
        log.info("Offer: %s anchor=$%,.0f walk=$%,.0f", lead.get("address"), ladder.anchor, ladder.walk_away)

    if rows:
        _write_csv(rows, "out/offers_to_send.csv")

    return {"run_id": run_id, "offers_generated": generated}
