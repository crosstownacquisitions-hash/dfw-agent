from __future__ import annotations

"""Quota-safe LLM calling (free-tier friendly).

Constraints:
- Bounded calls per run
- Bounded retries
- Hard timeout
- Daily quota guard (RPD)
- Cooldown when quota exceeded
- Disk cache (prompt+model -> response)
- No loops / no hangs

Providers:
- LiteLLM (recommended): enforces HTTP timeouts per request
- Gemini REST fallback: enforces requests timeout
- Gemini SDK last resort: wrapped in a thread timeout (best-effort)
"""

import hashlib
import json
import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeout
from typing import Optional

import requests

log = logging.getLogger(__name__)

STATE_PATH = os.path.join("out", "llm_state.json")
CACHE_DIR = os.path.join("out", "llm_cache")


def _today_utc() -> str:
    return time.strftime("%Y-%m-%d", time.gmtime())


def _load_state() -> dict:
    try:
        if os.path.exists(STATE_PATH):
            return json.load(open(STATE_PATH, "r", encoding="utf-8"))
    except Exception:
        pass
    return {"day": "", "calls_today": 0, "calls_this_run": 0, "cooldown_until": 0}


def _save_state(s: dict) -> None:
    os.makedirs(os.path.dirname(STATE_PATH) or ".", exist_ok=True)
    try:
        json.dump(s, open(STATE_PATH, "w", encoding="utf-8"), indent=2)
    except Exception:
        pass


def _cache_key(model: str, prompt: str) -> str:
    return hashlib.sha256((model + "\n" + prompt).encode("utf-8", "ignore")).hexdigest()[:32]


def _cache_get(k: str) -> Optional[str]:
    p = os.path.join(CACHE_DIR, f"{k}.txt")
    if not os.path.exists(p):
        return None
    try:
        return open(p, "r", encoding="utf-8").read().strip()
    except Exception:
        return None


def _cache_set(k: str, v: str) -> None:
    os.makedirs(CACHE_DIR, exist_ok=True)
    try:
        open(os.path.join(CACHE_DIR, f"{k}.txt"), "w", encoding="utf-8").write(v)
    except Exception:
        pass


def call_llm(prompt: str, *, feature: str = "general") -> str:
    """Return model text, or "" if disabled / budgeted out / failed."""
    if os.getenv("USE_LLM", "true").lower().strip() != "true":
        return ""

    if os.getenv("LLM_BUDGET_MODE", "cheap").lower().strip() == "off":
        return ""

    max_calls_run = int(os.getenv("LLM_MAX_CALLS_PER_RUN", "8"))
    rpd_limit = int(os.getenv("LLM_RPD_LIMIT", "250"))
    max_retries = int(os.getenv("LLM_MAX_RETRIES", "1"))
    timeout_s = int(os.getenv("LLM_TIMEOUT_SECS", "20"))

    state = _load_state()
    if state.get("day") != _today_utc():
        state = {"day": _today_utc(), "calls_today": 0, "calls_this_run": 0, "cooldown_until": 0}
        _save_state(state)

    now = time.time()
    if now < float(state.get("cooldown_until", 0) or 0):
        return ""

    if int(state.get("calls_this_run", 0)) >= max_calls_run:
        return ""

    if int(state.get("calls_today", 0)) >= rpd_limit:
        state["cooldown_until"] = now + int(os.getenv("LLM_COOLDOWN_QUOTA_SECS", "900"))
        _save_state(state)
        return ""

    # If FORCE_LITELLM=true, we only use LiteLLM (cleanest timeout behavior).
    force_litellm = os.getenv("FORCE_LITELLM", "false").lower().strip() == "true"
    provider = (os.getenv("LLM_PROVIDER") or "litellm").lower().strip()
    if force_litellm:
        provider = "litellm"

    primary = os.getenv("PRIMARY_MODEL", os.getenv("DEFAULT_LLM_MODEL", "gemini/gemini-2.5-flash")).strip()
    fallback_str = os.getenv("LLM_FALLBACK_MODELS", primary).strip()
    models = [m.strip() for m in fallback_str.split(",") if m.strip()]
    if primary not in models:
        models.insert(0, primary)

    # cache (keyed by first-choice model)
    k = _cache_key(models[0], prompt)
    cached = _cache_get(k)
    if cached:
        return cached

    last_err: Exception | None = None
    for m in models:
        for attempt in range(max_retries + 1):
            try:
                out = ""
                if provider == "litellm":
                    import litellm  # type: ignore

                    resp = litellm.completion(
                        model=m,
                        messages=[{"role": "user", "content": prompt}],
                        timeout=timeout_s,
                        temperature=0.2,
                        max_tokens=500,
                    )
                    out = (resp["choices"][0]["message"]["content"] or "").strip()
                else:
                    # Non-LiteLLM path: model will be last segment (gemini-2.5-flash)
                    out = _call_gemini_with_timeout(prompt, model=m.split("/")[-1], timeout_s=timeout_s)

                if out:
                    state["calls_today"] = int(state.get("calls_today", 0)) + 1
                    state["calls_this_run"] = int(state.get("calls_this_run", 0)) + 1
                    _save_state(state)
                    _cache_set(k, out)
                    return out

                # blank: don't retry same model
                break
            except Exception as e:
                last_err = e
                time.sleep(1.0 + attempt)

    if last_err:
        log.warning("LLM failed (%s): %s", feature, repr(last_err)[:200])
        state["cooldown_until"] = time.time() + 60
        _save_state(state)

    return ""


def _call_gemini_rest(prompt: str, *, model: str, timeout_s: int) -> str:
    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not api_key:
        return ""

    # Generative Language API (Gemini) REST
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.2, "maxOutputTokens": 500},
    }
    r = requests.post(url, json=payload, timeout=timeout_s)
    if r.status_code >= 400:
        return ""
    data = r.json() or {}
    cands = data.get("candidates") or []
    if not cands:
        return ""
    content = (cands[0].get("content") or {})
    parts = content.get("parts") or []
    if not parts:
        return ""
    txt = parts[0].get("text") or ""
    return str(txt).strip()


def _call_gemini_sdk(prompt: str, *, model: str) -> str:
    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not api_key:
        return ""
    try:
        from google import genai  # type: ignore

        client = genai.Client(api_key=api_key)
        resp = client.models.generate_content(model=model, contents=prompt)
        return (getattr(resp, "text", None) or "").strip()
    except Exception:
        return ""


def _call_gemini_with_timeout(prompt: str, *, model: str, timeout_s: int) -> str:
    # First try REST with hard timeout.
    try:
        out = _call_gemini_rest(prompt, model=model, timeout_s=timeout_s)
        if out:
            return out
    except Exception:
        pass

    # Last resort: SDK call wrapped in a thread timeout (best-effort).
    with ThreadPoolExecutor(max_workers=1) as ex:
        fut = ex.submit(_call_gemini_sdk, prompt, model=model)
        try:
            return (fut.result(timeout=timeout_s) or "").strip()
        except FuturesTimeout:
            return ""
        except Exception:
            return ""
