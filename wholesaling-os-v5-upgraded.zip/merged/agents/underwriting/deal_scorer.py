from __future__ import annotations

from dataclasses import dataclass
from typing import List

from domain.decisions import decide


@dataclass(frozen=True)
class ScoreResult:
    score: float
    decision: str
    reason_codes: List[str]
    confidence: str


def score_deal(
    *,
    arv: float | None,
    rehab: float | None,
    asking: float | None,
    mao_wholesale: float | None,
    mao_flip: float | None,
) -> ScoreResult:
    # Delegate to domain decision model for transparency
    d = decide(arv=arv, rehab=rehab, asking=asking, mao_wholesale=mao_wholesale, mao_flip=mao_flip)
    return ScoreResult(score=float(d.score), decision=str(d.decision), reason_codes=list(d.reason_codes), confidence=str(d.confidence))
