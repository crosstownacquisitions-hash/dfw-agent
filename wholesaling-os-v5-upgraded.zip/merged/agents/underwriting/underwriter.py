from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.logger import get_logger
from domain.math import calc_mao_flip, calc_mao_wholesale
from agents.enrich.comps_agent import estimate_arv
from agents.enrich.rehab_estimator import estimate_rehab
from agents.underwriting.deal_scorer import score_deal

log = get_logger(__name__)


@dataclass(frozen=True)
class UnderwriteResult:
    arv: float | None
    rehab: float | None
    mao_wholesale: float | None
    mao_flip: float | None
    score: float | None
    decision: str
    reason_codes: list[str]
    confidence: str
    meta: dict[str, Any]


def underwrite(
    *,
    lead_id: str,
    run_id: str,
    address: str,
    city: str,
    state: str,
    zip_code: str,
    sqft: int | None,
    year_built: int | None,
    asking_price: float | None,
) -> UnderwriteResult:
    comps = estimate_arv(
        lead_id=lead_id,
        run_id=run_id,
        address=address,
        city=city,
        state=state,
        zip_code=zip_code,
        subject_sqft=float(sqft) if sqft else None,
    )
    rehab = estimate_rehab(lead_id=lead_id, run_id=run_id, sqft=sqft, year_built=year_built)
    mao_w = calc_mao_wholesale(arv=comps.arv, rehab=rehab.rehab)
    mao_f = calc_mao_flip(arv=comps.arv, rehab=rehab.rehab)

    s = score_deal(arv=comps.arv, rehab=rehab.rehab, asking=asking_price, mao_wholesale=mao_w, mao_flip=mao_f)
    return UnderwriteResult(
        arv=comps.arv,
        rehab=rehab.rehab,
        mao_wholesale=mao_w,
        mao_flip=mao_f,
        score=s.score,
        decision=s.decision,
        reason_codes=s.reason_codes,
        confidence=s.confidence,
        meta={"comps": comps.meta, "rehab": rehab.meta},
    )
