from __future__ import annotations

from typing import List, Optional
import csv
import os

from domain.arv_from_comps import ComparableSale


def get_comps_from_csv(
    *,
    comps_csv_path: str,
    subject_city: str = "",
    subject_state: str = "",
    subject_zip: str = "",
    limit: int = 25,
) -> List[ComparableSale]:
    """Read a sold-comps CSV export and return normalized ComparableSale rows.

    Deterministic + auditable. This avoids live scraping and keeps the LLM out of data retrieval.
    """
    if not comps_csv_path or not os.path.exists(comps_csv_path):
        return []

    out: List[ComparableSale] = []
    with open(comps_csv_path, "r", encoding="utf-8-sig", newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            city = (row.get("City") or row.get("city") or "").strip()
            state = (row.get("State") or row.get("state") or "").strip()
            z = (row.get("Zip") or row.get("zip") or row.get("PostalCode") or "").strip()

            if subject_state and state and subject_state.lower() != state.lower():
                continue
            if subject_city and city and subject_city.lower() != city.lower():
                continue
            if subject_zip and z and subject_zip != z:
                continue

            sp = _f(row.get("Sale Price") or row.get("sale_price") or row.get("SoldPrice"))
            sqft = _f(row.get("Sqft") or row.get("sqft") or row.get("Living Area"))
            addr = (row.get("Address") or row.get("address") or row.get("Property Address") or "").strip()
            sold_date = (row.get("Sold Date") or row.get("sold_date") or "").strip()

            if sp and sqft and addr:
                out.append(
                    ComparableSale(
                        address=addr,
                        sale_price=sp,
                        sqft=sqft,
                        sold_date=sold_date,
                        source="csv",
                    )
                )

            if len(out) >= limit:
                break

    return out


def _f(x) -> Optional[float]:
    try:
        if x is None:
            return None
        s = str(x).replace("$", "").replace(",", "").strip()
        if not s:
            return None
        return float(s)
    except Exception:
        return None
