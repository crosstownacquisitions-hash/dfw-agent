from __future__ import annotations

"""Ingestion entrypoints.

This system is Notion-first: the daily workflow processes leads already in the
Notion Leads database with Status=New.

Use scripts/backfill_from_csv.py to bulk import.
"""

from app.logger import get_logger
from infrastructure.task_registry import register_task

log = get_logger(__name__)


@register_task("agents.ingest.lead_ingestor:ingest")
def ingest(run_id: str, limit: int = 100) -> dict:
    # Placeholder for future scraping/list ingestion. Kept for compatibility.
    log.info("Ingest noop (Notion-first)", extra={"run_id": run_id, "limit": limit})
    return {"run_id": run_id, "ingested": 0}
