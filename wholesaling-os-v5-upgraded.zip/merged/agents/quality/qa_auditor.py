from __future__ import annotations

from app.logger import get_logger
from infrastructure.task_registry import register_task
from tools.data.repo import ConfigRepo

log = get_logger(__name__)


@register_task("agents.quality.qa_auditor:audit_run")
def audit_run(run_id: str) -> dict:
    """Lightweight QA pass.

    In a full build, you'd also validate Notion schema, rate-limits, and provider
    output quality. Here we keep it safe and deterministic.
    """
    cfg = ConfigRepo().get("qa", default={"enabled": True})
    if not cfg.get("enabled", True):
        return {"run_id": run_id, "flags": 0, "skipped": True}

    # Placeholder QA checks; extend as you wire providers.
    flags = 0
    log.info("QA complete", extra={"run_id": run_id, "flags": flags})
    return {"run_id": run_id, "flags": flags}
