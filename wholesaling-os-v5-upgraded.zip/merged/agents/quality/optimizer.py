from __future__ import annotations

"""Learning loop.

This is intentionally conservative: we only adjust scoring weights when we have
enough outcome data.
"""

from app.logger import get_logger
from infrastructure.task_registry import register_task
from tools.data.repo import ConfigRepo
from tools.data.storage import SessionLocal
from tools.data.models import Outcome
from sqlalchemy import select

log = get_logger(__name__)


def _normalize(weights: dict[str, float]) -> dict[str, float]:
    total = sum(max(v, 0.0) for v in weights.values())
    if total <= 0:
        return weights
    return {k: round(max(v, 0.0) / total, 4) for k, v in weights.items()}


@register_task("agents.quality.optimizer:optimize")
def optimize(run_id: str) -> dict:
    """Update scoring weights based on outcomes.

    Outcome events you can write later:
      - offer_sent
      - offer_accepted
      - closed

    We only tune if we have >= MIN_EVENTS.
    """
    cfg = ConfigRepo()
    current = cfg.get(
        "scoring_weights",
        default={
            "discount": 0.35,
            "distress": 0.20,
            "liquidity": 0.15,
            "comps_confidence": 0.15,
            "execution_friction": 0.15,
        },
    )

    min_events = int(cfg.get("optimizer", default={"min_events": 30}).get("min_events", 30))

    with SessionLocal() as s:
        n = s.execute(select(Outcome.id)).all()
        n_events = len(n)

    if n_events < min_events:
        log.info("Optimizer skipped (insufficient data)", extra={"events": n_events, "min": min_events})
        return {"run_id": run_id, "updated": False, "events": n_events}

    # Conservative adjustment placeholder: slightly favor discount if enough acceptances.
    # You can replace with a proper regression later.
    new = dict(current)
    new["discount"] = float(new.get("discount", 0.35)) + 0.01
    new["execution_friction"] = float(new.get("execution_friction", 0.15)) - 0.01
    new = _normalize({k: float(v) for k, v in new.items()})
    cfg.set("scoring_weights", new)
    log.info("Optimizer updated weights", extra={"weights": new})
    return {"run_id": run_id, "updated": True, "weights": new, "events": n_events}
