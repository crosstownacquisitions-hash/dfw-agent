from __future__ import annotations

import uuid
import os
from datetime import datetime, timedelta, timezone

from app.logger import get_logger
from app.settings import settings
from domain.decisions import decision_from_score
from domain.math import calc_mao_flip, calc_mao_wholesale, rehab_estimate_from_tags
from domain.scoring import score_deal
from tools.data.repo import LeadsRepo, UnderwriteRepo
from tools.llm.router import llm_complete
from tools.notion.readers import NotionReaders
from tools.notion.writers import NotionWriters, sel, num
from tools.notion.schemas import LEADS
from domain.economics import CostLedger, StageBudgets
from domain.quarantine import QuarantineStore

log = get_logger(__name__)


def _estimate_arv_via_llm(lead: dict, *, run_id: str, lead_id: str, ledger: CostLedger, budgets: StageBudgets) -> tuple[float | None, str]:
    """Fallback ARV estimator if you don't have a comps provider wired yet.

    Returns (arv, confidence).
    """
    prompt = (
        "You are a DFW residential real estate underwriting assistant. "
        "Estimate ARV (after-repair value) in USD for the subject property. "
        "Return ONLY JSON: {\"arv\": number|null, \"confidence\": \"Low\"|\"Med\"|\"High\"}. "
        "If information is insufficient, set arv to null and confidence Low.\n\n"
        f"Subject: {lead.get('address','')} {lead.get('city','')} TX {lead.get('zip','')}\n"
        f"Type: {lead.get('property_type','SFH')}, Beds: {lead.get('beds')}, Baths: {lead.get('baths')}, "
        f"Sqft: {lead.get('sqft')}, Year: {lead.get('year_built')}\n"
        f"Asking price (if known): {lead.get('asking_price')}\n"
    )
    # Tiered routing: cheap first, escalate only if needed.
    cheap_model = settings.default_llm_model
    expensive_model = (os.getenv("EXPENSIVE_LLM_MODEL") or "").strip()

    def _call(model: str) -> dict:
        if not budgets.allow("llm"):
            return {"choices": [{"message": {"content": "{}"}}], "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}, "model": model}
        budgets.increment("llm", 1)
        return llm_complete([{"role": "user", "content": prompt}], model=model, temperature=0.1, max_tokens=180)

    resp = _call(cheap_model)
    content = (resp.get("choices") or [{}])[0].get("message", {}).get("content", "")
    usage = resp.get("usage") or {}
    total_tokens = int(usage.get("total_tokens") or 0)
    if total_tokens:
        ledger.record_usage(run_id=run_id, lead_id=lead_id, stage="llm_arv", vendor=str(resp.get("model") or cheap_model), units=total_tokens)
    try:
        import json

        obj = json.loads(content)
        arv = obj.get("arv")
        conf = str(obj.get("confidence", "Low"))
        arv_val = float(arv) if arv is not None else None

        if expensive_model and (conf.lower().startswith("l") or arv_val is None):
            resp2 = _call(expensive_model)
            content2 = (resp2.get("choices") or [{}])[0].get("message", {}).get("content", "")
            usage2 = resp2.get("usage") or {}
            total2 = int(usage2.get("total_tokens") or 0)
            if total2:
                ledger.record_usage(run_id=run_id, lead_id=lead_id, stage="llm_arv_escalated", vendor=str(resp2.get("model") or expensive_model), units=total2)
            try:
                obj2 = json.loads(content2)
                arv2 = obj2.get("arv")
                conf2 = str(obj2.get("confidence", conf))
                arv2_val = float(arv2) if arv2 is not None else None
                if arv2_val is not None:
                    return (arv2_val, conf2)
            except Exception:
                pass

        return (arv_val, conf)
    except Exception:
        return (None, "Low")


def process_new_leads(run_id: str, limit: int = 100, pursue_threshold: float = 70.0) -> dict:
    """Main daily pipeline: Notion(New) -> Underwrite -> Notion updates + tasks."""

    nr = NotionReaders()
    nw = NotionWriters()
    ledger = CostLedger()
    budgets = StageBudgets()
    quarantine = QuarantineStore()
    leads = nr.fetch_new_leads(limit=limit)

    processed = 0
    pursued = 0
    nurtured = 0
    discarded = 0
    needs_review = 0


    ranked_rows: list[dict] = []
    for lead in leads:
        page_id = lead.get("page_id")
        lead_id = lead.get("lead_id") or f"lead_{uuid.uuid4().hex[:10]}"
        lead["lead_id"] = lead_id

        try:
            # Persist lead to local DB (idempotent upsert)
            LeadsRepo().upsert(
                lead_id=lead_id,
                notion_page_id=page_id,
                address=lead.get("address", ""),
                city=lead.get("city", ""),
                state=lead.get("state", "TX"),
                zip=lead.get("zip", ""),
                county=lead.get("county", ""),
                property_type=lead.get("property_type", "SFH"),
                beds=int(lead["beds"]) if lead.get("beds") is not None else None,
                baths=float(lead["baths"]) if lead.get("baths") is not None else None,
                sqft=int(lead["sqft"]) if lead.get("sqft") is not None else None,
                year_built=int(lead["year_built"]) if lead.get("year_built") is not None else None,
                asking_price=float(lead["asking_price"]) if lead.get("asking_price") is not None else None,
                source=lead.get("source", ""),
                status=lead.get("status", "New"),
            )

            # --- Enrichment / valuation inputs
            arv, conf = _estimate_arv_via_llm(lead, run_id=run_id, lead_id=lead_id, ledger=ledger, budgets=budgets)
            rehab = rehab_estimate_from_tags(sqft=int(lead["sqft"]) if lead.get("sqft") else None, condition="unknown")

            if arv is None:
                decision = "NEEDS_REVIEW"
                score = None
                mao_w = None
                mao_f = None
                pursue = False
                needs_review += 1
            else:
                mao_w = calc_mao_wholesale(arv=arv, rehab=rehab)
                mao_f = calc_mao_flip(arv=arv, rehab=rehab)

                ask = float(lead["asking_price"]) if lead.get("asking_price") else None
                discount_pct = 0.0
                if ask and ask > 0:
                    discount_pct = max(min((arv - ask) / arv, 1.0), 0.0)

                distress_score = 0.6
                liquidity_score = 0.6
                comps_confidence = {"Low": 0.4, "Med": 0.65, "High": 0.85}.get(conf, 0.4)
                friction_score = 0.4

                score = score_deal(
                    discount_pct=discount_pct,
                    distress_score=distress_score,
                    liquidity_score=liquidity_score,
                    comps_confidence=comps_confidence,
                    friction_score=friction_score,
                )
                decision = decision_from_score(score)
                pursue = (score is not None and float(score) >= float(pursue_threshold))

            UnderwriteRepo().add(
                lead_id=lead_id,
                run_id=run_id,
                arv=arv,
                rehab=rehab,
                mao_wholesale=mao_w,
                mao_flip=mao_f,
                score=score,
                decision=decision,
                confidence=conf,
                reason_codes="",
            )

            # --- Write back to Notion
            if page_id:
                status_value = (
                    "Underwritten"
                    if decision in ("PURSUE_OFFER", "PURSUE_IF_NEGOTIABLE")
                    else ("Nurture" if decision == "NURTURE" else ("Dead" if decision == "DISCARD" else "Needs Review"))
                )

                props = {
                    LEADS["lead_id"]: {"rich_text": [{"text": {"content": lead_id}}]},
                    LEADS["status"]: sel(status_value),
                }
                nw.client.update_page(page_id, {"properties": props})

                if settings.notion_db_underwriting:
                    nw.create_underwrite(
                        lead_page_id=page_id,
                        uw={
                            "arv": arv,
                            "rehab": rehab,
                            "mao_wholesale": mao_w,
                            "mao_flip": mao_f,
                            "score": score,
                            "decision": decision,
                            "confidence": conf,
                            "reason_codes": [],
                            "assumptions_version": os.getenv("UNDERWRITING_ASSUMPTIONS_VERSION", "v1"),
                        },
                    )

                if pursue and settings.notion_db_tasks:
                    due = datetime.now(timezone.utc) + timedelta(hours=2)
                    nw.create_task(
                        title_text=f"Call/SMS seller re: {lead.get('address','')}",
                        lead_page_id=page_id,
                        task_type="Call",
                        due=due,
                    )

                    if settings.notion_db_dealrooms:
                        nw.create_dealroom(
                            title_text=lead.get("address", ""),
                            packet_status="Draft",
                            status="New",
                        )
                    pursued += 1
                elif decision == "NURTURE":
                    nurtured += 1
                elif decision == "DISCARD":
                    discarded += 1
                else:
                    needs_review += 1

            ranked_rows.append(
                {
                    "lead_id": lead_id,
                    "address": lead.get("address", ""),
                    "city": lead.get("city", ""),
                    "state": lead.get("state", "TX"),
                    "zip": lead.get("zip", ""),
                    "asking_price": float(lead["asking_price"]) if lead.get("asking_price") not in (None, "") else None,
                    "arv": arv,
                    "rehab": rehab,
                    "mao_wholesale": mao_w,
                    "mao_flip": mao_f,
                    "deal_score": score,
                    "decision": decision,
                    "confidence": conf,
                    "pursue": pursue,
                    "notion_page_id": page_id,
                    "assumptions_version": os.getenv("UNDERWRITING_ASSUMPTIONS_VERSION", "v1"),
                }
            )

            processed += 1

        except Exception as exc:
            quarantine.save(run_id=run_id, lead_id=lead_id, stage="pipeline", error=repr(exc), payload={"lead": lead, "page_id": page_id})
            needs_review += 1
            log.exception("Lead failed; quarantined", extra={"run_id": run_id, "lead_id": lead_id})
            continue


    # --- Write canonical run artifacts
    import os, csv
    os.makedirs('out', exist_ok=True)
    run_dir = os.path.join('out', 'runs', run_id)
    os.makedirs(run_dir, exist_ok=True)
    artifact_path = os.path.join(run_dir, 'ranked_leads.csv')
    latest_path = os.path.join('out', 'ranked_leads_latest.csv')
    fieldnames = list(ranked_rows[0].keys()) if ranked_rows else []
    for path in (artifact_path, latest_path):
        with open(path, 'w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            if fieldnames:
                w.writeheader()
                w.writerows(ranked_rows)

    return {
        "processed": processed,
        "pursued": pursued,
        "nurtured": nurtured,
        "discarded": discarded,
        "needs_review": needs_review,
    }