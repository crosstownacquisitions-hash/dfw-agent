from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.logger import get_logger
from domain.arv_from_comps import ComparableSale, arv_from_comps
from domain.consensus import SourceValue, weighted_consensus
from tools.providers.comps_provider import get_comps
from tools.providers.goliath_provider import get_avm
from tools.data.lineage import record_lineage

log = get_logger(__name__)


@dataclass(frozen=True)
class CompsOutput:
    arv: float | None
    comps: list[dict[str, Any]]
    meta: dict[str, Any]


def estimate_arv(
    *,
    lead_id: str,
    run_id: str,
    address: str,
    city: str,
    state: str,
    zip_code: str,
    subject_sqft: float | None,
) -> CompsOutput:
    comps_raw = get_comps(address, city=city, state=state, zip_code=zip_code)
    comps_list = comps_raw.get("comps", []) or []

    # Convert to ComparableSale where possible
    comp_objs: list[ComparableSale] = []
    for c in comps_list:
        try:
            comp_objs.append(
                ComparableSale(
                    address=str(c.get("address","")),
                    sale_price=float(c.get("sale_price") or c.get("price") or 0.0),
                    sqft=float(c.get("sqft") or 0.0),
                    beds=c.get("beds"),
                    baths=c.get("baths"),
                    sold_date=str(c.get("sold_date") or ""),
                    distance_mi=c.get("distance_mi"),
                    source=str(c.get("source") or "comps"),
                )
            )
        except Exception:
            continue

    arv_from_comp_math = arv_from_comps(subject_sqft, comp_objs)

    avm = get_avm(address, city=city, state=state, zip_code=zip_code)
    goliath_arv = avm.get("arv")

    selected, sources_payload, selected_by = weighted_consensus(
        [
            SourceValue(source="comps_median_ppsf", value=arv_from_comp_math, confidence=0.65, weight=1.0,
                        meta={"n_comps": len(comp_objs)}),
            SourceValue(source="goliath_avm", value=goliath_arv, confidence=avm.get("confidence"), weight=1.1,
                        meta=avm.get("meta")),
        ]
    )

    record_lineage(
        lead_id=lead_id,
        run_id=run_id,
        entity="underwrite",
        field="arv",
        value=selected,
        sources=sources_payload,
        selected_by=selected_by,
    )

    return CompsOutput(arv=selected, comps=comps_list, meta={"selected_by": selected_by, "sources": sources_payload})
