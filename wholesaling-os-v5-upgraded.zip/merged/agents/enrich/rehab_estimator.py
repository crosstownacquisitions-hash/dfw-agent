from __future__ import annotations

from dataclasses import dataclass

from domain.rehab_rules import estimate_rehab_budget
from tools.data.lineage import record_lineage


@dataclass(frozen=True)
class RehabOutput:
    rehab: float | None
    tier: str
    meta: dict


def estimate_rehab(
    *,
    lead_id: str,
    run_id: str,
    sqft: int | None,
    year_built: int | None,
    condition_hint: str = "",
) -> RehabOutput:
    rehab, tier, meta = estimate_rehab_budget(sqft=sqft, year_built=year_built, condition_hint=condition_hint)
    record_lineage(
        lead_id=lead_id,
        run_id=run_id,
        entity="underwrite",
        field="rehab",
        value=rehab,
        sources=[{"source":"rules_engine","value":rehab,"meta":meta}],
        selected_by="rehab_rules_v1",
    )
    return RehabOutput(rehab=rehab, tier=tier, meta=meta)
