from __future__ import annotations

"""Enrichment agent — parallel batch enrichment of leads.

For each lead this agent:
1. Fetches comps (from CSV or comps_provider)
2. Estimates ARV using weighted consensus (comps > AVM > LLM)
3. Estimates rehab from condition + sqft
4. Records lineage for every computed field
5. Returns enriched lead dict

Parallel execution: uses ThreadPoolExecutor for concurrent enrichment
(bounded by LLM_CONCURRENT from config).
"""

import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from agents.llm import call_llm
from agents.comps_adapter import get_comps_from_csv
from domain.arv_from_comps import arv_from_comps
from domain.math import rehab_estimate_from_tags
from tools.providers.lineage import LineageGraph, LineageSource, consensus_arv
from tools.cache.redis_cache import cached
from infrastructure.task_registry import register_task

log = logging.getLogger(__name__)

_lineage = LineageGraph()


@cached(ttl=86400, key_prefix="comps")
def _get_comps_cached(address: str, city: str, zip_code: str) -> list[dict]:
    """Cached comps lookup — returns serializable dicts."""
    comps_path = os.getenv("COMPS_CSV_PATH", "data/comps.csv")
    comps = get_comps_from_csv(
        comps_csv_path=comps_path,
        subject_city=city,
        subject_state="TX",
        subject_zip=zip_code,
        limit=25,
    )
    return [
        {"address": c.address, "sale_price": c.sale_price, "sqft": c.sqft, "sold_date": c.sold_date}
        for c in comps
    ]


def _arv_from_comps_dicts(subject_sqft: float | None, comps_dicts: list[dict]) -> float | None:
    """Re-hydrate comp dicts and compute ARV."""
    from domain.arv_from_comps import ComparableSale, arv_from_comps as _arv_fn
    comps = [ComparableSale(
        address=c["address"],
        sale_price=c["sale_price"],
        sqft=c["sqft"],
        sold_date=c.get("sold_date", ""),
        source="csv",
    ) for c in comps_dicts]
    return _arv_fn(subject_sqft, comps)


def _llm_arv_estimate(lead: dict) -> tuple[float | None, float]:
    """LLM ARV fallback. Returns (arv, confidence)."""
    import json
    prompt = (
        "You are a DFW residential real estate underwriting assistant. "
        "Estimate ARV in USD for the subject property. "
        'Return ONLY JSON: {"arv": number|null, "confidence": "Low"|"Med"|"High"}. '
        "Insufficient info: set arv null and confidence Low.\n\n"
        f"Address: {lead.get('address','')} {lead.get('city','')} TX {lead.get('zip','')}\n"
        f"Type: {lead.get('property_type','SFH')}, Beds: {lead.get('beds')}, "
        f"Baths: {lead.get('baths')}, Sqft: {lead.get('sqft')}, Year: {lead.get('year_built')}\n"
        f"Asking: {lead.get('asking_price')}\n"
    )
    raw = call_llm(prompt, feature="arv_estimate")
    if not raw:
        return None, 0.0
    try:
        obj = json.loads(raw)
        arv_val = obj.get("arv")
        conf_map = {"Low": 0.40, "Med": 0.65, "High": 0.85}
        conf = conf_map.get(obj.get("confidence", "Low"), 0.40)
        return (float(arv_val) if arv_val else None), conf
    except Exception:
        return None, 0.0


def enrich_lead(lead: dict) -> dict:
    """Enrich a single lead with ARV, rehab, and lineage."""
    lead_id  = lead.get("lead_id", "")
    address  = lead.get("address", "")
    city     = lead.get("city", "")
    zip_code = lead.get("zip", "")
    sqft     = int(lead["sqft"]) if lead.get("sqft") else None
    condition = lead.get("condition", "unknown")

    # 1. Comps-based ARV
    comps_dicts = _get_comps_cached(address, city, zip_code)
    comps_arv_val = _arv_from_comps_dicts(sqft, comps_dicts) if comps_dicts else None
    comps_conf = 0.85 if comps_arv_val and len(comps_dicts) >= 3 else (0.55 if comps_arv_val else 0.0)

    # 2. AVM from lead data
    avm_val = None
    try:
        avm_raw = lead.get("avm") or lead.get("AVM")
        if avm_raw:
            avm_val = float(str(avm_raw).replace("$", "").replace(",", ""))
    except Exception:
        pass

    # 3. LLM estimate
    model_arv, model_conf = _llm_arv_estimate(lead)

    # 4. Weighted consensus
    final_arv, final_conf, method = consensus_arv(
        lead_id,
        _lineage,
        comps_arv=comps_arv_val,
        comps_confidence=comps_conf,
        model_arv=model_arv,
        model_confidence=model_conf,
        avm=avm_val,
        avm_confidence=0.60,
    )

    # 5. Rehab estimate
    rehab = rehab_estimate_from_tags(sqft=sqft, condition=condition)
    _lineage.record(
        lead_id, "rehab",
        sources=[LineageSource("rehab_estimator", rehab, 0.75)],
        selected_value=rehab,
        method="heuristic",
    )

    enriched = dict(lead)
    enriched["arv"]             = final_arv
    enriched["arv_confidence"]  = final_conf
    enriched["arv_method"]      = method
    enriched["rehab"]           = rehab
    enriched["comps_count"]     = len(comps_dicts)
    return enriched


@register_task("agents.enrich.enrichment_agent:enrich_batch")
def enrich_batch(run_id: str, leads: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """Parallel batch enrichment."""
    if not leads:
        return {"run_id": run_id, "enriched": 0}

    from config import LLM_CONCURRENT
    max_workers = int(os.getenv("ENRICH_WORKERS", str(LLM_CONCURRENT)))

    enriched_leads: list[dict] = []
    failed = 0

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(enrich_lead, lead): lead for lead in leads}
        for future in as_completed(futures):
            try:
                enriched_leads.append(future.result())
            except Exception as exc:
                log.warning("Enrichment failed for lead: %s", exc)
                enriched_leads.append(futures[future])  # pass through unenriched
                failed += 1

    log.info("Enrichment complete: %d enriched, %d failed", len(enriched_leads) - failed, failed)
    return {"run_id": run_id, "enriched": len(enriched_leads), "failed": failed, "leads": enriched_leads}
