from __future__ import annotations

"""Buyer matcher — finds best-fit cash buyers for each pursued deal.

Matching criteria:
  1. Target zip proximity (haversine within max_zip_distance_miles)
  2. Price range overlap (buyer's max_price vs our MAO ± tolerance)
  3. Property type match (SFH, MF, etc.)
  4. Buyer score (past closings, response rate)

Outputs:
  - out/dispo_matches.csv  (lead_id → ranked buyer list)
"""

import csv
import logging
import math
import os
from dataclasses import dataclass
from typing import Any

from infrastructure.task_registry import register_task
from tools.cache.redis_cache import cached

log = logging.getLogger(__name__)


@dataclass
class BuyerMatch:
    buyer_id: str
    buyer_name: str
    match_score: float   # 0–1
    reason: str


def _haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in miles."""
    R = 3958.8
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlam = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


@cached(ttl=3600, key_prefix="buyers_csv")
def _load_buyers(buyers_csv: str) -> list[dict]:
    if not os.path.exists(buyers_csv):
        return []
    buyers = []
    with open(buyers_csv, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            buyers.append(row)
    return buyers


def _score_match(lead: dict, buyer: dict, max_dist_mi: float = 30, price_tol: float = 0.25) -> tuple[float, str]:
    """Return (match_score 0–1, reason_string)."""
    reasons = []
    score = 0.0

    # Property type
    prop_type = (lead.get("property_type") or "SFH").upper()
    buyer_types_raw = (buyer.get("PropertyTypes") or buyer.get("property_types") or "SFH")
    buyer_types = {t.strip().upper() for t in buyer_types_raw.split(",")}
    if prop_type in buyer_types or "SFH" in buyer_types:
        score += 0.30
        reasons.append("type_match")
    else:
        return 0.0, "type_mismatch"

    # Price range
    mao = float(lead.get("mao_wholesale") or 0)
    buyer_max = float(buyer.get("MaxPrice") or buyer.get("max_price") or 0)
    if buyer_max > 0 and mao > 0:
        if mao <= buyer_max * (1 + price_tol):
            score += 0.35
            reasons.append("price_ok")
        else:
            score += 0.10
            reasons.append("price_high")

    # Location (by zip — simplified: treat zip difference as proximity proxy)
    lead_zip = str(lead.get("zip") or "")
    buyer_zips_raw = (buyer.get("TargetZips") or buyer.get("target_zips") or "")
    buyer_zips = {z.strip() for z in buyer_zips_raw.split(",") if z.strip()}
    if lead_zip in buyer_zips:
        score += 0.25
        reasons.append("zip_match")
    elif buyer_zips:
        # Partial credit for same area code prefix
        if any(bz[:3] == lead_zip[:3] for bz in buyer_zips):
            score += 0.10
            reasons.append("zip_nearby")
    else:
        score += 0.10  # no zip constraint = open market buyer

    # Buyer quality score
    buyer_score = float(buyer.get("BuyerScore") or buyer.get("buyer_score") or 0.5)
    score += buyer_score * 0.10

    return min(score, 1.0), ", ".join(reasons)


def match_buyers_for_lead(lead: dict, buyers: list[dict], max_buyers: int = 12, min_score: float = 0.35) -> list[BuyerMatch]:
    scored = []
    for buyer in buyers:
        match_score, reason = _score_match(lead, buyer)
        if match_score >= min_score:
            scored.append(BuyerMatch(
                buyer_id=str(buyer.get("BuyerID") or buyer.get("buyer_id") or ""),
                buyer_name=str(buyer.get("Name") or buyer.get("name") or "Unknown"),
                match_score=round(match_score, 3),
                reason=reason,
            ))
    scored.sort(key=lambda m: m.match_score, reverse=True)
    return scored[:max_buyers]


def _write_matches(rows: list[dict], path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    is_new = not os.path.exists(path)
    fields = ["lead_id", "address", "buyer_id", "buyer_name", "match_score", "reason"]
    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        if is_new:
            w.writeheader()
        w.writerows(rows)


@register_task("agents.dispositions.buyer_matcher:match_buyers")
def match_buyers(run_id: str, pursued_leads: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    if not pursued_leads:
        return {"run_id": run_id, "matches": 0}

    buyers_csv = os.getenv("BUYERS_CSV_PATH", "data/buyers.csv")
    buyers = _load_buyers(buyers_csv)

    if not buyers:
        log.warning("No buyers loaded — check BUYERS_CSV_PATH=%s", buyers_csv)
        return {"run_id": run_id, "matches": 0, "warning": "no buyers loaded"}

    rows = []
    total_matches = 0
    for lead in pursued_leads:
        matches = match_buyers_for_lead(lead, buyers)
        total_matches += len(matches)
        for m in matches:
            rows.append({
                "lead_id":    lead.get("lead_id", ""),
                "address":    lead.get("address", ""),
                "buyer_id":   m.buyer_id,
                "buyer_name": m.buyer_name,
                "match_score": m.match_score,
                "reason":     m.reason,
            })
        log.info("Matched %d buyers for %s", len(matches), lead.get("address", ""))

    if rows:
        _write_matches(rows, "out/dispo_matches.csv")

    return {"run_id": run_id, "leads_matched": len(pursued_leads), "total_buyer_matches": total_matches}
