from __future__ import annotations
"""Deal room builder — assembles buyer-facing deal packets."""
import logging
from agents.llm import call_llm
from infrastructure.task_registry import register_task

log = logging.getLogger(__name__)

@register_task("agents.dispositions.dealroom_builder:build")
def build(run_id: str, lead: dict | None = None) -> dict:
    if not lead:
        return {"run_id": run_id, "built": False}
    addr   = lead.get("address","")
    arv    = lead.get("arv") or 0
    mao_w  = lead.get("mao_wholesale") or 0
    rehab  = lead.get("rehab") or 0
    spread = max(arv * 0.70 - rehab - mao_w, 0)
    prompt = (
        f"Write a 3-sentence cash buyer deal summary for {addr}. "
        f"ARV: ${arv:,.0f}. Estimated repairs: ${rehab:,.0f}. "
        f"Assignment fee opportunity: ~${spread:,.0f}. Be specific, factual, concise."
    )
    summary = call_llm(prompt, feature="dealroom") or (
        f"{addr} | ARV ~${arv:,.0f} | Repairs ~${rehab:,.0f} | "
        f"Potential spread ~${spread:,.0f} | Cash, as-is, fast close."
    )
    log.info("Deal room built for %s", addr)
    return {"run_id": run_id, "built": True, "address": addr, "summary": summary}
