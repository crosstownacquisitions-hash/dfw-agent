from __future__ import annotations
"""Dispo outreach agent — generates buyer blast messages."""
import csv, logging, os
from agents.llm import call_llm
from infrastructure.task_registry import register_task

log = logging.getLogger(__name__)

@register_task("agents.dispositions.dispo_outreach_agent:generate_blasts")
def generate_blasts(run_id: str, matches: list | None = None) -> dict:
    if not matches:
        return {"run_id": run_id, "blasts": 0}
    rows, count = [], 0
    for match in matches:
        addr   = match.get("address","")
        buyer  = match.get("buyer_name","Cash Buyer")
        arv    = match.get("arv") or 0
        mao_w  = match.get("mao_wholesale") or 0
        prompt = (
            f"Write a 2-sentence SMS blast to a cash buyer named {buyer} about {addr}. "
            f"ARV ~${arv:,.0f}, asking ${mao_w:,.0f}. Professional, urgent, concise."
        )
        msg = call_llm(prompt, feature="dispo_blast") or (
            f"HOT DEAL: {addr} | ARV ~${arv:,.0f} | Price ${mao_w:,.0f} | Cash/AS-IS. Interested?"
        )
        rows.append({"lead_id": match.get("lead_id",""), "buyer_name": buyer, "address": addr, "message": msg})
        count += 1
    os.makedirs("out/buyer_blasts", exist_ok=True)
    path = f"out/buyer_blasts/blasts_{run_id}.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["lead_id","buyer_name","address","message"])
        w.writeheader(); w.writerows(rows)
    log.info("Generated %d buyer blast messages", count)
    return {"run_id": run_id, "blasts": count, "output": path}
