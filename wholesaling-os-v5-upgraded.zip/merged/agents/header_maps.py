from __future__ import annotations

"""Header maps.

- DealSauce CSV headers -> canonical field names
- canonical field names -> Notion property names (YOUR Notion property names)
"""

from typing import Dict

# DealSauce CSV headers → canonical
DEALSAUCE_TO_CANONICAL: Dict[str, str] = {
    # identity
    "Lead ID": "lead_id",
    "LeadId": "lead_id",
    "LeadID": "lead_id",
    "PropertyAddress": "address",
    "Address": "address",
    "PropertyCity": "city",
    "City": "city",
    "PropertyState": "state",
    "State": "state",
    "PropertyPostalCode": "zip",
    "PostalCode": "zip",
    "Zip": "zip",

    "PropertyType": "property_type",
    "Type": "property_type",

    # values
    "AVM": "avm",
    "MarketValue": "market_value",
    "WholesaleValue": "wholesale_value",

    # physical
    "SquareFootage": "sqft",
    "Sqft": "sqft",
    "Beds": "beds",
    "Baths": "baths",
    "YearBuilt": "year_built",

    # misc/context (optional)
    "Condition": "condition",
    "SellerMessage": "seller_message",
    "AskingPrice": "seller_asking",
    "SellerAsking": "seller_asking",
    "BehindMonths": "behind_months",
    "PaymentBehindMonths": "behind_months",
    "DOM": "dom",
}

# canonical → Notion Leads DB property names (CONFIRMED)
CANONICAL_TO_NOTION_LEADS: Dict[str, str] = {
    "address": "Address",
    "lead_id": "Lead ID",
    "status": "Status",                # optional if provided
    "decision": "Decision",
    "source": "Source",                # optional if provided
    "property_type": "Type",
    "state": "State",
    "city": "City",
    "zip": "Zip",

    # computed write-back:
    "arv_est": "ARV",
    "repairs_est": "Rehab",
    "mao_flip": "MAO Flip",
    "mao_wholesale": "MAO Wholesale",
    "deal_score": "Deal Score",
    "sweet_spot": "Wholesale Sweet Spot",

    # idempotency (stores hash as rich text)
    "last_updated_hash": "Last Updated",
}

# canonical → Notion Underwriting DB property names (CONFIRMED)
CANONICAL_TO_NOTION_UNDERWRITING: Dict[str, str] = {
    # Title field is "Deal" in your Underwriting DB
    "deal_key": "Deal",
    "lead_page_id": "Lead",  # relation
    "decision": "Decision",
    "arv_est": "ARV",
    "repairs_est": "Rehab",
    "mao_flip": "MAO Flip",
    "mao_wholesale": "MAO Wholesale",
    "deal_score": "Deal Score",
    "notes": "Notes",
}
