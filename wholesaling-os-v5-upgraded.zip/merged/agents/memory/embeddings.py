from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass
from typing import Iterable

import numpy as np

from app.settings import settings

try:
    from litellm import embedding as litellm_embedding  # type: ignore
except Exception:  # pragma: no cover
    litellm_embedding = None


@dataclass(frozen=True)
class EmbeddingResult:
    vector: list[float]
    provider: str


def _hash_embed(text: str, dim: int = 256) -> list[float]:
    """Cheap, deterministic embedding.

    Uses token hashing into a fixed-size vector, L2-normalized. Good enough for lightweight memory retrieval
    without external embedding costs.
    """
    v = np.zeros(dim, dtype=np.float32)
    for tok in text.lower().split():
        h = int(hashlib.sha256(tok.encode("utf-8")).hexdigest(), 16)
        v[h % dim] += 1.0
    n = float(np.linalg.norm(v))
    if n > 0:
        v /= n
    return v.astype(float).tolist()


def embed(text: str) -> EmbeddingResult:
    model = getattr(settings, "embedding_model", "") if hasattr(settings, "embedding_model") else ""
    if model and litellm_embedding is not None:
        # litellm supports provider routing via model string
        res = litellm_embedding(model=model, input=[text])
        vec = res["data"][0]["embedding"]
        # normalize
        norm = math.sqrt(sum(x * x for x in vec)) or 1.0
        vec = [float(x) / norm for x in vec]
        return EmbeddingResult(vector=vec, provider=f"litellm:{model}")
    return EmbeddingResult(vector=_hash_embed(text), provider="hash")
