from __future__ import annotations

"""Agent memory: two implementations, both available.

VectorStore (file-based, V5)
    Lightweight TF-IDF cosine similarity. Zero extra deps. Persists to disk.
    Used by CriticAgent, PlannerAgent, and all existing agent code.
    get_store(namespace) → VectorStore instance.

VectorMemoryStore (DB-backed, Premier)
    Cosine similarity over PostgreSQL rows using hash or LiteLLM embeddings.
    Survives container restarts. Upgrades to real embeddings with zero code
    change by setting EMBEDDING_MODEL=text-embedding-3-small in .env.
    Use when you need persistence across restarts or SQL queryability.
"""

# ---------------------------------------------------------------------------
# V5 file-based VectorStore (unchanged — keeps all existing agent code working)
# ---------------------------------------------------------------------------

import hashlib
import json
import logging
import math
import os
import re
import time
from typing import Any

log = logging.getLogger(__name__)

_STORE_DIR = os.path.join("out", "memory")


def _tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


def _tfidf_vector(tokens: list[str], vocab: dict[str, int]) -> list[float]:
    from collections import Counter
    counts = Counter(tokens)
    vec = [0.0] * len(vocab)
    for tok, cnt in counts.items():
        if tok in vocab:
            vec[vocab[tok]] = 1 + math.log(cnt) if cnt > 0 else 0.0
    return vec


def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


class MemoryRecord:
    __slots__ = ("key", "text", "payload", "tokens", "ts", "confidence", "outcome")

    def __init__(
        self,
        key: str,
        text: str,
        payload: dict[str, Any],
        confidence: float = 1.0,
        outcome: str | None = None,
    ):
        self.key = key
        self.text = text
        self.payload = payload
        self.tokens = _tokenize(text)
        self.ts = time.time()
        self.confidence = confidence
        self.outcome = outcome


class VectorStore:
    """Lightweight persistent vector memory (file-backed, TF-IDF cosine)."""

    def __init__(self, namespace: str = "default", max_records: int = 5_000):
        self.namespace = namespace
        self.max_records = max_records
        self._records: list[MemoryRecord] = []
        self._vocab: dict[str, int] = {}
        os.makedirs(_STORE_DIR, exist_ok=True)
        self._path = os.path.join(_STORE_DIR, f"{namespace}.json")
        self._load()

    def add(
        self,
        key: str,
        payload: dict[str, Any],
        *,
        text: str | None = None,
        confidence: float = 1.0,
        outcome: str | None = None,
    ) -> None:
        if text is None:
            text = json.dumps(payload, default=str)
        self._records = [r for r in self._records if r.key != key]
        rec = MemoryRecord(key, text, payload, confidence=confidence, outcome=outcome)
        self._records.append(rec)
        for tok in rec.tokens:
            if tok not in self._vocab:
                self._vocab[tok] = len(self._vocab)
        if len(self._records) > self.max_records:
            self._records = sorted(self._records, key=lambda r: r.ts)
            self._records = self._records[-self.max_records:]
        self._save()

    def update_outcome(self, key: str, outcome: str, confidence: float | None = None) -> None:
        for rec in self._records:
            if rec.key == key:
                rec.outcome = outcome
                if confidence is not None:
                    rec.confidence = confidence
        self._save()

    def search(self, query: str, top_k: int = 5, min_score: float = 0.05) -> list[dict[str, Any]]:
        if not self._records:
            return []
        q_tokens = _tokenize(query)
        q_vec = _tfidf_vector(q_tokens, self._vocab)
        scored: list[tuple[float, MemoryRecord]] = []
        for rec in self._records:
            rv = _tfidf_vector(rec.tokens, self._vocab)
            sim = _cosine(q_vec, rv)
            if sim >= min_score:
                scored.append((sim, rec))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [
            {
                "key": r.key,
                "similarity": round(s, 4),
                "payload": r.payload,
                "outcome": r.outcome,
                "confidence": r.confidence,
                "ts": r.ts,
            }
            for s, r in scored[:top_k]
        ]

    def get(self, key: str) -> dict[str, Any] | None:
        for rec in self._records:
            if rec.key == key:
                return {"key": rec.key, "payload": rec.payload, "outcome": rec.outcome}
        return None

    def stats(self) -> dict[str, Any]:
        outcomes = [r.outcome for r in self._records if r.outcome]
        return {
            "namespace": self.namespace,
            "records": len(self._records),
            "vocab_size": len(self._vocab),
            "outcomes_recorded": len(outcomes),
            "outcome_breakdown": {o: outcomes.count(o) for o in set(outcomes)},
        }

    def _save(self) -> None:
        try:
            data = {
                "vocab": self._vocab,
                "records": [
                    {
                        "key": r.key,
                        "text": r.text,
                        "payload": r.payload,
                        "ts": r.ts,
                        "confidence": r.confidence,
                        "outcome": r.outcome,
                    }
                    for r in self._records
                ],
            }
            with open(self._path, "w", encoding="utf-8") as f:
                json.dump(data, f)
        except Exception as exc:
            log.warning("VectorStore save failed: %s", exc)

    def _load(self) -> None:
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._vocab = data.get("vocab", {})
            for row in data.get("records", []):
                rec = MemoryRecord(
                    key=row["key"],
                    text=row["text"],
                    payload=row["payload"],
                    confidence=row.get("confidence", 1.0),
                    outcome=row.get("outcome"),
                )
                rec.ts = row.get("ts", time.time())
                self._records.append(rec)
        except Exception as exc:
            log.warning("VectorStore load failed: %s", exc)


_stores: dict[str, VectorStore] = {}


def get_store(namespace: str = "leads") -> VectorStore:
    """Get or create a file-backed VectorStore for the given namespace."""
    if namespace not in _stores:
        _stores[namespace] = VectorStore(namespace=namespace)
    return _stores[namespace]


# ---------------------------------------------------------------------------
# Premier DB-backed VectorMemoryStore
# ---------------------------------------------------------------------------

from dataclasses import dataclass
from datetime import datetime, timezone
import numpy as np


@dataclass(frozen=True)
class MemoryWrite:
    namespace: str
    key: str
    text: str
    meta: dict[str, Any] | None = None
    outcome_label: str = ""
    confidence: float | None = None


@dataclass(frozen=True)
class MemoryHit:
    id: int
    key: str
    text: str
    score: float
    meta: dict[str, Any] | None


class VectorMemoryStore:
    """DB-backed vector memory with cosine similarity retrieval.

    Uses hash embeddings (zero cost) by default. Set EMBEDDING_MODEL=
    text-embedding-3-small in .env for real semantic search — zero code change.
    Requires MemoryItem table (auto-created by init_db()).
    """

    def add(self, w: MemoryWrite) -> int:
        from agents.memory.embeddings import embed
        from tools.data.repo import SessionLocal
        from tools.data.models import MemoryItem
        er = embed(w.text)
        now = datetime.now(timezone.utc)
        with SessionLocal() as s:
            item = MemoryItem(
                namespace=w.namespace,
                key=w.key,
                text=w.text,
                embedding=er.vector,
                meta=w.meta,
                outcome_label=w.outcome_label,
                confidence=w.confidence,
                created_at=now,
            )
            s.add(item)
            s.commit()
            s.refresh(item)
            return int(item.id)

    def search(self, namespace: str, query: str, k: int = 5) -> list[MemoryHit]:
        from agents.memory.embeddings import embed
        from tools.data.repo import SessionLocal
        from tools.data.models import MemoryItem
        q = np.array(embed(query).vector, dtype=np.float32)
        with SessionLocal() as s:
            items = (
                s.query(MemoryItem)
                .filter(MemoryItem.namespace == namespace)
                .order_by(MemoryItem.id.desc())
                .limit(500)
                .all()
            )
        hits: list[MemoryHit] = []
        for it in items:
            if not it.embedding:
                continue
            v = np.array(it.embedding, dtype=np.float32)
            score = float(np.dot(q, v) / ((np.linalg.norm(q) * np.linalg.norm(v)) + 1e-9))
            hits.append(MemoryHit(id=int(it.id), key=str(it.key), text=str(it.text), score=score, meta=it.meta))
        hits.sort(key=lambda x: x.score, reverse=True)
        return hits[:k]
