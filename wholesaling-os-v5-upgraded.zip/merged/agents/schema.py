from __future__ import annotations

"""Canonical schema layer.

This module defines the *canonical* field names used internally across:
- CSV imports (DealSauce -> canonical)
- Underwriting outputs (engine -> canonical)
- Notion sync write-backs (canonical -> Notion)

The goal is to keep all downstream logic stable even if upstream CSV headers change.
"""

from dataclasses import dataclass
from typing import List, Set


# Canonical "truth" schema (inputs)
CANONICAL_INPUT_FIELDS: List[str] = [
    "lead_id",
    "address",
    "city",
    "state",
    "zip",
    "property_type",
    "avm",
    "market_value",
    "wholesale_value",
    "sqft",
    "beds",
    "baths",
    "year_built",
    "condition",
    "seller_message",
    "seller_asking",
    "behind_months",
    "dom",
]

REQUIRED_INPUT_FIELDS: Set[str] = {"address", "city", "state", "zip"}
OPTIONAL_INPUT_FIELDS: Set[str] = set(CANONICAL_INPUT_FIELDS) - set(REQUIRED_INPUT_FIELDS)


# Canonical computed outputs we write back (to Notion + exports)
CANONICAL_OUTPUT_FIELDS: List[str] = [
    "deal_key",
    "arv_est",
    "repairs_est",
    "mao_flip",
    "mao_wholesale",
    "deal_score",
    "decision",
    "sweet_spot",
    "last_updated_hash",
]
