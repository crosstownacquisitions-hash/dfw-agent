from __future__ import annotations

import hashlib
from typing import Any, Dict, List


def row_hash(record: Dict[str, Any], fields: List[str]) -> str:
    """Stable SHA-256 hash (truncated) across a subset of fields.

    Used to ensure idempotent Notion upserts (avoid API spam).
    """
    parts: list[str] = []
    for f in fields:
        v = record.get(f, "")
        parts.append("" if v is None else str(v).strip())
    payload = "|".join(parts)
    return hashlib.sha256(payload.encode("utf-8", errors="ignore")).hexdigest()[:24]
