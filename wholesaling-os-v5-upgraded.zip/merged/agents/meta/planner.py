from __future__ import annotations

"""PlannerAgent — goal decomposition and subtask orchestration.

Given a high-level goal (e.g. "underwrite today's DFW leads") the planner:
1. Retrieves similar past runs from vector memory.
2. Emits a structured execution plan with ordered subtasks.
3. Writes the plan + confidence to shared state.

The planner is lightweight by default (heuristic): it only calls the LLM when
the goal is novel (no close memory match) or explicitly requested.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any

from agents.memory.vector_store import get_store
from agents.llm import call_llm

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class Subtask:
    task_id: str
    name: str
    agent: str           # dotted path: "workflows.daily_run:run"
    priority: int = 5    # 1 = highest
    depends_on: list[str] = field(default_factory=list)
    params: dict[str, Any] = field(default_factory=dict)
    rationale: str = ""


@dataclass
class ExecutionPlan:
    goal: str
    run_id: str
    subtasks: list[Subtask]
    confidence: float        # 0–1
    source: str              # "heuristic" | "llm" | "memory"
    created_at: float = field(default_factory=time.time)

    def ordered(self) -> list[Subtask]:
        return sorted(self.subtasks, key=lambda t: t.priority)

    def to_dict(self) -> dict[str, Any]:
        return {
            "goal": self.goal,
            "run_id": self.run_id,
            "confidence": self.confidence,
            "source": self.source,
            "subtasks": [
                {
                    "task_id": t.task_id,
                    "name": t.name,
                    "agent": t.agent,
                    "priority": t.priority,
                    "depends_on": t.depends_on,
                    "params": t.params,
                    "rationale": t.rationale,
                }
                for t in self.ordered()
            ],
        }


# ---------------------------------------------------------------------------
# Default heuristic plan (no LLM needed for standard daily run)
# ---------------------------------------------------------------------------

_STANDARD_DAILY_PLAN: list[dict[str, Any]] = [
    {
        "task_id": "ingest",
        "name": "Ingest new leads",
        "agent": "agents.ingest.lead_ingestor:ingest",
        "priority": 1,
        "depends_on": [],
        "rationale": "Pull new leads from Notion before underwriting.",
    },
    {
        "task_id": "enrich",
        "name": "Enrich leads with comps and condition data",
        "agent": "agents.enrich.enrichment_agent:enrich_batch",
        "priority": 2,
        "depends_on": ["ingest"],
        "rationale": "ARV and condition data required for accurate MAO.",
    },
    {
        "task_id": "underwrite",
        "name": "Underwrite and score all enriched leads",
        "agent": "workflows.daily_run:run",
        "priority": 3,
        "depends_on": ["enrich"],
        "rationale": "Core deal scoring pipeline.",
    },
    {
        "task_id": "offers",
        "name": "Generate offer strategies for pursued deals",
        "agent": "agents.acquisitions.offer_agent:generate_offers",
        "priority": 4,
        "depends_on": ["underwrite"],
        "rationale": "Produce LAO/Anchor/WalkAway ladder for each PURSUE_OFFER decision.",
    },
    {
        "task_id": "dispo",
        "name": "Match buyers and build dealrooms",
        "agent": "agents.dispositions.buyer_matcher:match_buyers",
        "priority": 5,
        "depends_on": ["underwrite"],
        "rationale": "Start building buyer pipeline in parallel with offers.",
    },
    {
        "task_id": "qa",
        "name": "QA audit and optimize scoring weights",
        "agent": "agents.quality.qa_auditor:audit_run",
        "priority": 6,
        "depends_on": ["underwrite"],
        "rationale": "Flag anomalies and tune weights from outcome data.",
    },
    {
        "task_id": "reflect",
        "name": "Reflect and write to memory",
        "agent": "agents.meta.critic:reflect_on_run",
        "priority": 7,
        "depends_on": ["qa"],
        "rationale": "Critic evaluates run quality and persists learnings.",
    },
]


# ---------------------------------------------------------------------------
# Planner
# ---------------------------------------------------------------------------

class PlannerAgent:
    """Decomposes goals into subtask plans using memory + optional LLM."""

    SIMILARITY_THRESHOLD = 0.55  # Use memory plan if similarity >= this

    def __init__(self):
        self.memory = get_store("plans")

    def plan(self, run_id: str, goal: str, context: dict[str, Any] | None = None) -> ExecutionPlan:
        ctx = context or {}

        # 1. Check memory for similar past plans
        similar = self.memory.search(goal, top_k=3)
        best_match = similar[0] if similar else None

        if best_match and best_match["similarity"] >= self.SIMILARITY_THRESHOLD:
            past_subtasks = best_match["payload"].get("subtasks", [])
            if past_subtasks:
                subtasks = [Subtask(**t) for t in past_subtasks]
                plan = ExecutionPlan(
                    goal=goal,
                    run_id=run_id,
                    subtasks=subtasks,
                    confidence=best_match["similarity"],
                    source="memory",
                )
                log.info("PlannerAgent used memory plan (sim=%.2f)", best_match["similarity"])
                self._store_plan(run_id, goal, plan)
                return plan

        # 2. Detect standard daily run
        if any(kw in goal.lower() for kw in ("daily", "wholesale", "dfw", "leads", "deal")):
            subtasks = [
                Subtask(**{k: v for k, v in t.items()})
                for t in _STANDARD_DAILY_PLAN
            ]
            # Inject run params
            for st in subtasks:
                st.params["run_id"] = run_id
                if "limit" in ctx:
                    st.params["limit"] = ctx["limit"]

            plan = ExecutionPlan(
                goal=goal,
                run_id=run_id,
                subtasks=subtasks,
                confidence=0.92,
                source="heuristic",
            )
            self._store_plan(run_id, goal, plan)
            return plan

        # 3. Novel goal — ask LLM to decompose
        plan = self._llm_plan(run_id, goal, ctx)
        self._store_plan(run_id, goal, plan)
        return plan

    def _llm_plan(self, run_id: str, goal: str, context: dict[str, Any]) -> ExecutionPlan:
        prompt = (
            "You are an orchestration planner for a DFW real estate wholesale OS. "
            "Given the goal below, output a JSON execution plan.\n\n"
            f"Goal: {goal}\nContext: {json.dumps(context)}\n\n"
            "Return ONLY valid JSON:\n"
            '{"subtasks": [{"task_id": str, "name": str, "agent": str, '
            '"priority": int, "depends_on": [str], "rationale": str}]}'
        )
        raw = call_llm(prompt, feature="planner")
        try:
            obj = json.loads(raw)
            subtasks = [Subtask(**t) for t in obj.get("subtasks", [])]
            if subtasks:
                return ExecutionPlan(goal=goal, run_id=run_id, subtasks=subtasks, confidence=0.70, source="llm")
        except Exception:
            pass

        # Fallback to heuristic plan on any LLM failure
        log.warning("PlannerAgent LLM failed; falling back to heuristic plan")
        return ExecutionPlan(
            goal=goal,
            run_id=run_id,
            subtasks=[Subtask(**{k: v for k, v in t.items()}) for t in _STANDARD_DAILY_PLAN],
            confidence=0.60,
            source="heuristic_fallback",
        )

    def _store_plan(self, run_id: str, goal: str, plan: ExecutionPlan) -> None:
        self.memory.add(
            key=run_id,
            payload=plan.to_dict(),
            text=goal,
            confidence=plan.confidence,
        )
