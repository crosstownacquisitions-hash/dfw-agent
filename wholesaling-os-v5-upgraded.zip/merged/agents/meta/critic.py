from __future__ import annotations

"""CriticAgent — post-run reflection and quality evaluation.

After each pipeline run the Critic:
1. Evaluates the run against expected benchmarks.
2. Flags anomalies (e.g. >80% DISCARD, zero pursued, ARV too clustered).
3. Generates a natural-language reflection.
4. Writes findings back to vector memory so future Planner/agents can learn.

Pattern: PlannerAgent → SubtaskAgents → CriticAgent → MemoryWrite
"""

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any

from agents.memory.vector_store import get_store
from agents.llm import call_llm
from infrastructure.task_registry import register_task

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Anomaly flags
# ---------------------------------------------------------------------------

@dataclass
class AnomalyFlag:
    code: str
    severity: str          # "low" | "medium" | "high"
    message: str
    value: Any = None


# ---------------------------------------------------------------------------
# Reflection report
# ---------------------------------------------------------------------------

@dataclass
class ReflectionReport:
    run_id: str
    flags: list[AnomalyFlag] = field(default_factory=list)
    overall_quality: float = 1.0   # 0–1
    narrative: str = ""
    recommendations: list[str] = field(default_factory=list)
    ts: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "overall_quality": self.overall_quality,
            "narrative": self.narrative,
            "flags": [{"code": f.code, "severity": f.severity, "message": f.message} for f in self.flags],
            "recommendations": self.recommendations,
            "ts": self.ts,
        }


# ---------------------------------------------------------------------------
# CriticAgent
# ---------------------------------------------------------------------------

class CriticAgent:
    # Expected healthy benchmarks
    MIN_PURSUE_RATE = 0.05      # At least 5% of processed leads pursued
    MAX_DISCARD_RATE = 0.80     # If >80% discarded, something is wrong
    MIN_PROCESSED = 1           # At least 1 lead processed to be meaningful

    def __init__(self):
        self.memory = get_store("reflections")
        self.plan_memory = get_store("plans")

    def evaluate(self, run_id: str, summary: dict[str, Any]) -> ReflectionReport:
        report = ReflectionReport(run_id=run_id)

        processed = summary.get("processed", 0)
        pursued = summary.get("pursued", 0)
        nurtured = summary.get("nurtured", 0)
        discarded = summary.get("discarded", 0)
        needs_review = summary.get("needs_review", 0)

        # ── Anomaly detection ──────────────────────────────────────────────

        if processed < self.MIN_PROCESSED:
            report.flags.append(AnomalyFlag(
                code="NO_LEADS_PROCESSED",
                severity="high",
                message="No leads were processed this run. Check Notion connection or lead source.",
            ))

        if processed > 0:
            discard_rate = discarded / processed
            pursue_rate = pursued / processed
            review_rate = needs_review / processed

            if discard_rate > self.MAX_DISCARD_RATE:
                report.flags.append(AnomalyFlag(
                    code="HIGH_DISCARD_RATE",
                    severity="medium",
                    message=f"Discard rate {discard_rate:.0%} exceeds threshold. Consider relaxing buy box.",
                    value=discard_rate,
                ))

            if pursue_rate < self.MIN_PURSUE_RATE and processed >= 10:
                report.flags.append(AnomalyFlag(
                    code="LOW_PURSUE_RATE",
                    severity="medium",
                    message=f"Pursue rate {pursue_rate:.1%} below minimum. ARV estimates may be too conservative.",
                    value=pursue_rate,
                ))

            if review_rate > 0.40:
                report.flags.append(AnomalyFlag(
                    code="HIGH_REVIEW_RATE",
                    severity="low",
                    message=f"Needs-review rate {review_rate:.0%} is high — many leads lack ARV data.",
                    value=review_rate,
                ))

        # ── Compute quality score ──────────────────────────────────────────

        penalty = sum(
            {"low": 0.02, "medium": 0.08, "high": 0.20}.get(f.severity, 0.05)
            for f in report.flags
        )
        report.overall_quality = max(1.0 - penalty, 0.0)

        # ── Generate narrative (LLM or heuristic) ─────────────────────────

        report.narrative = self._generate_narrative(summary, report)
        report.recommendations = self._recommendations(report)

        # ── Write to memory ────────────────────────────────────────────────

        self.memory.add(
            key=run_id,
            payload=report.to_dict(),
            text=f"Run {run_id}: {report.narrative}",
            confidence=report.overall_quality,
            outcome="reflected",
        )

        # Update plan memory with outcome
        self.plan_memory.update_outcome(
            run_id,
            outcome=f"quality={report.overall_quality:.2f}",
            confidence=report.overall_quality,
        )

        log.info(
            "CriticAgent reflection complete",
            extra={
                "run_id": run_id,
                "quality": report.overall_quality,
                "flags": len(report.flags),
            },
        )
        return report

    def _generate_narrative(self, summary: dict[str, Any], report: ReflectionReport) -> str:
        processed = summary.get("processed", 0)
        if processed == 0:
            return "Run completed with no leads processed — likely a connectivity or source issue."

        pursue_rate = summary.get("pursued", 0) / processed
        nuance = (
            "Pipeline performed well within normal parameters."
            if report.overall_quality >= 0.9
            else "Pipeline completed with notable anomalies that warrant attention."
        )
        return (
            f"Processed {processed} leads. Pursued {summary.get('pursued', 0)} ({pursue_rate:.1%}), "
            f"Nurtured {summary.get('nurtured', 0)}, Discarded {summary.get('discarded', 0)}, "
            f"Needs review {summary.get('needs_review', 0)}. {nuance}"
        )

    def _recommendations(self, report: ReflectionReport) -> list[str]:
        recs = []
        codes = {f.code for f in report.flags}

        if "HIGH_DISCARD_RATE" in codes:
            recs.append("Consider expanding buy box: raise max_arv or relax min_dom_days.")
        if "LOW_PURSUE_RATE" in codes:
            recs.append("Review ARV estimation model — may be systematically undervaluing properties.")
            recs.append("Lower pursue_threshold from 70 to 65 on next run as an experiment.")
        if "HIGH_REVIEW_RATE" in codes:
            recs.append("Ensure comps CSV or comps API is loaded — ARV null rate is too high.")
        if "NO_LEADS_PROCESSED" in codes:
            recs.append("Check NOTION_DB_LEADS env var and verify leads exist with Status=New.")

        if not recs:
            recs.append("No corrective actions required. Continue monitoring.")
        return recs


# ---------------------------------------------------------------------------
# Registered task
# ---------------------------------------------------------------------------

@register_task("agents.meta.critic:reflect_on_run")
def reflect_on_run(run_id: str, summary: dict[str, Any] | None = None) -> dict[str, Any]:
    if not summary:
        log.warning("CriticAgent called without summary for run_id=%s", run_id)
        return {"run_id": run_id, "skipped": True}

    report = CriticAgent().evaluate(run_id, summary)
    return report.to_dict()
