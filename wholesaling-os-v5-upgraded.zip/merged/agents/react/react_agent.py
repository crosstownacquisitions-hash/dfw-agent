from __future__ import annotations

"""ReAct agent base class.

Implements the Reason → Act → Observe loop for tool-using agents.

Pattern
-------
Thought: What do I need to do?
Tool:    call(tool_name, args)
Observation: result
... (repeat up to max_steps)
Answer: final answer

Each agent subclass registers its tools and defines a system prompt.
The loop terminates when the model emits "FINAL:" or max_steps is exceeded.

Usage
-----
class MyAgent(ReactAgent):
    SYSTEM = "You are a DFW deal analyzer."

    def tools(self):
        return {
            "estimate_arv": self._estimate_arv,
            "compute_mao": self._compute_mao,
        }

    def _estimate_arv(self, address: str, sqft: int) -> str:
        ...

result = MyAgent().run("Should I pursue 123 Main St, Dallas TX?")
"""

from __future__ import annotations

import json
import logging
import re
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable

from agents.llm import call_llm

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class ReActStep:
    step: int
    thought: str = ""
    tool: str = ""
    tool_args: dict[str, Any] = field(default_factory=dict)
    observation: str = ""
    ts: float = field(default_factory=time.time)


@dataclass
class ReActResult:
    goal: str
    answer: str
    steps: list[ReActStep]
    success: bool
    elapsed_s: float
    self_critique: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "goal": self.goal,
            "answer": self.answer,
            "success": self.success,
            "steps": len(self.steps),
            "elapsed_s": round(self.elapsed_s, 2),
            "self_critique": self.self_critique,
        }


# ---------------------------------------------------------------------------
# Base ReAct agent
# ---------------------------------------------------------------------------

_TOOL_CALL_RE = re.compile(
    r"Tool:\s*(\w+)\s*\(([^)]*)\)",
    re.IGNORECASE,
)
_FINAL_RE = re.compile(r"FINAL:\s*(.*)", re.IGNORECASE | re.DOTALL)


class ReactAgent(ABC):
    MAX_STEPS: int = 8
    SYSTEM: str = "You are a helpful real estate wholesale assistant."

    @abstractmethod
    def tools(self) -> dict[str, Callable[..., str]]:
        """Return mapping of tool_name -> callable."""
        ...

    def run(self, goal: str, context: dict[str, Any] | None = None) -> ReActResult:
        t0 = time.time()
        steps: list[ReActStep] = []
        tool_registry = self.tools()
        tool_desc = self._describe_tools(tool_registry)

        history = self._build_initial_prompt(goal, tool_desc, context or {})

        for step_num in range(1, self.MAX_STEPS + 1):
            step = ReActStep(step=step_num)

            response = call_llm(history, feature="react")
            if not response:
                step.thought = "[LLM unavailable — using heuristic]"
                steps.append(step)
                break

            # Parse response
            step.thought = response.strip()

            # Check for FINAL answer
            final_match = _FINAL_RE.search(response)
            if final_match:
                answer = final_match.group(1).strip()
                steps.append(step)
                critique = self._self_critique(goal, answer, steps)
                return ReActResult(
                    goal=goal,
                    answer=answer,
                    steps=steps,
                    success=True,
                    elapsed_s=time.time() - t0,
                    self_critique=critique,
                )

            # Parse and execute tool call
            tool_match = _TOOL_CALL_RE.search(response)
            if tool_match:
                tool_name = tool_match.group(1).strip()
                args_str = tool_match.group(2).strip()
                step.tool = tool_name

                # Parse args (key=value pairs or JSON)
                args = self._parse_args(args_str)
                step.tool_args = args

                if tool_name in tool_registry:
                    try:
                        obs = tool_registry[tool_name](**args)
                        step.observation = str(obs)
                    except Exception as exc:
                        step.observation = f"ERROR: {exc}"
                        log.warning("ReAct tool error (%s): %s", tool_name, exc)
                else:
                    step.observation = f"ERROR: Unknown tool '{tool_name}'. Available: {list(tool_registry)}"

                history = f"{history}\n\nThought: {step.thought}\nObservation: {step.observation}\n"
            else:
                # No tool call and no final — treat as internal thought
                history = f"{history}\n\nThought: {step.thought}\n"

            steps.append(step)

        # Max steps reached — extract best answer from last response
        last_thought = steps[-1].thought if steps else ""
        return ReActResult(
            goal=goal,
            answer=last_thought,
            steps=steps,
            success=False,
            elapsed_s=time.time() - t0,
            self_critique="Max steps reached without definitive answer.",
        )

    def _self_critique(self, goal: str, answer: str, steps: list[ReActStep]) -> str:
        """Quick self-critique to verify answer quality."""
        prompt = (
            f"Goal: {goal}\n"
            f"Answer: {answer}\n\n"
            "In ONE sentence, evaluate if this answer directly addresses the goal. "
            "Start with PASS or FAIL."
        )
        critique = call_llm(prompt, feature="self_critique")
        return critique or "Critique unavailable."

    def _build_initial_prompt(self, goal: str, tool_desc: str, context: dict[str, Any]) -> str:
        ctx_str = json.dumps(context, default=str) if context else "{}"
        return (
            f"{self.SYSTEM}\n\n"
            f"You solve goals step-by-step using the Thought→Tool→Observation pattern.\n"
            f"Available tools:\n{tool_desc}\n\n"
            f"To call a tool: Tool: tool_name(key=value, key2=value2)\n"
            f"When you have enough information: FINAL: <your answer>\n\n"
            f"Context: {ctx_str}\n"
            f"Goal: {goal}\n\n"
            f"Thought:"
        )

    def _describe_tools(self, registry: dict[str, Callable]) -> str:
        lines = []
        for name, fn in registry.items():
            doc = (fn.__doc__ or "").split("\n")[0].strip()
            lines.append(f"  {name}: {doc}")
        return "\n".join(lines)

    @staticmethod
    def _parse_args(args_str: str) -> dict[str, Any]:
        if not args_str.strip():
            return {}
        # Try JSON first
        try:
            if args_str.startswith("{"):
                return json.loads(args_str)
        except Exception:
            pass
        # Parse key=value pairs
        result: dict[str, Any] = {}
        for part in re.split(r",\s*(?=\w+=)", args_str):
            if "=" in part:
                k, _, v = part.partition("=")
                k = k.strip()
                v = v.strip().strip("\"'")
                # Try numeric conversion
                try:
                    result[k] = int(v)
                except ValueError:
                    try:
                        result[k] = float(v)
                    except ValueError:
                        result[k] = v
        return result
