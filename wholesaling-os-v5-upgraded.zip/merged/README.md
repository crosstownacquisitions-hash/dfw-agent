# Wholesaling OS v5 Unified

> Premier infrastructure + V5 agent implementations — one production-ready codebase.

## What's in here

This codebase merges two parallel development tracks:

**From Premier (infrastructure upgrades):**
- `tools/data/models.py` — `Lineage` + `MemoryItem` DB tables (field-level audit trail + persistent vector memory)
- `tools/data/lineage.py` — DB-backed lineage writer (`record_lineage()`); every ARV/rehab/MAO has a queryable row
- `agents/memory/embeddings.py` — zero-cost hash embeddings by default; set `EMBEDDING_MODEL=text-embedding-3-small` for real semantic search, zero code change
- `agents/memory/vector_store.py` — both file-based `VectorStore` (backward compat) and DB-backed `VectorMemoryStore`
- `domain/consensus.py` — `weighted_consensus()` using **weighted median** (outlier-resistant ARV consensus)
- `app/jwt_simple.py` + `app/auth.py` — zero-dependency HS256 JWT + scope-based access control (`runs:write`, `notion:write`)
- `app/middleware.py` + `app/metrics.py` — auto-instruments every HTTP endpoint for Prometheus (no manual metric calls)
- `tools/providers/goliath_provider.py` — wired AVM provider with exponential-backoff retries + circuit breaker
- `agents/underwriting/underwriter.py` — typed `UnderwriteResult` dataclass with `reason_codes: list[str]`
- `app/settings.py` — richer settings (JWT fields, Goliath credentials, `EMBEDDING_MODEL`, `CACHE_TTL_SECONDS`)

**From V5 (agent implementations):**
- Full offer ladder agent (`agents/acquisitions/offer_agent.py`) — LAO/Anchor/Walk-Away math
- Buyer CSV matcher (`agents/dispositions/buyer_matcher.py`) — zip/price/type scoring
- Dispo blast generator + dealroom builder
- 4-touch followup scheduler
- `infrastructure/circuit_breaker.py` — proper 3-state machine (CLOSED → OPEN → HALF_OPEN)
- `infrastructure/health.py` — `/health/detail` checking DB, Redis, Notion, LLM, disk, circuit breakers
- K8s manifests, HPA, Grafana dashboard, Prometheus scrape config
- `agents/llm.py` — quota guard, disk cache, RPD limiter, per-run cap, cooldown

## Quick start

```bash
cp .env.example .env
# Fill in NOTION_TOKEN, DATABASE_URL, etc.

# Docker Compose (Postgres + Redis + worker + API):
docker-compose up

# Or local dev (SQLite):
DATABASE_URL=sqlite:///./dev.db uvicorn app.main:app --reload
```

## Auth

```bash
# Get a JWT (API key required):
curl -H "X-API-Key: YOUR_KEY" -X POST "http://localhost:8000/auth/token"

# Run the pipeline (any caller):
curl -X POST "http://localhost:8000/run/daily?limit=50"

# Synchronous meta-orchestrated run (JWT with runs:write scope):
curl -H "Authorization: Bearer YOUR_JWT" -X POST "http://localhost:8000/run/premier"
```

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Liveness probe |
| GET | `/health/detail` | Full dep checks (DB, Redis, Notion, CBs) |
| GET | `/metrics` | Prometheus (auto-instrumented) |
| POST | `/auth/token` | Mint scoped JWT |
| POST | `/run/daily` | Async pipeline run |
| POST | `/run/premier` | Sync planner+critic run |
| GET | `/runs` | List recent runs |
| POST | `/outcomes` | Record deal outcome |
| GET | `/leads/summary` | Dashboard stats |
| POST | `/reload-keys` | Hot-reload API keys |

## Key env vars

| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_URL` | `sqlite:///./dev.db` | PostgreSQL in prod |
| `JWT_SECRET` | `CHANGE_ME` | HS256 signing key |
| `EMBEDDING_MODEL` | `` | Set for real embeddings (e.g. `text-embedding-3-small`) |
| `GOLIATH_BASE_URL` | `` | AVM provider (optional) |
| `GOLIATH_API_KEY` | `` | AVM provider key |
| `METRICS_ENABLED` | `true` | Auto-instruments all HTTP endpoints |
| `LLM_MAX_CALLS_PER_RUN` | `8` | Cost guard |

## Lineage queries

Every computed field (ARV, rehab, MAO) writes a row to `lineage`:

```sql
SELECT field, value, selected_by, value_checksum, created_at
FROM lineage
WHERE lead_id = 'lead_abc123'
ORDER BY created_at;
```

## Running tests

```bash
pytest tests/ -v --tb=short
```

~40 tests covering domain math, scoring, decisions, ARV logic, offer ladders, buyer matching, circuit breakers, vector memory, critic agent, lineage, weighted consensus, DB memory, and hash embeddings.
