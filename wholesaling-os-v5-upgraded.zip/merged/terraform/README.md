# Terraform starter (AWS)

This is a minimal, optional cloud starter to run the docker-compose stack on a single EC2 instance.

## What it does
- Creates a security group exposing: 22 (SSH), 8000 (API), 6379 (Redis optional), 5432 (Postgres optional)
- Launches an Ubuntu EC2 instance with Docker + Docker Compose installed
- You SSH in, pull your repo, and run `docker compose up -d`

## Before use
- Install terraform
- Configure AWS credentials
- Set variables in `terraform.tfvars` (see example)

## Notes
- For production, prefer managed Postgres and a proper secrets manager.
- This is intentionally minimal and designed to be easy to modify.
