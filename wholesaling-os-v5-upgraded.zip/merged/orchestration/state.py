from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Any, Dict, List

class RunContext(BaseModel):
    run_id: str
    goal: str
    meta: Dict[str, Any] = Field(default_factory=dict)

class SharedState(BaseModel):
    context: RunContext
    lead_ids: List[str] = Field(default_factory=list)
    errors: List[str] = Field(default_factory=list)
