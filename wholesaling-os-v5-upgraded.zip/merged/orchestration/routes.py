# TODO: implement finite state routing based on DealScorer decision outputs.
