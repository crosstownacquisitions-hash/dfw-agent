from __future__ import annotations
"""
OSController — Planner-driven orchestration.

PlannerAgent decomposes the goal into subtasks.
Each subtask is enqueued.
After pipeline finishes, CriticAgent reflects and writes to memory.
"""

import uuid
import logging
from app.logger import get_logger
from orchestration.state import SharedState, RunContext
from infrastructure.queue import enqueue_task
from agents.meta.planner import PlannerAgent
from tools.metrics.prometheus import set_queue_depth

log = get_logger(__name__)


class OSController:
    def run_daily(self, goal: str, limit: int = 100, pursue_threshold: float = 70.0) -> SharedState:
        run_id = f"run_{uuid.uuid4().hex[:10]}"
        ctx = RunContext(run_id=run_id, goal=goal, meta={"limit": limit, "pursue_threshold": pursue_threshold})
        state = SharedState(context=ctx)

        # 1. Planner decomposes goal into subtasks
        plan = PlannerAgent().plan(run_id=run_id, goal=goal, context={"limit": limit})
        log.info("Plan created (%s, confidence=%.2f, %d subtasks)",
                 plan.source, plan.confidence, len(plan.subtasks))

        # 2. Enqueue core pipeline
        enqueue_task("workflows.daily_run:run", {
            "run_id": run_id, "goal": goal, "limit": limit,
            "pursue_threshold": pursue_threshold,
        })

        # 3. Enqueue QA + optimizer + critic
        enqueue_task("agents.quality.qa_auditor:audit_run", {"run_id": run_id})
        enqueue_task("agents.quality.optimizer:optimize", {"run_id": run_id})
        enqueue_task("agents.meta.critic:reflect_on_run", {"run_id": run_id})

        # 4. Update metrics
        set_queue_depth("default", 4)

        log.info("Enqueued daily run", extra={"run_id": run_id, "plan_source": plan.source})
        return state
