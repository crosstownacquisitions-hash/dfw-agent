from __future__ import annotations

import importlib


def test_identity_registry_idempotent(monkeypatch, tmp_path):
    import pytest
    pytest.importorskip("sqlalchemy")
    # Ensure the DB is isolated per test
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_path}/id.db")

    # Reload storage layer after env change
    import tools.data.storage as storage

    importlib.reload(storage)
    import tools.data.repo as repo

    importlib.reload(repo)

    from domain.identity import IdentityRegistry, build_fingerprint

    reg = IdentityRegistry()
    fp = build_fingerprint(address="123 N Main St., Apt #2", parcel_apn="123-45", source_system="zillow", source_record_id="Z-1")
    a = reg.get_or_create(fingerprint=fp, preferred_lead_id=None)
    b = reg.get_or_create(fingerprint=fp, preferred_lead_id="lead_custom")

    assert a.canonical_lead_id == b.canonical_lead_id
