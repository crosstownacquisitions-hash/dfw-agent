from __future__ import annotations

import json
import os


def test_goliath_contract_avm(monkeypatch, tmp_path):
    """Contract test: adapter output schema must remain stable.

    Uses a recorded cassette (no network calls).
    """

    here = os.path.dirname(__file__)
    cassette = json.load(open(os.path.join(here, "cassette_avm_1.json"), "r", encoding="utf-8"))

    monkeypatch.setenv("GOLIATH_BASE_URL", "https://example.invalid")
    monkeypatch.setenv("GOLIATH_API_KEY", "test")

    class FakeResp:
        def __init__(self, status_code: int, payload: dict):
            self.status_code = status_code
            self._payload = payload

        def raise_for_status(self):
            if self.status_code >= 400:
                raise RuntimeError(f"HTTP {self.status_code}")

        def json(self):
            return self._payload

    class FakeClient:
        def __init__(self, *a, **k):
            pass

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def post(self, url, json=None, headers=None):
            assert url.endswith(cassette["request"]["path"])  # correct endpoint
            assert json == cassette["request"]["payload"]
            return FakeResp(cassette["response"]["status_code"], cassette["response"]["json"])

    monkeypatch.setattr("tools.providers.goliath_provider.httpx.Client", FakeClient)

    from tools.providers.goliath_provider import get_avm

    out = get_avm(**cassette["request"]["payload"])
    assert set(out.keys()) == {"arv", "confidence", "meta"}
    assert out["arv"] == cassette["response"]["json"]["arv"]
    assert out["confidence"] == cassette["response"]["json"]["confidence"]
    assert out["meta"].get("provider") == "goliath"
