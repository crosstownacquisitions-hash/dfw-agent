"""
DFW Wholesale OS — Pytest Test Suite

Run: pytest tests/ -v --tb=short
"""

from __future__ import annotations

import json
import math
import os
import sys
import tempfile
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

# Ensure project root on path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_lead():
    return {
        "lead_id": "lead_test_001",
        "address": "123 Elm Street",
        "city": "Dallas",
        "state": "TX",
        "zip": "75201",
        "county": "dallas",
        "property_type": "SFH",
        "beds": 3,
        "baths": 2.0,
        "sqft": 1400,
        "year_built": 1975,
        "asking_price": 150000.0,
        "condition": "fair",
        "source": "test",
        "status": "New",
    }


@pytest.fixture
def hot_lead(sample_lead):
    return {**sample_lead, "asking_price": 100000.0, "condition": "poor"}


@pytest.fixture
def cold_lead(sample_lead):
    return {**sample_lead, "asking_price": 280000.0, "condition": "excellent"}


# ---------------------------------------------------------------------------
# Domain: Math
# ---------------------------------------------------------------------------

class TestDomainMath:

    def test_mao_wholesale_basic(self):
        from domain.math import calc_mao_wholesale
        mao = calc_mao_wholesale(arv=200_000, rehab=40_000, assignment_fee=15_000)
        expected = 200_000 * 0.70 - 40_000 - 15_000  # = 85000
        assert math.isclose(mao, expected, rel_tol=1e-6)

    def test_mao_wholesale_floor_zero(self):
        from domain.math import calc_mao_wholesale
        mao = calc_mao_wholesale(arv=50_000, rehab=60_000)
        assert mao == 0.0

    def test_mao_flip_basic(self):
        from domain.math import calc_mao_flip
        mao = calc_mao_flip(arv=200_000, rehab=40_000, profit_target=30_000)
        # 200k - 16k(sell) - 40k(rehab) - 15k(hold) - 30k(profit) = 99k
        assert mao > 0
        assert mao < 200_000

    def test_mao_flip_cap(self):
        from domain.math import calc_mao_flip
        mao = calc_mao_flip(arv=200_000, rehab=5_000, max_pct_cap=0.80)
        assert mao <= 200_000 * 0.80

    def test_rehab_estimate_by_condition(self):
        from domain.math import rehab_estimate_from_tags
        light = rehab_estimate_from_tags(sqft=1400, condition="light")
        heavy = rehab_estimate_from_tags(sqft=1400, condition="heavy")
        assert heavy > light

    def test_rehab_estimate_no_sqft(self):
        from domain.math import rehab_estimate_from_tags
        val = rehab_estimate_from_tags(sqft=None, condition="medium")
        assert val > 0


# ---------------------------------------------------------------------------
# Domain: Scoring
# ---------------------------------------------------------------------------

class TestDomainScoring:

    def test_hot_lead_high_score(self):
        from domain.scoring import score_deal
        score = score_deal(
            discount_pct=0.50,
            distress_score=0.90,
            liquidity_score=0.80,
            comps_confidence=0.85,
            friction_score=0.20,
        )
        assert score > 70.0, f"Expected >70, got {score}"

    def test_cold_lead_low_score(self):
        from domain.scoring import score_deal
        score = score_deal(
            discount_pct=0.02,
            distress_score=0.10,
            liquidity_score=0.30,
            comps_confidence=0.40,
            friction_score=0.80,
        )
        assert score < 30.0, f"Expected <30, got {score}"

    def test_score_clamp_0_100(self):
        from domain.scoring import score_deal
        # Perfect deal
        score_max = score_deal(discount_pct=1.0, distress_score=1.0,
                               liquidity_score=1.0, comps_confidence=1.0, friction_score=0.0)
        assert 0.0 <= score_max <= 100.0
        # Zero deal
        score_min = score_deal(discount_pct=0.0, distress_score=0.0,
                               liquidity_score=0.0, comps_confidence=0.0, friction_score=1.0)
        assert 0.0 <= score_min <= 100.0

    def test_score_weights_sum_to_1(self):
        from domain.scoring import DEFAULT_WEIGHTS
        total = (DEFAULT_WEIGHTS.discount + DEFAULT_WEIGHTS.distress +
                 DEFAULT_WEIGHTS.liquidity + DEFAULT_WEIGHTS.comps_confidence +
                 DEFAULT_WEIGHTS.execution_friction)
        assert math.isclose(total, 1.0, rel_tol=0.01), f"Weights sum to {total}"


# ---------------------------------------------------------------------------
# Domain: Decisions
# ---------------------------------------------------------------------------

class TestDecisions:

    def test_pursue_offer(self):
        from domain.decisions import decision_from_score
        assert decision_from_score(90) == "PURSUE_OFFER"

    def test_pursue_if_negotiable(self):
        from domain.decisions import decision_from_score
        assert decision_from_score(75) == "PURSUE_IF_NEGOTIABLE"

    def test_nurture(self):
        from domain.decisions import decision_from_score
        assert decision_from_score(55) == "NURTURE"

    def test_discard(self):
        from domain.decisions import decision_from_score
        assert decision_from_score(30) == "DISCARD"

    def test_none_score(self):
        from domain.decisions import decision_from_score
        assert decision_from_score(None) == "NEEDS_REVIEW"

    def test_boundary_70(self):
        from domain.decisions import decision_from_score
        assert decision_from_score(70) == "PURSUE_IF_NEGOTIABLE"

    def test_boundary_85(self):
        from domain.decisions import decision_from_score
        assert decision_from_score(85) == "PURSUE_OFFER"


# ---------------------------------------------------------------------------
# Domain: ARV from comps
# ---------------------------------------------------------------------------

class TestArvFromComps:

    def test_median_ppsf(self):
        from domain.arv_from_comps import ComparableSale, arv_from_comps
        comps = [
            ComparableSale("101 A", 200_000, 1000),
            ComparableSale("102 B", 210_000, 1000),
            ComparableSale("103 C", 190_000, 1000),
        ]
        arv = arv_from_comps(1000.0, comps)
        # median ppsf = 200, subject 1000 sqft => 200k
        assert arv == 200_000.0

    def test_insufficient_comps_returns_none(self):
        from domain.arv_from_comps import ComparableSale, arv_from_comps
        comps = [ComparableSale("101 A", 200_000, 1000)]
        assert arv_from_comps(1000.0, comps) is None

    def test_no_sqft_returns_none(self):
        from domain.arv_from_comps import arv_from_comps
        assert arv_from_comps(None, []) is None


# ---------------------------------------------------------------------------
# Agents: Offer ladder
# ---------------------------------------------------------------------------

class TestOfferAgent:

    def test_ladder_ordering(self):
        from agents.acquisitions.offer_agent import build_ladder
        ladder = build_ladder(mao70=100_000)
        assert ladder.lao < ladder.anchor < ladder.rungs[0]
        assert ladder.anchor < ladder.walk_away

    def test_ladder_walk_away_cap(self):
        from agents.acquisitions.offer_agent import build_ladder
        ladder = build_ladder(mao70=100_000, mao80=95_000)
        assert ladder.walk_away <= 100_000

    def test_ladder_rounding(self):
        from agents.acquisitions.offer_agent import build_ladder, _round_k
        ladder = build_ladder(mao70=97_300)
        assert ladder.anchor % 1000 == 0 or math.isclose(ladder.anchor % 1000, 0)


# ---------------------------------------------------------------------------
# Agents: Buyer matcher
# ---------------------------------------------------------------------------

class TestBuyerMatcher:

    def test_type_mismatch_excluded(self):
        from agents.dispositions.buyer_matcher import _score_match
        lead = {"property_type": "SFH", "mao_wholesale": 100_000, "zip": "75201"}
        buyer = {"PropertyTypes": "Commercial", "MaxPrice": "200000", "TargetZips": "75201"}
        score, reason = _score_match(lead, buyer)
        assert score == 0.0
        assert "type_mismatch" in reason

    def test_price_match(self):
        from agents.dispositions.buyer_matcher import _score_match
        lead = {"property_type": "SFH", "mao_wholesale": 90_000, "zip": "75201"}
        buyer = {"PropertyTypes": "SFH", "MaxPrice": "150000", "TargetZips": "75201"}
        score, reason = _score_match(lead, buyer)
        assert score > 0.35

    def test_zip_match_bonus(self):
        from agents.dispositions.buyer_matcher import _score_match
        lead_same_zip = {"property_type": "SFH", "mao_wholesale": 80_000, "zip": "75201"}
        lead_diff_zip = {"property_type": "SFH", "mao_wholesale": 80_000, "zip": "77001"}
        buyer = {"PropertyTypes": "SFH", "MaxPrice": "150000", "TargetZips": "75201"}
        s_same, _ = _score_match(lead_same_zip, buyer)
        s_diff, _ = _score_match(lead_diff_zip, buyer)
        assert s_same > s_diff


# ---------------------------------------------------------------------------
# Agents: Vector memory
# ---------------------------------------------------------------------------

class TestVectorStore:

    def test_add_and_retrieve(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path))
        from agents.memory import vector_store as vs_mod
        import importlib
        # Patch storage dir
        vs_mod._STORE_DIR = str(tmp_path)
        store = vs_mod.VectorStore(namespace="test")

        store.add("lead_001", {"address": "123 Main", "decision": "PURSUE_OFFER"})
        result = store.get("lead_001")
        assert result is not None
        assert result["payload"]["decision"] == "PURSUE_OFFER"

    def test_search_returns_relevant(self, tmp_path, monkeypatch):
        from agents.memory import vector_store as vs_mod
        vs_mod._STORE_DIR = str(tmp_path)
        store = vs_mod.VectorStore(namespace="test2")

        store.add("a", {"type": "deal"}, text="motivated seller Dallas foreclosure")
        store.add("b", {"type": "deal"}, text="expired listing beautiful updated home")
        store.add("c", {"type": "deal"}, text="Dallas motivated seller behind payments")

        results = store.search("motivated seller Dallas", top_k=3)
        keys = [r["key"] for r in results]
        assert "a" in keys or "c" in keys  # relevant docs found

    def test_outcome_update(self, tmp_path):
        from agents.memory import vector_store as vs_mod
        vs_mod._STORE_DIR = str(tmp_path)
        store = vs_mod.VectorStore(namespace="test3")
        store.add("lead_x", {"score": 88}, text="high equity motivated")
        store.update_outcome("lead_x", "closed", confidence=0.95)
        result = store.get("lead_x")
        assert result["outcome"] == "closed"


# ---------------------------------------------------------------------------
# Agents: CriticAgent
# ---------------------------------------------------------------------------

class TestCriticAgent:

    def test_healthy_run(self, tmp_path):
        from agents.memory import vector_store as vs_mod
        vs_mod._STORE_DIR = str(tmp_path)
        from agents.meta.critic import CriticAgent
        critic = CriticAgent()
        critic.memory = vs_mod.VectorStore("reflections_test")
        critic.plan_memory = vs_mod.VectorStore("plans_test")

        report = critic.evaluate("run_001", {
            "processed": 50, "pursued": 8, "nurtured": 20,
            "discarded": 15, "needs_review": 7,
        })
        assert report.overall_quality > 0.8
        assert "run_001" in report.run_id

    def test_high_discard_rate_flagged(self, tmp_path):
        from agents.memory import vector_store as vs_mod
        vs_mod._STORE_DIR = str(tmp_path)
        from agents.meta.critic import CriticAgent
        critic = CriticAgent()
        critic.memory = vs_mod.VectorStore("reflections_test2")
        critic.plan_memory = vs_mod.VectorStore("plans_test2")

        report = critic.evaluate("run_002", {
            "processed": 100, "pursued": 1, "nurtured": 5,
            "discarded": 90, "needs_review": 4,
        })
        flag_codes = {f.code for f in report.flags}
        assert "HIGH_DISCARD_RATE" in flag_codes

    def test_no_leads_flagged(self, tmp_path):
        from agents.memory import vector_store as vs_mod
        vs_mod._STORE_DIR = str(tmp_path)
        from agents.meta.critic import CriticAgent
        critic = CriticAgent()
        critic.memory = vs_mod.VectorStore("reflections_test3")
        critic.plan_memory = vs_mod.VectorStore("plans_test3")

        report = critic.evaluate("run_003", {"processed": 0, "pursued": 0,
                                              "nurtured": 0, "discarded": 0, "needs_review": 0})
        flag_codes = {f.code for f in report.flags}
        assert "NO_LEADS_PROCESSED" in flag_codes


# ---------------------------------------------------------------------------
# Infrastructure: Circuit breaker
# ---------------------------------------------------------------------------

class TestCircuitBreaker:

    def test_closed_passes_calls(self):
        from infrastructure.circuit_breaker import CircuitBreaker
        cb = CircuitBreaker("test_svc", failure_threshold=3)
        results = []
        for _ in range(3):
            with cb():
                results.append("ok")
        assert results == ["ok", "ok", "ok"]

    def test_opens_after_threshold(self):
        from infrastructure.circuit_breaker import CircuitBreaker, CircuitBreakerError
        cb = CircuitBreaker("test_svc2", failure_threshold=3, reset_timeout_s=999)
        for _ in range(3):
            try:
                with cb():
                    raise ValueError("simulated failure")
            except ValueError:
                pass
        with pytest.raises(CircuitBreakerError):
            with cb():
                pass

    def test_default_value_on_open(self):
        from infrastructure.circuit_breaker import CircuitBreaker
        cb = CircuitBreaker("test_svc3", failure_threshold=2, reset_timeout_s=999)
        for _ in range(2):
            try:
                with cb():
                    raise RuntimeError("fail")
            except RuntimeError:
                pass
        result = cb.call(lambda: "should_not_reach", default="fallback")
        assert result == "fallback"


# ---------------------------------------------------------------------------
# Tools: Data lineage
# ---------------------------------------------------------------------------

class TestLineage:

    def test_consensus_arv_blend(self, tmp_path):
        from tools.providers.lineage import LineageGraph, consensus_arv
        graph = LineageGraph()
        graph._LINEAGE_DIR = str(tmp_path)
        arv, conf, method = consensus_arv(
            "lead_lin_001", graph,
            comps_arv=200_000, comps_confidence=0.85,
            model_arv=210_000, model_confidence=0.55,
        )
        assert arv is not None
        assert "blend" in method.lower() or "consensus" in method.lower() or "source" in method.lower()
        assert conf > 0.5

    def test_consensus_arv_no_sources(self, tmp_path):
        from tools.providers.lineage import LineageGraph, consensus_arv
        graph = LineageGraph()
        arv, conf, method = consensus_arv("lead_no_src", graph)
        assert arv is None
        assert method == "no_sources"

    def test_checksum_integrity(self, tmp_path):
        from tools.providers.lineage import LineageGraph, LineageSource
        graph = LineageGraph()
        graph._LINEAGE_DIR = str(tmp_path)
        graph.record("lead_chk", "arv",
                     [LineageSource("comps_api", 200_000, 0.85)],
                     selected_value=200_000, method="single_source")
        assert graph.verify_checksum("lead_chk", "arv", 200_000, "single_source")
        assert not graph.verify_checksum("lead_chk", "arv", 999_999, "single_source")


# ---------------------------------------------------------------------------
# Tools: Redis cache
# ---------------------------------------------------------------------------

class TestRedisCache:

    def test_local_lru_fallback(self):
        """When Redis is unavailable, local LRU should work."""
        from tools.cache.redis_cache import cached, _local_cache
        call_count = 0

        @cached(ttl=60, key_prefix="test_cache")
        def expensive_fn(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x * 2

        result1 = expensive_fn(5)
        result2 = expensive_fn(5)
        assert result1 == 10
        assert result2 == 10
        # Second call should hit cache
        assert call_count <= 2  # May vary based on Redis availability

    def test_different_args_different_cache(self):
        from tools.cache.redis_cache import cached
        @cached(ttl=60, key_prefix="test_cache2")
        def fn(x: int) -> int:
            return x * 3
        assert fn(1) == 3
        assert fn(2) == 6


# ---------------------------------------------------------------------------
# Integration: Pipeline smoke test (no external calls)
# ---------------------------------------------------------------------------

class TestPipelineSmoke:

    def test_config_imports(self):
        import config
        assert hasattr(config, "BUY_BOX")
        assert hasattr(config, "MAO_CONFIG")
        assert hasattr(config, "THRESHOLDS")
        assert hasattr(config, "OFFER_STRATEGY")

    def test_domain_imports(self):
        from domain.math import calc_mao_wholesale, calc_mao_flip
        from domain.scoring import score_deal
        from domain.decisions import decision_from_score
        from domain.arv_from_comps import arv_from_comps

    def test_agent_imports(self):
        from agents.acquisitions.offer_agent import generate_offers, build_ladder
        from agents.dispositions.buyer_matcher import match_buyers
        from agents.enrich.rehab_estimator import estimate_rehab
        from agents.meta.planner import PlannerAgent
        from agents.meta.critic import CriticAgent

    def test_full_underwrite_math(self):
        """End-to-end underwriting math for a canonical deal."""
        from domain.math import calc_mao_wholesale, calc_mao_flip, rehab_estimate_from_tags
        from domain.scoring import score_deal
        from domain.decisions import decision_from_score

        arv   = 220_000
        sqft  = 1_600
        rehab = rehab_estimate_from_tags(sqft=sqft, condition="fair")  # ~72k
        mao_w = calc_mao_wholesale(arv=arv, rehab=rehab)
        mao_f = calc_mao_flip(arv=arv, rehab=rehab)

        assert mao_w > 0
        assert mao_f > 0
        assert mao_w < arv
        assert mao_f < arv

        # Score at 65% of ARV asking price
        asking = arv * 0.65
        discount = max((arv - asking) / arv, 0.0)
        score = score_deal(
            discount_pct=discount,
            distress_score=0.7,
            liquidity_score=0.65,
            comps_confidence=0.70,
            friction_score=0.3,
        )
        decision = decision_from_score(score)
        assert decision in ("PURSUE_OFFER", "PURSUE_IF_NEGOTIABLE", "NURTURE", "DISCARD")


# ---------------------------------------------------------------------------
# Premier additions: Consensus, Lineage checksum, DB memory
# ---------------------------------------------------------------------------

class TestWeightedConsensus:
    """Premier's weighted median ARV consensus."""

    def test_prefers_median_over_mean(self):
        """Weighted median ignores outliers — [100, 200, 300] → 200, not 200."""
        from domain.consensus import SourceValue, weighted_consensus
        v, sources, by = weighted_consensus([
            SourceValue(source="a", value=100, confidence=0.9, weight=1.0),
            SourceValue(source="b", value=200, confidence=0.9, weight=1.0),
            SourceValue(source="c", value=300, confidence=0.9, weight=1.0),
        ])
        assert v == 200.0
        assert by == "weighted_median"
        assert len(sources) == 3

    def test_outlier_does_not_drag_result(self):
        """Wild AVM outlier should not pull the consensus value."""
        from domain.consensus import SourceValue, weighted_consensus
        v, _, by = weighted_consensus([
            SourceValue(source="comps", value=200_000, confidence=0.9, weight=1.5),
            SourceValue(source="model", value=195_000, confidence=0.7, weight=1.0),
            SourceValue(source="bad_avm", value=999_999, confidence=0.1, weight=0.3),
        ])
        assert v is not None
        assert v < 300_000, "Outlier should not dominate the consensus"
        assert by == "weighted_median"

    def test_single_source(self):
        from domain.consensus import SourceValue, weighted_consensus
        v, sources, by = weighted_consensus([
            SourceValue(source="comps", value=185_000, confidence=0.85, weight=1.0),
        ])
        assert v == 185_000.0
        assert len(sources) == 1

    def test_all_none_returns_none(self):
        from domain.consensus import SourceValue, weighted_consensus
        v, sources, by = weighted_consensus([
            SourceValue(source="a", value=None),
            SourceValue(source="b", value=None),
        ])
        assert v is None
        assert by == "none"

    def test_empty_list_returns_none(self):
        from domain.consensus import weighted_consensus
        v, sources, by = weighted_consensus([])
        assert v is None


class TestLineageChecksum:
    """Premier's deterministic value checksum."""

    def test_checksum_stable_across_key_order(self):
        from domain.consensus import checksum
        assert checksum({"a": 1, "b": 2}) == checksum({"b": 2, "a": 1})

    def test_checksum_differs_for_different_values(self):
        from domain.consensus import checksum
        assert checksum({"arv": 200_000}) != checksum({"arv": 199_999})

    def test_checksum_works_for_scalars(self):
        from domain.consensus import checksum
        c1 = checksum(200_000)
        c2 = checksum(200_000)
        assert c1 == c2

    def test_db_lineage_record(self):
        """DB lineage writer creates a row for each field recorded."""
        import os
        os.environ.setdefault("DATABASE_URL", "sqlite:///./test_lineage.db")
        from tools.data.repo import init_db
        init_db()
        from tools.data.lineage import record_lineage
        record_lineage(
            lead_id="lead_chk_001",
            run_id="run_chk_001",
            entity="underwrite",
            field="arv",
            value=200_000,
            sources=[{"source": "comps_api", "value": 200_000, "confidence": 0.85}],
            selected_by="weighted_median",
        )
        # Verify row exists
        from tools.data.repo import SessionLocal
        from tools.data.models import Lineage
        with SessionLocal() as s:
            row = s.query(Lineage).filter_by(lead_id="lead_chk_001", field="arv").first()
        assert row is not None
        assert row.selected_by == "weighted_median"
        assert row.value_checksum != ""


class TestDBMemory:
    """Premier's DB-backed VectorMemoryStore."""

    def test_add_and_search(self):
        import os
        os.environ.setdefault("DATABASE_URL", "sqlite:///./test_memory.db")
        from tools.data.repo import init_db
        init_db()
        from agents.memory.vector_store import VectorMemoryStore, MemoryWrite
        ms = VectorMemoryStore()
        ms.add(MemoryWrite(namespace="test_runs", key="k1", text="DFW deal analysis rehab estimate"))
        ms.add(MemoryWrite(namespace="test_runs", key="k2", text="buyer list dispo outreach Dallas"))
        hits = ms.search("test_runs", "rehab", k=2)
        assert len(hits) >= 1
        assert hits[0].score > 0

    def test_hash_embedding_is_deterministic(self):
        from agents.memory.embeddings import _hash_embed
        v1 = _hash_embed("hello world")
        v2 = _hash_embed("hello world")
        assert v1 == v2

    def test_hash_embedding_is_normalized(self):
        import math
        from agents.memory.embeddings import _hash_embed
        v = _hash_embed("test string for normalization")
        norm = math.sqrt(sum(x * x for x in v))
        assert abs(norm - 1.0) < 1e-4 or norm == 0.0  # L2-normalized or zero vector
