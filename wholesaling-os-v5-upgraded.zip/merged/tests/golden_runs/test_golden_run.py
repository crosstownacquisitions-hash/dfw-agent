from __future__ import annotations

import json
import os
from unittest.mock import MagicMock, patch

import pytest


def _load_json(rel: str):
    here = os.path.dirname(__file__)
    return json.load(open(os.path.join(here, rel), "r", encoding="utf-8"))


@pytest.mark.parametrize("pursue_threshold", [70.0])
def test_golden_run_pipeline_regression(pursue_threshold: float, tmp_path, monkeypatch):
    pytest.importorskip("sqlalchemy")
    """Golden run: run the pipeline on fixed fixtures and assert outputs stay in bounds.

    We mock external systems (Notion + LLM) so this is deterministic and CI-safe.
    """

    # Isolate DB + outputs
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_path}/test.db")
    monkeypatch.chdir(tmp_path)

    fixtures = _load_json("fixtures.json")
    expected = _load_json("expected_outputs.json")

    # Deterministic LLM: ARV = asking_price * 1.6 with Med confidence
    def fake_llm_complete(messages, model=None, **kwargs):
        txt = messages[0]["content"]
        # crude parse: find asking price line
        asking = 150000
        for line in txt.splitlines():
            if "Asking price" in line:
                try:
                    asking = int(float(line.split(":", 1)[1].strip() or 150000))
                except Exception:
                    asking = 150000
        arv = float(asking) * 1.6
        content = json.dumps({"arv": arv, "confidence": "Med"})
        return {
            "choices": [{"message": {"content": content}}],
            "usage": {"prompt_tokens": 50, "completion_tokens": 20, "total_tokens": 70},
            "model": model or "fake",
        }

    # Import module so patch() can resolve submodule attributes
    import agents.pipeline  # noqa: F401

    # Mock Notion readers/writers
    with patch("agents.pipeline.NotionReaders", create=True) as NR, patch("agents.pipeline.NotionWriters", create=True) as NW, patch(
        "agents.pipeline.llm_complete", side_effect=fake_llm_complete, create=True
    ):
        NR.return_value.fetch_new_leads.return_value = fixtures
        # Writers are no-ops
        nw = NW.return_value
        nw.client.update_page = MagicMock()
        nw.create_underwrite = MagicMock()
        nw.create_task = MagicMock()
        nw.create_dealroom = MagicMock()

        from agents.pipeline import process_new_leads

        summary = process_new_leads(run_id="run_golden", limit=50, pursue_threshold=pursue_threshold)
        assert summary["processed"] == len(fixtures)

    # Read artifact output
    out_csv = tmp_path / "out" / "runs" / "run_golden" / "ranked_leads.csv"
    assert out_csv.exists()

    import csv

    rows = list(csv.DictReader(open(out_csv, "r", encoding="utf-8")))
    assert len(rows) == len(fixtures)

    for r in rows:
        lid = r["lead_id"]
        exp = expected[lid]
        arv = float(r["arv"]) if r["arv"] else None
        rehab = float(r["rehab"]) if r["rehab"] else None
        mao_w = float(r["mao_wholesale"]) if r["mao_wholesale"] else None
        assert arv is None or (exp["arv"][0] <= arv <= exp["arv"][1])
        assert rehab is None or (exp["rehab"][0] <= rehab <= exp["rehab"][1])
        assert mao_w is None or (exp["mao_wholesale"][0] <= mao_w <= exp["mao_wholesale"][1])
        assert r["decision"] in exp["decision_in"]
