from __future__ import annotations

import os
import time
from dataclasses import dataclass

from tools.data.repo import ConfigRepo


def _today_utc() -> str:
    return time.strftime("%Y-%m-%d", time.gmtime())


@dataclass
class StageBudgets:
    """Simple daily budgets, stored in ConfigKV.

    Defaults are intentionally permissive (no behavior change).

    Env overrides:
      - ENRICHMENT_DAILY_BUDGET_CALLS (default 999999)
      - LLM_DAILY_BUDGET_CALLS (default 999999)
    """

    enrichment_daily_calls: int = int(os.getenv("ENRICHMENT_DAILY_BUDGET_CALLS", "999999"))
    llm_daily_calls: int = int(os.getenv("LLM_DAILY_BUDGET_CALLS", "999999"))

    def __post_init__(self) -> None:
        self._repo = ConfigRepo()

    def _key(self, stage: str) -> str:
        return f"budget:{stage}:{_today_utc()}"

    def get_count(self, stage: str) -> int:
        d = self._repo.get(self._key(stage), default={})
        return int(d.get("count", 0))

    def increment(self, stage: str, n: int = 1) -> int:
        key = self._key(stage)
        d = self._repo.get(key, default={})
        c = int(d.get("count", 0)) + int(n)
        self._repo.set(key, {"count": c})
        return c

    def allow(self, stage: str) -> bool:
        c = self.get_count(stage)
        if stage == "enrichment":
            return c < self.enrichment_daily_calls
        if stage == "llm":
            return c < self.llm_daily_calls
        return True
