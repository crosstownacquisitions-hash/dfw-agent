from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.logger import get_logger
from tools.data.repo import OutcomeRepo

log = get_logger(__name__)


@dataclass
class CostEvent:
    stage: str
    vendor: str
    amount_usd: float
    units: int = 1
    meta: dict[str, Any] | None = None


class CostLedger:
    """Write cost and usage events into the outcomes table.

    We purposely re-use OutcomeRepo to avoid DB schema changes.
    Each cost event is stored as Outcome(event="cost") with:
      - value: amount_usd
      - meta: {stage, vendor, units, ...}
    """

    def __init__(self) -> None:
        self._repo = OutcomeRepo()

    def record_cost(
        self,
        *,
        run_id: str,
        lead_id: str,
        stage: str,
        vendor: str,
        amount_usd: float,
        units: int = 1,
        meta: dict[str, Any] | None = None,
    ) -> None:
        payload = {"stage": stage, "vendor": vendor, "units": units}
        if meta:
            payload.update(meta)
        self._repo.add(lead_id=lead_id, run_id=run_id, event="cost", value=float(amount_usd), meta=payload)

    def record_usage(
        self,
        *,
        run_id: str,
        lead_id: str,
        stage: str,
        vendor: str,
        units: int,
        meta: dict[str, Any] | None = None,
    ) -> None:
        payload = {"stage": stage, "vendor": vendor, "units": int(units)}
        if meta:
            payload.update(meta)
        self._repo.add(lead_id=lead_id, run_id=run_id, event="usage", value=float(units), meta=payload)
