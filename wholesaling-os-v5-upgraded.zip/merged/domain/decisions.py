from __future__ import annotations

"""Decision policy.

Keep this deterministic and auditable.
"""

from dataclasses import dataclass, field
from typing import List


# ---------------------------------------------------------------------------
# Decision result (used by deal_scorer and underwriter)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class DecisionResult:
    score: float
    decision: str
    reason_codes: List[str]
    confidence: str  # "High" | "Med" | "Low"


# ---------------------------------------------------------------------------
# Thin wrapper used by tests and external callers
# ---------------------------------------------------------------------------

def decision_from_score(score: float | None) -> str:
    if score is None:
        return "NEEDS_REVIEW"
    if score >= 85:
        return "PURSUE_OFFER"
    if score >= 70:
        return "PURSUE_IF_NEGOTIABLE"
    if score >= 50:
        return "NURTURE"
    return "DISCARD"


# ---------------------------------------------------------------------------
# Full underwriting decision — called by deal_scorer.score_deal()
# ---------------------------------------------------------------------------

def decide(
    *,
    arv: float | None,
    rehab: float | None,
    asking: float | None,
    mao_wholesale: float | None,
    mao_flip: float | None,
) -> DecisionResult:
    """Deterministic scoring and decision from underwriting numbers.

    Returns a DecisionResult with a 0-100 score, decision label, machine-readable
    reason_codes (shown in Notion when a deal is rejected), and a confidence level.
    """
    reason_codes: list[str] = []

    # ── Guard: missing data ──────────────────────────────────────────────────
    if arv is None or arv <= 0:
        return DecisionResult(
            score=0.0,
            decision="NEEDS_REVIEW",
            reason_codes=["NO_ARV"],
            confidence="Low",
        )

    if rehab is None:
        reason_codes.append("NO_REHAB_ESTIMATE")
        rehab = 0.0

    # ── Core metrics ─────────────────────────────────────────────────────────
    score = 50.0  # neutral baseline

    # 1. Price-to-ARV discount (most important signal)
    if asking and asking > 0:
        discount_pct = max((arv - asking) / arv, 0.0)
        if discount_pct >= 0.40:
            score += 30.0
        elif discount_pct >= 0.30:
            score += 20.0
        elif discount_pct >= 0.20:
            score += 10.0
        elif discount_pct >= 0.10:
            score += 0.0
        else:
            score -= 15.0
            reason_codes.append("LOW_DISCOUNT")
    else:
        reason_codes.append("NO_ASKING_PRICE")

    # 2. MAO spread — does asking sit below our wholesale number?
    if mao_wholesale is not None and asking is not None and asking > 0:
        spread = mao_wholesale - asking
        if spread >= 10_000:
            score += 15.0
        elif spread >= 0:
            score += 5.0
        else:
            score -= 10.0
            reason_codes.append("ASKING_ABOVE_MAO_WHOLESALE")

    # 3. Rehab burden relative to ARV
    rehab_pct = rehab / arv if arv else 0.0
    if rehab_pct > 0.40:
        score -= 15.0
        reason_codes.append("HIGH_REHAB_BURDEN")
    elif rehab_pct > 0.25:
        score -= 5.0

    # 4. Flip viability check
    if mao_flip is not None and asking is not None and asking > 0:
        if asking > mao_flip * 1.1:
            reason_codes.append("ASKING_ABOVE_MAO_FLIP")

    score = max(min(score, 100.0), 0.0)

    # ── Decision thresholds ──────────────────────────────────────────────────
    decision = decision_from_score(score)

    # ── Confidence ───────────────────────────────────────────────────────────
    if "NO_ASKING_PRICE" in reason_codes or "NO_REHAB_ESTIMATE" in reason_codes:
        confidence = "Low"
    elif len(reason_codes) == 0 and score >= 70:
        confidence = "High"
    else:
        confidence = "Med"

    return DecisionResult(
        score=round(score, 1),
        decision=decision,
        reason_codes=reason_codes,
        confidence=confidence,
    )
