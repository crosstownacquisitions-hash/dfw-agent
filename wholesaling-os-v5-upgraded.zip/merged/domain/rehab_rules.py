from __future__ import annotations

from typing import Dict, Any, Optional


FLAG_COSTS = {
    "foundation": 20000,
    "roof": 12000,
    "hvac": 7000,
}


def rehab_with_flags(base_rehab: Optional[float], flags: Dict[str, Any]) -> Optional[float]:
    """Add deterministic rehab adjustments based on boolean flags."""
    if base_rehab is None:
        return None
    total = float(base_rehab)
    for k, add in FLAG_COSTS.items():
        v = flags.get(k)
        if v is True or (isinstance(v, str) and v.strip().lower() in ("true", "yes", "1")):
            total += add
    return total


def estimate_rehab_cost(sqft: int, year_built: int | None = None, property_type: str = "SFH") -> float:
    # Light heuristic: base $/sqft with vintage penalty
    if sqft <= 0:
        return 0.0
    base = 22.0  # $/sqft
    if year_built and year_built < 1970:
        base += 8.0
    if property_type.lower() in {"duplex", "triplex", "quad", "multifamily"}:
        base += 3.0
    return float(base * sqft)


def estimate_rehab_budget(
    sqft: int | None,
    year_built: int | None = None,
    condition_hint: str = "",
) -> tuple[float, str, dict]:
    """Return (total_rehab, tier_label, meta_dict) for lineage recording.

    tier: 'light' | 'medium' | 'heavy'
    """
    sqft_safe = sqft or 1_400
    base = estimate_rehab_cost(sqft_safe, year_built=year_built)

    c = (condition_hint or "").lower()
    if c in ("gut", "bad", "poor", "heavy", "full"):
        mult, tier = 1.6, "heavy"
    elif c in ("fair", "average", "avg", "medium"):
        mult, tier = 1.0, "medium"
    elif c in ("good", "excellent", "updated", "turnkey", "light", "cosmetic"):
        mult, tier = 0.5, "light"
    else:
        mult, tier = 1.1, "medium"

    total = round(base * mult, -2)
    meta = {"sqft": sqft_safe, "year_built": year_built, "condition_hint": condition_hint,
            "base_ppsf": base / sqft_safe if sqft_safe else 0, "tier": tier, "mult": mult}
    return total, tier, meta
