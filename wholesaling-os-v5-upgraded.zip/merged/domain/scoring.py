from __future__ import annotations
from dataclasses import dataclass
from tools.data.repo import ConfigRepo

@dataclass
class ScoringWeights:
    discount: float = 0.35
    distress: float = 0.20
    liquidity: float = 0.15
    comps_confidence: float = 0.15
    execution_friction: float = 0.15

DEFAULT_WEIGHTS = ScoringWeights()


def get_weights() -> ScoringWeights:
    """Load weights from DB config (set by Optimizer)."""
    raw = ConfigRepo().get("scoring_weights", default={})
    if not raw:
        return DEFAULT_WEIGHTS
    try:
        return ScoringWeights(**{k: float(v) for k, v in raw.items() if hasattr(DEFAULT_WEIGHTS, k)})
    except Exception:
        return DEFAULT_WEIGHTS

def score_deal(*, discount_pct: float, distress_score: float, liquidity_score: float,
               comps_confidence: float, friction_score: float, w: ScoringWeights | None = None) -> float:
    w = w or get_weights()
    s = (
        discount_pct * w.discount +
        distress_score * w.distress +
        liquidity_score * w.liquidity +
        comps_confidence * w.comps_confidence +
        (1.0 - friction_score) * w.execution_friction
    )
    return max(min(s * 100.0, 100.0), 0.0)
