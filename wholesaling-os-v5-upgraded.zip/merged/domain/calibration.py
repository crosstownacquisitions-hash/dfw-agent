"""Calibration constants for underwriting math.

These are defaults; tune over time based on realized outcomes.
"""

SELL_COST_PCT = 0.08  # configurable 0.07–0.09
HOLDING_COST_BASE = 15000
PROFIT_TARGET = 30000
ASSIGNMENT_FEE = 15000

DOM_HOLDING_BANDS = [
    (0, 30, 12000),
    (31, 60, 15000),
    (61, 90, 18000),
    (91, 3650, 22000),
]
