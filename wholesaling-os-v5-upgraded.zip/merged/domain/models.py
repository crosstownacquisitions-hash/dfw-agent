from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any

class Lead(BaseModel):
    lead_id: str
    address: str
    city: Optional[str] = None
    county: Optional[str] = None
    zip: Optional[str] = None
    property_type: Optional[str] = None
    beds: Optional[float] = None
    baths: Optional[float] = None
    sqft: Optional[int] = None
    year_built: Optional[int] = None
    source: Optional[str] = None
    status: str = "NEW"
    meta: Dict[str, Any] = Field(default_factory=dict)

class Underwrite(BaseModel):
    lead_id: str
    arv: Optional[float] = None
    rehab: Optional[float] = None
    mao_wholesale: Optional[float] = None
    mao_flip: Optional[float] = None
    score: Optional[float] = None
    decision: Optional[str] = None
    confidence: Optional[str] = None
    reason_codes: List[str] = Field(default_factory=list)
    version: int = 1
