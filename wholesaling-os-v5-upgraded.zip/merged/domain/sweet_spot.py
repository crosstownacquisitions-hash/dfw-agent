from __future__ import annotations

from typing import Optional


def wholesale_sweet_spot(ask: Optional[float], mao_wholesale: Optional[float]) -> str:
    """Classify seller ask relative to MAO wholesale."""
    if ask is None or mao_wholesale is None:
        return ""
    if ask <= mao_wholesale:
        return "In Sweet Spot"
    if ask <= mao_wholesale + 10000:
        return "Close"
    return "Out of Range"
