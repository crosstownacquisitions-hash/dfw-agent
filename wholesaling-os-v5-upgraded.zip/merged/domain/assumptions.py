from __future__ import annotations

import os
from functools import lru_cache
from typing import Any

import yaml

from app.logger import get_logger

log = get_logger(__name__)


DEFAULT_VERSION = os.getenv("UNDERWRITING_ASSUMPTIONS_VERSION", "v1").strip() or "v1"


@lru_cache(maxsize=8)
def load_assumptions(version: str | None = None) -> dict[str, Any]:
    """Load versioned underwriting assumptions from config/underwriting/<version>.yaml.

    Falls back to built-in defaults if file missing.
    """
    v = (version or DEFAULT_VERSION).strip()
    path = os.path.join(os.path.dirname(__file__), "..", "config", "underwriting", f"{v}.yaml")
    path = os.path.abspath(path)
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
            if not isinstance(data, dict):
                return {}
            return data
    except FileNotFoundError:
        log.warning("Assumptions file missing: %s", path)
        return {}
    except Exception as exc:
        log.warning("Assumptions load failed: %s", exc)
        return {}
