from __future__ import annotations

import argparse
import json
import os

from app.logger import get_logger

log = get_logger(__name__)


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="Replay a quarantined lead payload.")
    p.add_argument("--file", required=True, help="Path to quarantine JSON file")
    args = p.parse_args(argv)

    if not os.path.exists(args.file):
        raise SystemExit(f"Not found: {args.file}")

    rec = json.load(open(args.file, "r", encoding="utf-8"))
    # We don't automatically re-run the whole workflow here because the pipeline
    # entrypoints vary by deployment. Instead, print the payload for operator use.
    print(json.dumps(rec, indent=2))


if __name__ == "__main__":
    main()
