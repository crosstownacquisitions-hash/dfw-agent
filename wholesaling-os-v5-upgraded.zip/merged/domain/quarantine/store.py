from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from app.logger import get_logger

log = get_logger(__name__)


@dataclass
class QuarantineRecord:
    run_id: str
    lead_id: str
    stage: str
    error: str
    payload: dict[str, Any]
    created_at: str


class QuarantineStore:
    """File-based dead-letter quarantine.

    Writes JSON to out/quarantine/<run_id>/<lead_id>.json.
    This keeps the main pipeline from failing hard on a single bad record.
    """

    def __init__(self, base_dir: str = "out/quarantine") -> None:
        self.base_dir = base_dir

    def save(self, *, run_id: str, lead_id: str, stage: str, error: str, payload: dict[str, Any]) -> str:
        ts = datetime.now(timezone.utc).isoformat()
        rec = QuarantineRecord(run_id=run_id, lead_id=lead_id, stage=stage, error=error, payload=payload, created_at=ts)
        d = os.path.join(self.base_dir, run_id)
        os.makedirs(d, exist_ok=True)
        path = os.path.join(d, f"{lead_id}.json")
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(rec.__dict__, f, indent=2)
        except Exception as exc:
            log.warning("Quarantine write failed: %s", exc)
        return path
