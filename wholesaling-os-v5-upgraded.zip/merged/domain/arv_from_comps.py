from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional
import statistics


@dataclass
class ComparableSale:
    address: str
    sale_price: float
    sqft: float
    beds: Optional[float] = None
    baths: Optional[float] = None
    sold_date: str = ""
    distance_mi: Optional[float] = None
    source: str = ""


def arv_from_comps(subject_sqft: Optional[float], comps: List[ComparableSale]) -> Optional[float]:
    """Very simple comps-based ARV estimator (median PPSF * subject sqft)."""
    if not subject_sqft or subject_sqft <= 0:
        return None
    pps = []
    for c in comps:
        if c.sale_price and c.sqft and c.sqft > 0:
            pps.append(c.sale_price / c.sqft)
    if len(pps) < 3:
        return None
    pps_med = statistics.median(pps)
    return round(pps_med * float(subject_sqft), 0)
