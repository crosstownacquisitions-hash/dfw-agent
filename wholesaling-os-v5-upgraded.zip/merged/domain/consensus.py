from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import math


@dataclass(frozen=True)
class SourceValue:
    source: str
    value: float | None
    confidence: float | None = None
    weight: float = 1.0
    meta: dict[str, Any] | None = None


def weighted_consensus(values: list[SourceValue]) -> tuple[float | None, list[dict[str, Any]], str]:
    """Choose a value via robust weighted median with confidence weighting.

    Returns: (selected_value, sources_payload, selected_by)
    """
    vals = [v for v in values if v.value is not None]
    if not vals:
        return None, [], "none"

    # Effective weight includes confidence (default 0.6)
    pairs: list[tuple[float, float, SourceValue]] = []
    for v in vals:
        conf = v.confidence if v.confidence is not None else 0.6
        w = max(0.05, float(v.weight)) * max(0.05, float(conf))
        pairs.append((float(v.value), w, v))

    pairs.sort(key=lambda x: x[0])
    total = sum(w for _, w, _ in pairs) or 1.0
    cum = 0.0
    selected = pairs[-1][0]
    for val, w, _sv in pairs:
        cum += w
        if cum / total >= 0.5:
            selected = val
            break

    sources_payload = [
        {
            "source": sv.source,
            "value": sv.value,
            "confidence": sv.confidence,
            "weight": sv.weight,
            "meta": sv.meta or {},
        }
        for _, _, sv in pairs
    ]
    return float(selected), sources_payload, "weighted_median"


# ---------------------------------------------------------------------------
# Utility: deterministic JSON checksum (exported for lineage verification)
# ---------------------------------------------------------------------------

import hashlib as _hashlib
import json as _json
from typing import Any as _Any


def checksum(value: _Any) -> str:
    """SHA-256 hex digest of the JSON-serialised value (keys sorted)."""
    raw = _json.dumps(value, sort_keys=True, default=str).encode("utf-8")
    return _hashlib.sha256(raw).hexdigest()
