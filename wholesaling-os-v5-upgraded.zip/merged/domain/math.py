from __future__ import annotations

"""Core underwriting math.

These formulas are intentionally simple, explicit, and easy to audit.
"""

import os

from domain.assumptions import load_assumptions


def clamp(v: float, lo: float, hi: float) -> float:
    return max(min(v, hi), lo)


def calc_mao_wholesale(
    arv: float,
    rehab: float,
    assignment_fee: float = 15000.0,
    max_pct: float = 0.70,
    assumptions_version: str | None = None,
) -> float:
    """Classic wholesale MAO: ARV * % - rehab - assignment."""
    if os.getenv("USE_VERSIONED_ASSUMPTIONS", "false").lower().strip() == "true":
        a = load_assumptions(assumptions_version)
        assignment_fee = float(a.get("assignment_fee", assignment_fee) or assignment_fee)
        # Max pct is encoded in formula string; keep explicit param as source of truth.
    return max(arv * max_pct - rehab - assignment_fee, 0.0)


def calc_mao_flip(
    arv: float,
    rehab: float,
    holding_costs: float = 15000.0,
    selling_cost_pct: float = 0.08,
    profit_target: float = 30000.0,
    max_pct_cap: float = 0.80,
    assumptions_version: str | None = None,
) -> float:
    """Flip MAO: ARV - selling costs - rehab - holding - profit.

    We also cap at ARV * max_pct_cap to avoid unrealistic buys.
    """
    if os.getenv("USE_VERSIONED_ASSUMPTIONS", "false").lower().strip() == "true":
        a = load_assumptions(assumptions_version)
        selling_cost_pct = float(a.get("selling_cost_pct", selling_cost_pct) or selling_cost_pct)
        holding_costs = float(a.get("holding_cost_base", holding_costs) or holding_costs)
        profit_target = float(a.get("profit_target", profit_target) or profit_target)

    selling_costs = arv * clamp(selling_cost_pct, 0.0, 0.20)
    mao = arv - selling_costs - rehab - holding_costs - profit_target
    return max(min(mao, arv * max_pct_cap), 0.0)


def rehab_estimate_from_tags(*, sqft: int | None, condition: str | None) -> float:
    """Heuristic rehab estimator.

    condition: one of "light", "medium", "heavy", "unknown".
    """
    base = 25000.0
    if sqft and sqft > 0:
        base = max(base, sqft * 15.0)

    c = (condition or "unknown").lower()
    mult = {
        "light": 0.8,
        "cosmetic": 0.8,
        "medium": 1.0,
        "standard": 1.0,
        "heavy": 1.4,
        "full": 1.4,
        "unknown": 1.1,
    }.get(c, 1.1)
    return round(base * mult, 0)
