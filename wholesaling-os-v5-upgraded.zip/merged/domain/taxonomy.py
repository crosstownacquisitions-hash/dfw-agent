"""Standard enums (authoritative value sets).

Keep Notion selects constrained to these values.
"""

LEAD_STATUS = [
    "New",
    "Contacted",
    "Follow Up",
    "Underwriting",
    "Offer Sent",
    "Negotiating",
    "Under Contract",
    "Dead",
]

DECISIONS = [
    "Send Offer",
    "Negotiate",
    "Nurture",
    "Reject",
    "Needs Review",
]

DEALROOM_STATUS = ["New", "Draft", "Sent", "Viewed", "Negotiating", "Closed", "Dead"]
DEALROOM_TIER = ["A", "B", "C", "D"]
PACKET_STATUS = ["Not Started", "In Progress", "Ready", "Sent"]

TASK_STATUS = ["Not Started", "In Progress", "Waiting", "Done"]
TASK_PRIORITY = ["Low", "Medium", "High", "Critical"]
TASK_TYPE = ["Offer", "Follow Up", "Research", "Dispo", "Admin"]
