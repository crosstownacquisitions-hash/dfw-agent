from __future__ import annotations

import argparse
import csv
import uuid

from tools.notion.writers import NotionWriters
from domain.identity import IdentityRegistry, build_fingerprint


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--csv", required=True, help="Path to CSV file")
    p.add_argument("--limit", type=int, default=2000)
    p.add_argument("--source", type=str, default="CSV Import")
    args = p.parse_args()

    nw = NotionWriters()
    idreg = IdentityRegistry()
    n = 0
    with open(args.csv, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if n >= args.limit:
                break

            address = (row.get("address") or row.get("Address") or "").strip()
            if not address:
                continue

            source_record_id = (row.get("lead_id") or row.get("Lead ID") or row.get("id") or row.get("ID") or "").strip()
            parcel_apn = (row.get("apn") or row.get("APN") or row.get("parcel") or row.get("Parcel") or "").strip() or None

            fp = build_fingerprint(
                address=address,
                parcel_apn=parcel_apn,
                source_system=(row.get("source") or args.source),
                source_record_id=source_record_id or address,
            )
            lead_id = idreg.get_or_create(fingerprint=fp, preferred_lead_id=(source_record_id or None)).canonical_lead_id
            nw.upsert_lead(
                lead_id=lead_id,
                address=address,
                fields={
                    "status": row.get("status") or "New",
                    "source": row.get("source") or args.source,
                    "city": row.get("city") or row.get("City"),
                    "state": row.get("state") or row.get("State") or "TX",
                    "zip": row.get("zip") or row.get("Zip"),
                    "county": row.get("county") or row.get("County"),
                    "property_type": row.get("type") or row.get("Type") or "SFH",
                    "beds": _to_num(row.get("beds") or row.get("Beds")),
                    "baths": _to_num(row.get("baths") or row.get("Baths")),
                    "sqft": _to_num(row.get("sqft") or row.get("Sqft")),
                    "year_built": _to_num(row.get("year") or row.get("Year")),
                    "asking_price": _to_num(row.get("asking") or row.get("Asking Price")),
                },
            )
            n += 1
    print({"imported": n})


def _to_num(v: str | None):
    if v is None:
        return None
    s = str(v).strip().replace(",", "")
    if s == "":
        return None
    try:
        return float(s)
    except Exception:
        return None


if __name__ == "__main__":
    main()
