from __future__ import annotations

"""Sync engine output CSV -> Notion Leads + Underwriting (linked).

Usage:
    python -m scripts.sync_underwriting_from_output --csv "out/ranked_leads.csv" --limit 2000

Expected columns (flexible):
- Address / City / State / Zip / Lead ID
- ARV / Rehab / MAO Flip / MAO Wholesale / Deal Score / Decision / Wholesale Sweet Spot
or your engine-specific equivalents (ARV_Est, Repairs_Est, MAO_80, MAO_70, DealScore, etc.)

Notes:
- Leads upsert is idempotent via hash stored in Leads.Last Updated (rich text).
- Underwriting row upsert uses Deal (title) = deal_key.
"""

import argparse
import pandas as pd

from agents.notion_sync import NotionSync
from agents.hash_utils import row_hash
from domain.sweet_spot import wholesale_sweet_spot


def _f(x):
    try:
        if x == "" or x is None:
            return None
        return float(str(x).replace(",", "").strip())
    except Exception:
        return None


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--csv", required=True, help="Engine output CSV (e.g., out/ranked_leads.csv)")
    p.add_argument("--limit", type=int, default=2000)
    args = p.parse_args(argv)

    df = pd.read_csv(args.csv, dtype=str, keep_default_na=False).fillna("")
    ns = NotionSync()
    idx = ns.preload_leads_index()

    updated = 0
    skipped = 0

    for i, r in enumerate(df.to_dict("records")):
        if i >= args.limit:
            break

        address = str(r.get("Address") or r.get("address") or "").strip()
        lead_id = str(r.get("Lead ID") or r.get("LeadID") or r.get("lead_id") or "").strip()
        if not address:
            skipped += 1
            continue

        city = str(r.get("City") or r.get("city") or "").strip()
        state = str(r.get("State") or r.get("state") or "").strip()
        zip_ = str(r.get("Zip") or r.get("zip") or "").strip()

        deal_key = str(
            r.get("DealKey")
            or r.get("deal_key")
            or f"{address}|{city}|{state}|{zip_}"
        ).strip()

        canonical = {
            "lead_id": lead_id,
            "address": address,
            "city": city,
            "state": state,
            "zip": zip_,

            "deal_key": deal_key,
            "arv_est": _f(r.get("ARV_Est") or r.get("ARV") or ""),
            "repairs_est": _f(r.get("Repairs_Est") or r.get("Rehab") or ""),
            "mao_flip": _f(r.get("MAO_80") or r.get("MAO Flip") or ""),
            "mao_wholesale": _f(r.get("MAO_70") or r.get("MAO Wholesale") or ""),
            "deal_score": _f(r.get("DealScore") or r.get("Deal Score") or ""),
            "decision": str(r.get("Decision") or "").strip() or ("Send Offer" if str(r.get("SendOffer") or "").strip().lower() in ("1","true","yes") else ""),
            "sweet_spot": str(r.get("WholesaleSweetSpot") or r.get("Wholesale Sweet Spot") or "").strip(),
            "notes": str(r.get("Notes") or "").strip(),
        }

        # Auto-classify sweet spot if missing (based on seller ask vs MAO wholesale)
        if not canonical.get("sweet_spot"):
            ask = _f(
                r.get("AskingPrice")
                or r.get("Asking Price")
                or r.get("Seller Asking")
                or r.get("Ask")
                or r.get("List Price")
                or r.get("Price")
                or ""
            )
            canonical["sweet_spot"] = wholesale_sweet_spot(ask, canonical.get("mao_wholesale"))

        canonical["last_updated_hash"] = row_hash(
            canonical,
            ["deal_key", "arv_est", "repairs_est", "mao_flip", "mao_wholesale", "deal_score", "decision", "sweet_spot"],
        )

        lead_page_id = ns.upsert_lead(canonical, idx=idx)
        ns.upsert_underwriting(canonical, lead_page_id)

        updated += 1
        if updated % 100 == 0:
            print(f"Synced {updated} rows...")

    print({"updated": updated, "skipped": skipped})


if __name__ == "__main__":
    main()
