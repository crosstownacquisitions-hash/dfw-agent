from __future__ import annotations

import argparse
from datetime import datetime, timedelta, date
import pandas as pd

from agents.notion_sync import NotionSync


def _today() -> date:
    # Keep it simple: local date. (Notion stores ISO date strings)
    return datetime.now().date()


def _pick_task(decision: str) -> tuple[str, str, str]:
    d = (decision or "").lower()
    if "send offer" in d or "offer" in d:
        return ("Offer", "To Do", "High")
    if "follow" in d or "nurture" in d or "callback" in d:
        return ("Follow-Up", "To Do", "Medium")
    if "research" in d or "enrich" in d:
        return ("Research", "To Do", "Low")
    return ("", "", "")


def main(argv: list[str] | None = None):
    p = argparse.ArgumentParser()
    p.add_argument("--csv", required=True, help="Engine output CSV (e.g., out/ranked_leads.csv)")
    p.add_argument("--limit", type=int, default=2000)
    p.add_argument("--due_days", type=int, default=0, help="Days from today for default due date")
    args = p.parse_args(argv)

    df = pd.read_csv(args.csv).fillna("")
    ns = NotionSync()
    idx = ns.preload_leads_index()

    created = 0
    skipped = 0

    due = _today() + timedelta(days=int(args.due_days))

    for i, r in enumerate(df.to_dict("records")):
        if i >= args.limit:
            break

        address = str(r.get("Address") or r.get("address") or "").strip()
        if not address:
            skipped += 1
            continue

        decision = str(r.get("Decision") or "").strip()
        task_type, status, priority = _pick_task(decision)
        if not task_type:
            skipped += 1
            continue

        lead_id = str(r.get("Lead ID") or r.get("LeadID") or r.get("lead_id") or "").strip()

        canonical = {
            "lead_id": lead_id,
            "address": address,
            "city": str(r.get("City") or r.get("city") or "").strip(),
            "state": str(r.get("State") or r.get("state") or "").strip(),
            "zip": str(r.get("Zip") or r.get("zip") or "").strip(),
        }
        lead_page_id = ns.upsert_lead(canonical, idx=idx)
        dealroom_id = ""
        try:
            dealroom_id = ns.upsert_dealroom({"Address": address})
        except Exception:
            dealroom_id = ""

        best_phone = str(r.get("Best Phone") or r.get("Phone") or r.get("phone") or "").strip()

        task_name = f"{task_type}: {address}"

        task = {
            "Task Name": task_name,
            "Status": status,
            "Due Date": due.isoformat(),
            "Task Type": task_type,
            "Priority": priority,
            "Address": address,
            "Best Phone": best_phone,
            "Attempt #": str(r.get("Attempt #") or "0").strip() or "0",
            "Notes": "",
        }

        ns.upsert_task(task, relation_candidates=[lead_page_id, dealroom_id])
        created += 1

    print({"tasks_upserted": created, "skipped": skipped})


if __name__ == "__main__":
    main()
