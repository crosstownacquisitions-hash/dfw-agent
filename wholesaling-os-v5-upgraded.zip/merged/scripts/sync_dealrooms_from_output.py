from __future__ import annotations

import argparse
import pandas as pd

from agents.notion_sync import NotionSync


def _f(x):
    try:
        if x == "" or x is None:
            return None
        return float(x)
    except Exception:
        return None


def _tier(score: float | None) -> str:
    if score is None:
        return "C"
    if score >= 85:
        return "A"
    if score >= 75:
        return "B"
    if score >= 65:
        return "C"
    return "D"


def main(argv: list[str] | None = None):
    p = argparse.ArgumentParser()
    p.add_argument("--csv", required=True, help="Engine output CSV (e.g., out/ranked_leads.csv)")
    p.add_argument("--limit", type=int, default=2000)
    p.add_argument("--min_score", type=float, default=65.0)
    args = p.parse_args(argv)

    df = pd.read_csv(args.csv).fillna("")
    ns = NotionSync()

    upserted = 0
    skipped = 0

    for i, r in enumerate(df.to_dict("records")):
        if i >= args.limit:
            break

        address = str(r.get("Address") or r.get("address") or "").strip()
        if not address:
            skipped += 1
            continue

        score = _f(r.get("Deal Score") or r.get("DealScore") or r.get("deal_score") or "")
        decision = str(r.get("Decision") or "").strip()
        send_offer = bool(r.get("SendOffer")) or ("send offer" in decision.lower())

        if not send_offer and (score is None or score < float(args.min_score)):
            skipped += 1
            continue

        arv = _f(r.get("ARV_Est") or r.get("ARV") or "")
        repairs = _f(r.get("Repairs_Est") or r.get("Rehab") or "")
        mao = _f(r.get("MAO Wholesale") or r.get("MAO_70") or r.get("MAO") or "")
        if mao is None:
            mao = _f(r.get("MAO Flip") or r.get("MAO_80") or "")

        # Equity %: rough if ARV present
        equity = None
        if arv and mao is not None and arv != 0:
            equity = round((arv - mao) / arv * 100.0, 1)

        dealroom = {
            "Address": address,
            "Status": "New",
            "Tier": _tier(score),
            "Packet Status": "Not Started",
            "Deal Room Link": str(r.get("Deal Room Link") or "").strip(),
            "Google Sheet Row ID": str(r.get("Google Sheet Row ID") or r.get("Row ID") or "").strip(),
            "ARV": arv,
            "Repairs": repairs,
            "MAO": mao,
            "Equity %": equity,
            "Close Probability": None,
            "Buyer Blast Sent": False,
            "Seller Presentation Sent": False,
        }

        ns.upsert_dealroom(dealroom)
        upserted += 1

    print({"dealrooms_upserted": upserted, "skipped": skipped})


if __name__ == "__main__":
    main()
