from __future__ import annotations

import os
import json
import time
import argparse

from dotenv import load_dotenv

from tools.data.repo import init_db
from workflows.daily_run import run as daily_run
from scripts.backfill_leads_from_csv import main as backfill_main


def _load_env():
    load_dotenv()
    # Ensure SSL bundle for requests (Windows)
    try:
        import certifi
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
        os.environ.setdefault("REQUESTS_CA_BUNDLE", certifi.where())
    except Exception:
        pass


def _log_event(obj: dict):
    os.makedirs("out", exist_ok=True)
    obj["ts"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    with open(os.path.join("out", "run_log.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(obj) + "\n")


def main(argv: list[str] | None = None):
    _load_env()
    init_db()

    p = argparse.ArgumentParser()
    p.add_argument("--goal", default="Ingest + rank + push pursued deals (70+) into Notion Tasks/Dealrooms")
    p.add_argument("--limit", type=int, default=2000, help="How many Notion 'New' leads to process this run")
    p.add_argument("--pursue_threshold", type=float, default=70.0, help="Score threshold to create Tasks/Dealrooms")
    p.add_argument("--backfill_csv", default="", help="Optional: ingest a CSV into Notion Leads before processing")
    p.add_argument("--backfill_limit", type=int, default=0, help="Rows to ingest from CSV (0 disables)")
    args = p.parse_args(argv)

    _log_event({"stage": "start", "args": vars(args)})

    if args.backfill_csv and args.backfill_limit:
        _log_event({"stage": "backfill", "csv": args.backfill_csv, "limit": args.backfill_limit})
        backfill_main(["--csv", args.backfill_csv, "--limit", str(args.backfill_limit)])

    _log_event({"stage": "daily_run", "limit": args.limit, "pursue_threshold": args.pursue_threshold})
    out = daily_run(goal=args.goal, limit=args.limit, pursue_threshold=args.pursue_threshold)

    _log_event({"stage": "done", "summary": out})
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
