from __future__ import annotations
import argparse
from orchestration.controller import OSController

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--limit", type=int, default=100)
    p.add_argument("--goal", type=str, default="Find qualified wholesale deals in DFW today")
    args = p.parse_args()
    state = OSController().run_daily(goal=args.goal, limit=args.limit)
    print(state.model_dump())

if __name__ == "__main__":
    main()
