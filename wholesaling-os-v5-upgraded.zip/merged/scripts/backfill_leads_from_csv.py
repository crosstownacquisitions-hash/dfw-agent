from __future__ import annotations

"""Backfill DealSauce export -> Notion Leads DB via canonical schema.

Usage:
    python -m scripts.backfill_leads_from_csv --csv "data/Leads - Import_Stage.csv" --limit 2000

Notes:
- Uses agents.importer.load_leads_canonical (usecols + rename-once + validator)
- Uses agents.notion_sync.NotionSync (idempotent upserts via Last Updated hash storage)
"""

import argparse
import os

from agents.importer import load_leads_canonical
from agents.notion_sync import NotionSync


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--csv", required=True, help="DealSauce export CSV path")
    p.add_argument("--limit", type=int, default=2000)
    p.add_argument("--source", type=str, default="DealSauce", help="Optional source tag to set on Leads.Source")
    p.add_argument("--status", type=str, default="New", help="Optional status to set on Leads.Status")
    args = p.parse_args(argv)

    df, report = load_leads_canonical(args.csv)
    ns = NotionSync()
    idx = ns.preload_leads_index()

    n = 0
    skipped = 0

    for i, row in enumerate(df.to_dict("records")):
        if i >= args.limit:
            break

        address = str(row.get("address") or "").strip()
        if not address:
            skipped += 1
            continue

        canonical = {
            "lead_id": str(row.get("lead_id") or "").strip(),
            "address": address,
            "city": str(row.get("city") or "").strip(),
            "state": str(row.get("state") or "").strip(),
            "zip": str(row.get("zip") or "").strip(),
            "property_type": str(row.get("property_type") or "").strip(),

            # optional convenience fields if your Leads DB has them
            "source": args.source,
            "status": args.status,
        }

        ns.upsert_lead(canonical, idx=idx)
        n += 1

        if n % 100 == 0:
            print(f"Imported {n} leads...")

    print({"imported": n, "skipped": skipped, "report": report})


if __name__ == "__main__":
    main()
