from __future__ import annotations

import os
import requests
from dotenv import load_dotenv


def main() -> None:
    load_dotenv()

    print("NOTION_TOKEN present:", bool(os.getenv("NOTION_TOKEN")))
    print("NOTION_DB_LEADS present:", bool(os.getenv("NOTION_DB_LEADS")))

    # pandas/numpy
    try:
        import numpy, pandas

        print("numpy:", numpy.__version__, "pandas:", pandas.__version__)
    except Exception as e:
        print("pandas/numpy import FAILED:", repr(e))

    # notion ping
    try:
        t = os.getenv("NOTION_TOKEN", "")
        h = {"Authorization": f"Bearer {t}", "Notion-Version": "2022-06-28"}
        r = requests.get("https://api.notion.com/v1/users/me", headers=h, timeout=15)
        print("Notion /users/me:", r.status_code)
    except Exception as e:
        print("Notion ping FAILED:", repr(e))


if __name__ == "__main__":
    main()
