from __future__ import annotations

"""API authentication middleware.

Supports:
  1. API key auth via X-API-Key header (primary)
  2. Bearer token (secondary, same key space)

Keys are loaded from env (API_KEYS=key1,key2,key3).
Operator UI endpoints (/dashboard, /health) are exempt from auth.

Usage
-----
from api.auth import require_auth, optional_auth

@app.get("/run/daily")
async def run_daily(auth: AuthContext = Depends(require_auth)):
    ...
"""

from __future__ import annotations

import hashlib
import logging
import os
import time
from dataclasses import dataclass

from fastapi import Depends, HTTPException, Request, Security, status
from fastapi.security import APIKeyHeader, HTTPAuthorizationCredentials, HTTPBearer

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Key loading
# ---------------------------------------------------------------------------

def _load_api_keys() -> set[str]:
    raw = os.getenv("API_KEYS", "")
    keys = {k.strip() for k in raw.split(",") if k.strip()}
    # Also accept the Notion token as a valid key for operator convenience
    notion = os.getenv("NOTION_TOKEN", "")
    if notion and notion != "secret_xxx":
        keys.add(notion)
    return keys


_API_KEYS: set[str] = _load_api_keys()

# Routes exempt from auth
_EXEMPT_PREFIXES = {"/health", "/metrics", "/docs", "/redoc", "/openapi"}

# ---------------------------------------------------------------------------
# Security schemes
# ---------------------------------------------------------------------------

_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)
_bearer_scheme = HTTPBearer(auto_error=False)


@dataclass
class AuthContext:
    key_hash: str     # Hashed key — never log the raw key
    scopes: list[str]
    authenticated_at: float


# ---------------------------------------------------------------------------
# Auth logic
# ---------------------------------------------------------------------------

def _validate_key(raw_key: str | None) -> AuthContext | None:
    if not raw_key:
        return None

    # If no keys are configured, allow all (dev mode)
    if not _API_KEYS:
        return AuthContext(
            key_hash="dev_mode",
            scopes=["*"],
            authenticated_at=time.time(),
        )

    if raw_key in _API_KEYS:
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()[:12]
        return AuthContext(
            key_hash=key_hash,
            scopes=["*"],
            authenticated_at=time.time(),
        )
    return None


async def require_auth(
    request: Request,
    api_key: str | None = Security(_api_key_header),
    bearer: HTTPAuthorizationCredentials | None = Security(_bearer_scheme),
) -> AuthContext:
    """Dependency: requires valid authentication. Raises 401 if missing/invalid."""
    # Check exempt paths
    path = request.url.path
    if any(path.startswith(p) for p in _EXEMPT_PREFIXES):
        return AuthContext(key_hash="exempt", scopes=["readonly"], authenticated_at=time.time())

    # Try API key header
    ctx = _validate_key(api_key)
    if ctx:
        return ctx

    # Try Bearer token
    if bearer:
        ctx = _validate_key(bearer.credentials)
        if ctx:
            return ctx

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or missing API key. Provide X-API-Key header.",
        headers={"WWW-Authenticate": "ApiKey"},
    )


async def optional_auth(
    api_key: str | None = Security(_api_key_header),
    bearer: HTTPAuthorizationCredentials | None = Security(_bearer_scheme),
) -> AuthContext | None:
    """Dependency: auth is optional — returns None if unauthenticated."""
    ctx = _validate_key(api_key)
    if ctx:
        return ctx
    if bearer:
        return _validate_key(bearer.credentials)
    return None


def reload_keys() -> int:
    """Hot-reload API keys from environment (useful after secret rotation)."""
    global _API_KEYS
    _API_KEYS = _load_api_keys()
    log.info("API keys reloaded: %d keys active", len(_API_KEYS))
    return len(_API_KEYS)
