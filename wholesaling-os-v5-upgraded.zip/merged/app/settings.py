from __future__ import annotations

import os
from dotenv import load_dotenv
from pydantic import BaseModel

load_dotenv()


def _b(name: str, default: bool = False) -> bool:
    v = os.getenv(name, str(default)).strip().lower()
    return v in ("1", "true", "yes", "y", "on")


def _i(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)).strip())
    except Exception:
        return default


class Settings(BaseModel):
    # Notion
    notion_token: str = os.getenv("NOTION_TOKEN", "")
    notion_db_leads: str = os.getenv("NOTION_DB_LEADS", "")
    notion_db_underwriting: str = os.getenv("NOTION_DB_UNDERWRITING", "")
    notion_db_tasks: str = os.getenv("NOTION_DB_TASKS", "")
    notion_db_buyers: str = os.getenv("NOTION_DB_BUYERS", "")
    notion_db_dealrooms: str = os.getenv("NOTION_DB_DEALROOMS", "")

    # Storage / queues
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./dev.db")
    redis_url: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    queue_backend: str = os.getenv("QUEUE_BACKEND", "celery")
    cache_ttl_seconds: int = _i("CACHE_TTL_SECONDS", 86400)

    # LLM routing — supports both naming conventions
    llm_model: str = os.getenv(
        "LLM_MODEL",
        os.getenv("PRIMARY_MODEL", os.getenv("DEFAULT_LLM_MODEL", "gemini/gemini-2.5-flash")),
    )
    embedding_model: str = os.getenv("EMBEDDING_MODEL", "")

    # Security — JWT + API keys
    jwt_secret: str = os.getenv("JWT_SECRET", "CHANGE_ME")
    jwt_issuer: str = os.getenv("JWT_ISSUER", "wholesaling-os")
    jwt_audience: str = os.getenv("JWT_AUDIENCE", "wholesaling-os")
    jwt_exp_minutes: int = _i("JWT_EXP_MINUTES", 120)
    # Accepts both API_KEYS_CSV (Premier) and API_KEYS (V5) env var names
    api_keys_csv: str = os.getenv("API_KEYS_CSV", os.getenv("API_KEYS", ""))

    # Third-party AVM providers
    goliath_base_url: str = os.getenv("GOLIATH_BASE_URL", "")
    goliath_api_key: str = os.getenv("GOLIATH_API_KEY", "")

    # Observability
    metrics_enabled: bool = _b("METRICS_ENABLED", True)
    otel_exporter_otlp_endpoint: str = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "")
    service_name: str = os.getenv("SERVICE_NAME", "wholesaling-os-v5")
    log_level: str = os.getenv("LOG_LEVEL", "INFO")

    @property
    def default_llm_model(self) -> str:
        """Backward-compat alias used by V5 agents."""
        return self.llm_model


settings = Settings()
