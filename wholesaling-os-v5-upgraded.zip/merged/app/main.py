from __future__ import annotations
"""
Wholesaling OS v5 Unified — FastAPI Application

Endpoints:
  GET  /health           — liveness probe
  GET  /health/ready     — readiness probe
  GET  /health/detail    — full dependency health check (DB, Redis, Notion, LLM, CBs)
  GET  /metrics          — Prometheus metrics (auto-instrumented via MetricsMiddleware)
  POST /auth/token       — mint a scoped JWT (requires API key or existing JWT)
  POST /run/daily        — trigger daily pipeline run (enqueued, async)
  POST /run/premier      — synchronous meta-orchestrated run (planner → tasks → critic)
  GET  /runs             — list recent runs
  GET  /runs/{run_id}    — run details + critic reflection
  POST /outcomes         — record deal outcome (feedback loop)
  GET  /leads/summary    — pipeline stats dashboard
  POST /reload-keys      — hot-reload API keys without restart
  GET  /ui               — simple operator UI
"""

from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import JSONResponse, PlainTextResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware

from app.logger import get_logger
from app.settings import settings
from app.middleware import MetricsMiddleware
from app.auth import require_scopes, mint_jwt, Principal, get_principal
from infrastructure.telemetry import init_telemetry
from infrastructure.health import run_all_checks, liveness, readiness
from tools.data.repo import init_db
from orchestration.controller import OSController

log = get_logger(__name__)

app = FastAPI(
    title="Wholesaling OS v5 Unified",
    description="Autonomous DFW wholesale real estate pipeline — Premier + V5 merged",
    version="5.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

if settings.metrics_enabled:
    app.add_middleware(MetricsMiddleware)


# ---------------------------------------------------------------------------
# Startup
# ---------------------------------------------------------------------------

@app.on_event("startup")
def _startup() -> None:
    init_telemetry()
    init_db()
    log.info("Wholesaling OS v5 Unified started")


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health", tags=["ops"])
def health():
    return liveness()


@app.get("/health/ready", tags=["ops"])
def health_ready():
    r = readiness()
    if r.get("status") != "ready":
        raise HTTPException(status_code=503, detail=r)
    return r


@app.get("/health/detail", tags=["ops"])
def health_detail():
    """Full dependency health: DB, Redis, Notion, LLM keys, disk, circuit breakers."""
    return run_all_checks()


# ---------------------------------------------------------------------------
# Metrics (Prometheus — auto-instrumented by MetricsMiddleware)
# ---------------------------------------------------------------------------

@app.get("/metrics", response_class=PlainTextResponse, tags=["ops"])
def metrics():
    if not settings.metrics_enabled:
        return PlainTextResponse("metrics disabled", status_code=404)
    try:
        from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
        return PlainTextResponse(generate_latest().decode("utf-8"), media_type=CONTENT_TYPE_LATEST)
    except ImportError:
        return PlainTextResponse("# prometheus_client not installed\n")


# ---------------------------------------------------------------------------
# Auth — JWT issuance
# ---------------------------------------------------------------------------

@app.post("/auth/token", tags=["auth"])
def issue_token(
    sub: str = "operator",
    scopes: str = "runs:write,notion:write",
    _p: Principal = Depends(get_principal),
):
    """Mint a scoped JWT. Requires valid API key or existing JWT.

    Example scopes: runs:write, notion:write, runs:read
    Tokens expire after JWT_EXP_MINUTES (default 120).
    """
    tok = mint_jwt(sub=sub, scopes=[s.strip() for s in scopes.split(",") if s.strip()])
    return {"token": tok, "sub": sub, "scopes": scopes, "expires_in_minutes": settings.jwt_exp_minutes}


# ---------------------------------------------------------------------------
# Pipeline — async (enqueued) run
# ---------------------------------------------------------------------------

@app.post("/run/daily", tags=["pipeline"])
def run_daily(
    limit: int = 100,
    goal: str = "Find qualified wholesale deals in DFW today",
    pursue_threshold: float = 70.0,
):
    """Trigger daily pipeline run. Enqueues work and returns run_id immediately."""
    state = OSController().run_daily(goal=goal, limit=limit, pursue_threshold=pursue_threshold)
    return {"run_id": state.context.run_id, "status": "enqueued", "goal": goal}


# ---------------------------------------------------------------------------
# Pipeline — synchronous meta-orchestrated run (Premier pattern)
# ---------------------------------------------------------------------------

@app.post("/run/premier", tags=["pipeline"])
def run_premier(
    limit: int = 100,
    goal: str = "Find qualified wholesale deals in DFW today",
    _p: Principal = Depends(require_scopes("runs:write")),
):
    """Synchronous planner → tasks → critic run. Returns full result dict.

    Requires JWT with runs:write scope (or API key).
    """
    from agents.pipeline import DailyPipeline
    res = DailyPipeline().run(goal=goal, limit=limit)
    return res.__dict__


# ---------------------------------------------------------------------------
# Runs — list and detail
# ---------------------------------------------------------------------------

@app.get("/runs", tags=["pipeline"])
def list_runs(limit: int = 20):
    """List recent pipeline runs."""
    try:
        from tools.data.storage import SessionLocal
        from tools.data.models import Run
        from sqlalchemy import select, desc
        with SessionLocal() as s:
            rows = s.execute(select(Run).order_by(desc(Run.started_at)).limit(limit)).scalars().all()
            return [
                {
                    "run_id": r.run_id,
                    "goal": r.goal,
                    "started_at": r.started_at.isoformat() if r.started_at else None,
                    "finished_at": r.finished_at.isoformat() if r.finished_at else None,
                    "summary": r.summary,
                }
                for r in rows
            ]
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.get("/runs/{run_id}", tags=["pipeline"])
def get_run(run_id: str):
    """Get run details and critic reflection."""
    try:
        from tools.data.storage import SessionLocal
        from tools.data.models import Run
        with SessionLocal() as s:
            run = s.get(Run, run_id)
            if not run:
                raise HTTPException(status_code=404, detail="Run not found")
            reflection = None
            try:
                from agents.memory.vector_store import get_store
                mem = get_store("reflections").get(run_id)
                if mem:
                    reflection = mem.get("payload")
            except Exception:
                pass
            return {
                "run_id": run.run_id,
                "goal": run.goal,
                "started_at": run.started_at.isoformat() if run.started_at else None,
                "finished_at": run.finished_at.isoformat() if run.finished_at else None,
                "summary": run.summary,
                "reflection": reflection,
            }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ---------------------------------------------------------------------------
# Outcomes — feedback loop write path
# ---------------------------------------------------------------------------

@app.post("/outcomes", tags=["feedback"])
def record_outcome(
    lead_id: str,
    run_id: str,
    event: str,
    value: float | None = None,
    meta: dict | None = None,
):
    """Record a deal outcome event: offer_sent, offer_accepted, closed, dead."""
    from tools.data.repo import OutcomeRepo
    from agents.memory.vector_store import get_store
    OutcomeRepo().add(lead_id=lead_id, run_id=run_id, event=event, value=value, meta=meta)
    try:
        store = get_store("leads")
        store.update_outcome(lead_id, outcome=event, confidence=1.0 if event == "closed" else 0.8)
    except Exception:
        pass
    return {"recorded": True, "lead_id": lead_id, "event": event}


# ---------------------------------------------------------------------------
# Dashboard summary
# ---------------------------------------------------------------------------

@app.get("/leads/summary", tags=["dashboard"])
def leads_summary():
    """High-level pipeline stats for the operator dashboard."""
    try:
        from tools.data.storage import SessionLocal
        from tools.data.models import Underwrite, Outcome
        from sqlalchemy import select, func
        with SessionLocal() as s:
            total_uw  = s.execute(select(func.count()).select_from(Underwrite)).scalar() or 0
            pursued   = s.execute(select(func.count()).select_from(Underwrite)
                                  .where(Underwrite.decision.in_(["PURSUE_OFFER", "PURSUE_IF_NEGOTIABLE"]))).scalar() or 0
            nurtured  = s.execute(select(func.count()).select_from(Underwrite)
                                  .where(Underwrite.decision == "NURTURE")).scalar() or 0
            discarded = s.execute(select(func.count()).select_from(Underwrite)
                                  .where(Underwrite.decision == "DISCARD")).scalar() or 0
            total_outcomes = s.execute(select(func.count()).select_from(Outcome)).scalar() or 0
            closed = s.execute(select(func.count()).select_from(Outcome)
                               .where(Outcome.event == "closed")).scalar() or 0
        return {
            "total_underwritten": total_uw,
            "pursued": pursued,
            "nurtured": nurtured,
            "discarded": discarded,
            "outcomes_recorded": total_outcomes,
            "closed": closed,
            "conversion_rate": round(closed / pursued, 3) if pursued else 0,
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ---------------------------------------------------------------------------
# Ops
# ---------------------------------------------------------------------------

@app.post("/reload-keys", tags=["ops"])
def reload_keys():
    """Hot-reload API keys from environment after secret rotation."""
    from api.auth import reload_keys as _reload
    n = _reload()
    return {"keys_loaded": n}


@app.get("/ui", response_class=HTMLResponse, tags=["ops"])
def ui():
    return HTMLResponse("""<!doctype html>
<html>
<head><meta charset="utf-8"/><title>Wholesaling OS v5 Unified</title></head>
<body style="font-family: system-ui; max-width: 900px; margin: 40px auto; padding: 0 20px;">
  <h1>Wholesaling OS v5 Unified</h1>
  <p>Premier infrastructure + V5 agent implementations merged into one codebase.</p>
  <h3>Quick start</h3>
  <pre>
# Get a JWT (requires API key):
curl -H "X-API-Key: YOUR_KEY" -X POST "http://localhost:8000/auth/token?sub=operator&scopes=runs:write"

# Run the pipeline (async, enqueued):
curl -X POST "http://localhost:8000/run/daily?limit=50"

# Run synchronously with planner+critic (JWT required):
curl -H "Authorization: Bearer YOUR_JWT" -X POST "http://localhost:8000/run/premier?limit=50"
  </pre>
  <p>
    <a href="/health/detail">/health/detail</a> •
    <a href="/leads/summary">/leads/summary</a> •
    <a href="/metrics">/metrics</a> •
    <a href="/docs">/docs</a>
  </p>
</body></html>""")
