from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Annotated

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer, APIKeyHeader
from app.jwt_simple import JWTError, encode as jwt_encode, decode as jwt_decode

from app.settings import settings


bearer = HTTPBearer(auto_error=False)
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


@dataclass(frozen=True)
class Principal:
    sub: str
    scopes: set[str]


def _api_keys() -> set[str]:
    if not settings.api_keys_csv:
        return set()
    return {k.strip() for k in settings.api_keys_csv.split(",") if k.strip()}


def mint_jwt(sub: str, scopes: list[str]) -> str:
    now = datetime.now(timezone.utc)
    exp = now + timedelta(minutes=settings.jwt_exp_minutes)
    payload = {
        "iss": settings.jwt_issuer,
        "aud": settings.jwt_audience,
        "sub": sub,
        "scopes": scopes,
        "iat": int(now.timestamp()),
        "exp": int(exp.timestamp()),
    }
    return jwt_encode(payload, settings.jwt_secret, algorithm="HS256")


def _principal_from_bearer(creds: HTTPAuthorizationCredentials) -> Principal:
    try:
        payload = jwt_decode(
            creds.credentials,
            settings.jwt_secret,
            audience=settings.jwt_audience,
            issuer=settings.jwt_issuer,
            algorithms=["HS256"],
        )
        sub = str(payload.get("sub", ""))
        scopes = set(payload.get("scopes", []) or [])
        if not sub:
            raise HTTPException(status_code=401, detail="Invalid token: missing subject")
        return Principal(sub=sub, scopes=scopes)
    except JWTError as e:
        raise HTTPException(status_code=401, detail=f"Invalid token: {e}") from e


def get_principal(
    creds: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)],
    api_key: Annotated[str | None, Security(api_key_header)],
) -> Principal:
    """Dependency: accepts API key (wildcard scopes) or JWT (scoped)."""
    # API key path — grants all scopes
    if api_key:
        keys = _api_keys()
        if not keys or api_key in keys:  # dev mode if no keys configured
            return Principal(sub="api_key", scopes={"*"})
        raise HTTPException(status_code=401, detail="Invalid API key")

    # Bearer JWT path
    if creds:
        return _principal_from_bearer(creds)

    raise HTTPException(status_code=401, detail="Missing credentials")


def require_scopes(*required: str):
    """FastAPI dependency factory: raises 403 if Principal lacks any required scope."""
    def _dep(p: Principal = Depends(get_principal)) -> Principal:
        if "*" in p.scopes:
            return p
        missing = [s for s in required if s not in p.scopes]
        if missing:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Missing required scopes: {', '.join(missing)}",
            )
        return p

    return _dep
