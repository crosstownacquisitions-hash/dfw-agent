from __future__ import annotations

from prometheus_client import Counter, Histogram

REQUEST_COUNT = Counter(
    "http_requests_total",
    "Total HTTP requests",
    ["method", "path", "status"],
)

REQUEST_LATENCY = Histogram(
    "http_request_latency_seconds",
    "HTTP request latency in seconds",
    ["method", "path"],
)

LEADS_PROCESSED = Counter("leads_processed_total", "Leads processed", ["stage"])
OFFERS_GENERATED = Counter("offers_generated_total", "Offers generated")
