from __future__ import annotations

import base64
import hashlib
import hmac
import json
from typing import Any


class JWTError(Exception):
    pass


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("utf-8")


def _b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode((s + pad).encode("utf-8"))


def encode(payload: dict[str, Any], secret: str, algorithm: str = "HS256") -> str:
    if algorithm != "HS256":
        raise JWTError("Only HS256 supported")
    header = {"typ": "JWT", "alg": "HS256"}
    h = _b64url(json.dumps(header, separators=(",", ":"), sort_keys=True).encode("utf-8"))
    p = _b64url(json.dumps(payload, separators=(",", ":"), sort_keys=True, default=str).encode("utf-8"))
    signing_input = f"{h}.{p}".encode("utf-8")
    sig = hmac.new(secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
    return f"{h}.{p}.{_b64url(sig)}"


def decode(token: str, secret: str, *, audience: str, issuer: str, algorithms: list[str] | None = None) -> dict[str, Any]:
    algos = algorithms or ["HS256"]
    if "HS256" not in algos:
        raise JWTError("HS256 required")
    parts = token.split(".")
    if len(parts) != 3:
        raise JWTError("Invalid token format")
    h_b, p_b, s_b = parts
    signing_input = f"{h_b}.{p_b}".encode("utf-8")
    expected = hmac.new(secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
    sig = _b64url_decode(s_b)
    if not hmac.compare_digest(expected, sig):
        raise JWTError("Invalid signature")
    payload = json.loads(_b64url_decode(p_b).decode("utf-8"))
    if payload.get("iss") != issuer:
        raise JWTError("Invalid issuer")
    if payload.get("aud") != audience:
        raise JWTError("Invalid audience")
    exp = payload.get("exp")
    if exp is not None:
        if int(exp) < int(__import__("time").time()):
            raise JWTError("Token expired")
    return payload
