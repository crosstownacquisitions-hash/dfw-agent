from __future__ import annotations

import uuid
from datetime import datetime, timezone

from app.logger import get_logger
from domain.decisions import decision_from_score
from tools.data.repo import RunsRepo
from agents.pipeline import process_new_leads
from infrastructure.task_registry import register_task

log = get_logger(__name__)


@register_task("workflows.daily_run:run")
def run(run_id: str | None = None, goal: str = "Find qualified wholesale deals in DFW today", limit: int = 100, pursue_threshold: float = 70.0) -> dict:
    run_id = run_id or f"run_{uuid.uuid4().hex[:10]}"
    RunsRepo().create_run(run_id=run_id, goal=goal, started_at=datetime.now(timezone.utc))
    log.info("Daily run started", extra={"run_id": run_id, "limit": limit})

    summary = process_new_leads(run_id=run_id, limit=limit, pursue_threshold=pursue_threshold)
    RunsRepo().finish_run(run_id=run_id, finished_at=datetime.now(timezone.utc), summary=summary)
    log.info("Daily run finished", extra={"run_id": run_id, **summary})
    return {"run_id": run_id, **summary}
